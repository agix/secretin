var Secretin = (function () {
'use strict';

var version = "1.0.0";

function hexStringToUint8Array(hexString) {
  if (hexString.length % 2 !== 0) {
    throw 'Invalid hexString';
  }
  var arrayBuffer = new Uint8Array(hexString.length / 2);

  for (var i = 0; i < hexString.length; i += 2) {
    var byteValue = parseInt(hexString.substr(i, 2), 16);
    if (isNaN(byteValue)) {
      throw 'Invalid hexString';
    }
    arrayBuffer[i / 2] = byteValue;
  }

  return arrayBuffer;
}

function bytesToHexString(givenBytes) {
  if (!givenBytes) {
    return null;
  }

  var bytes = new Uint8Array(givenBytes);
  var hexBytes = [];

  for (var i = 0; i < bytes.length; ++i) {
    var byteString = bytes[i].toString(16);
    if (byteString.length < 2) {
      byteString = '0' + byteString;
    }
    hexBytes.push(byteString);
  }
  return hexBytes.join('');
}

function asciiToUint8Array(str) {
  var chars = [];
  for (var i = 0; i < str.length; ++i) {
    chars.push(str.charCodeAt(i));
  }
  return new Uint8Array(chars);
}

function bytesToASCIIString(bytes) {
  return String.fromCharCode.apply(null, new Uint8Array(bytes));
}

function generateSeed() {
  var buf = new Uint8Array(32);
  crypto.getRandomValues(buf);

  var shift = 3;
  var carry = 0;
  var symbol = void 0;
  var byte = void 0;
  var i = void 0;
  var output = '';
  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

  for (i = 0; i < buf.length; i++) {
    byte = buf[i];

    symbol = carry | byte >> shift;
    output += alphabet[symbol & 0x1f];

    if (shift > 5) {
      shift -= 5;
      symbol = byte >> shift;
      output += alphabet[symbol & 0x1f];
    }

    shift = 5 - shift;
    carry = byte << shift;
    shift = 8 - shift;
  }

  if (shift !== 3) {
    output += alphabet[carry & 0x1f];
    shift = 3;
    carry = 0;
  }

  return { b32: output, raw: buf };
}

function localStorageAvailable() {
  try {
    var storage = window.localStorage;
    var x = '__storage_test__';
    storage.setItem(x, x);
    storage.removeItem(x);
    return true;
  } catch (e) {
    return false;
  }
}

function xorSeed(byteArray1, byteArray2) {
  if (byteArray1.length === byteArray2.length && byteArray1.length === 32) {
    var buf = new Uint8Array(32);
    var i = void 0;
    for (i = 0; i < 32; i++) {
      buf[i] = byteArray1[i] ^ byteArray2[i];
    }
    return buf;
  }
  throw 'xorSeed wait for 32 bytes arrays';
}

function getSHA256(str) {
  var algorithm = 'SHA-256';
  var data = asciiToUint8Array(str);
  return crypto.subtle.digest(algorithm, data);
}

function genRSAOAEP() {
  var algorithm = {
    name: 'RSA-OAEP',
    modulusLength: 4096,
    publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
    hash: { name: 'SHA-256' }
  };
  var extractable = true;
  var keyUsages = ['wrapKey', 'unwrapKey', 'encrypt', 'decrypt'];
  return crypto.subtle.generateKey(algorithm, extractable, keyUsages);
}

function generateWrappingKey() {
  var algorithm = {
    name: 'AES-CBC',
    length: 256
  };

  var extractable = true;
  var keyUsages = ['wrapKey', 'unwrapKey'];

  return crypto.subtle.generateKey(algorithm, extractable, keyUsages);
}

function encryptAESGCM256(secret, key) {
  var result = {};
  var algorithm = {};
  if (typeof key === 'undefined') {
    algorithm = {
      name: 'AES-GCM',
      length: 256
    };
    var extractable = true;
    var keyUsages = ['encrypt'];
    return crypto.subtle.generateKey(algorithm, extractable, keyUsages).then(function (newKey) {
      var iv = new Uint8Array(12);
      crypto.getRandomValues(iv);
      algorithm = {
        name: 'AES-GCM',
        iv: iv,
        tagLength: 128
      };
      var data = asciiToUint8Array(JSON.stringify(secret));
      result.key = newKey;
      result.iv = iv;
      return crypto.subtle.encrypt(algorithm, newKey, data);
    }).then(function (encryptedSecret) {
      result.secret = encryptedSecret;
      return result;
    });
  }

  result.key = key;
  var iv = new Uint8Array(12);
  crypto.getRandomValues(iv);
  algorithm = {
    name: 'AES-GCM',
    iv: iv,
    tagLength: 128
  };
  var data = asciiToUint8Array(JSON.stringify(secret));
  result.iv = iv;
  return crypto.subtle.encrypt(algorithm, key, data).then(function (encryptedSecret) {
    result.secret = encryptedSecret;
    return result;
  });
}

function decryptAESGCM256(secretObject, key) {
  var algorithm = {
    name: 'AES-GCM',
    iv: hexStringToUint8Array(secretObject.iv),
    tagLength: 128
  };
  var data = hexStringToUint8Array(secretObject.secret);
  return crypto.subtle.decrypt(algorithm, key, data);
}

function encryptRSAOAEP(secret, publicKey) {
  var algorithm = {
    name: 'RSA-OAEP',
    hash: { name: 'SHA-256' }
  };
  var data = asciiToUint8Array(secret);
  return crypto.subtle.encrypt(algorithm, publicKey, data);
}

function decryptRSAOAEP(secret, privateKey) {
  var algorithm = {
    name: 'RSA-OAEP',
    hash: { name: 'SHA-256' }
  };
  var data = hexStringToUint8Array(secret);
  return crypto.subtle.decrypt(algorithm, privateKey, data);
}

function wrapRSAOAEP(key, wrappingPublicKey) {
  var format = 'raw';
  var wrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: { name: 'SHA-256' }
  };
  return crypto.subtle.wrapKey(format, key, wrappingPublicKey, wrapAlgorithm);
}

function unwrapRSAOAEP(wrappedKeyHex, unwrappingPrivateKey) {
  var format = 'raw';
  var wrappedKey = hexStringToUint8Array(wrappedKeyHex);
  var unwrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: { name: 'SHA-256' }
  };
  var unwrappedKeyAlgorithm = {
    name: 'AES-GCM',
    length: 256
  };
  var extractable = true;
  var usages = ['decrypt', 'encrypt'];

  return crypto.subtle.unwrapKey(format, wrappedKey, unwrappingPrivateKey, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, usages);
}

function _exportPublicKey(publicKey) {
  var format = 'jwk';
  return crypto.subtle.exportKey(format, publicKey);
}

function _importPublicKey(jwkPublicKey) {
  var format = 'jwk';
  var algorithm = {
    name: 'RSA-OAEP',
    hash: { name: 'SHA-256' }
  };
  var extractable = false;
  var keyUsages = ['wrapKey', 'encrypt'];
  return crypto.subtle.importKey(format, jwkPublicKey, algorithm, extractable, keyUsages);
}

function derivePassword(password, parameters) {
  var result = {};

  var passwordBuf = asciiToUint8Array(password);
  var extractable = false;
  var usages = ['deriveKey', 'deriveBits'];

  return crypto.subtle.importKey('raw', passwordBuf, { name: 'PBKDF2' }, extractable, usages).then(function (key) {
    var saltBuf = void 0;
    var iterations = void 0;
    if (typeof parameters === 'undefined') {
      saltBuf = new Uint8Array(32);
      crypto.getRandomValues(saltBuf);
      var iterationsBuf = new Uint8Array(1);
      crypto.getRandomValues(iterationsBuf);
      iterations = 100000 + iterationsBuf[0];
    } else {
      saltBuf = hexStringToUint8Array(parameters.salt);
      if (typeof parameters.iterations === 'undefined') {
        iterations = 10000; // retrocompatibility
      } else {
        iterations = parameters.iterations;
      }
    }

    result.salt = saltBuf;
    result.iterations = iterations;

    var algorithm = {
      name: 'PBKDF2',
      salt: saltBuf,
      iterations: iterations,
      hash: { name: 'SHA-256' }
    };

    var deriveKeyAlgorithm = {
      name: 'AES-CBC',
      length: 256
    };

    extractable = true;
    usages = ['wrapKey', 'unwrapKey'];

    return crypto.subtle.deriveKey(algorithm, key, deriveKeyAlgorithm, extractable, usages);
  }).then(function (dKey) {
    result.key = dKey;
    return crypto.subtle.exportKey('raw', dKey);
  }).then(function (rawKey) {
    return crypto.subtle.digest('SHA-256', rawKey);
  }).then(function (hashedKey) {
    result.hash = hashedKey;
    return result;
  });
}

function exportKey(wrappingKey, key) {
  var result = {};
  var format = 'jwk';
  var iv = new Uint8Array(16);
  crypto.getRandomValues(iv);
  var wrapAlgorithm = {
    name: 'AES-CBC',
    iv: iv
  };
  result.iv = iv;
  return crypto.subtle.wrapKey(format, key, wrappingKey, wrapAlgorithm).then(function (wrappedKey) {
    result.key = wrappedKey;
    return result;
  });
}

function _importPrivateKey(key, privateKeyObject) {
  var format = 'jwk';
  var wrappedPrivateKey = hexStringToUint8Array(privateKeyObject.privateKey);
  var unwrapAlgorithm = {
    name: 'AES-CBC',
    iv: hexStringToUint8Array(privateKeyObject.iv)
  };
  var unwrappedKeyAlgorithm = {
    name: 'RSA-OAEP',
    hash: { name: 'sha-256' }
  };
  var extractable = true;
  var keyUsages = ['unwrapKey', 'decrypt'];

  return crypto.subtle.unwrapKey(format, wrappedPrivateKey, key, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, keyUsages).catch(function () {
    throw 'Invalid Password';
  });
}

function importKey(key, keyObject) {
  var format = 'jwk';
  var wrappedKey = hexStringToUint8Array(keyObject.key);
  var unwrapAlgorithm = {
    name: 'AES-CBC',
    iv: hexStringToUint8Array(keyObject.iv)
  };
  var unwrappedKeyAlgorithm = unwrapAlgorithm;
  var extractable = true;
  var keyUsages = ['wrapKey', 'unwrapKey'];

  return crypto.subtle.unwrapKey(format, wrappedKey, key, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, keyUsages).catch(function () {
    throw 'Invalid Password';
  });
}

var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var API = function () {
  function API(db) {
    classCallCheck(this, API);

    if (typeof db === 'object') {
      this.db = db;
    } else {
      this.db = { users: {}, secrets: {} };
    }
  }

  API.prototype.userExists = function userExists(username, isHashed) {
    return this.retrieveUser(username, 'undefined', isHashed).then(function () {
      return true;
    }, function () {
      return false;
    });
  };

  API.prototype.addUser = function addUser(username, privateKey, publicKey, pass) {
    var _this = this;

    var hashedUsername = void 0;
    return getSHA256(username).then(function (rHashedUsername) {
      hashedUsername = rHashedUsername;
      return new Promise(function (resolve, reject) {
        if (typeof _this.db.users[bytesToHexString(hashedUsername)] === 'undefined') {
          resolve(getSHA256(pass.hash));
        } else {
          reject('User already exists');
        }
      });
    }).then(function (hashedHash) {
      _this.db.users[bytesToHexString(hashedUsername)] = {
        pass: {
          salt: pass.salt,
          hash: bytesToHexString(hashedHash),
          iterations: pass.iterations
        },
        privateKey: privateKey,
        publicKey: publicKey,
        keys: {}
      };
      return;
    });
  };

  API.prototype.addSecret = function addSecret(user, secretObject) {
    var _this2 = this;

    return user.getToken(this).then(function () {
      if (typeof _this2.db.users[secretObject.hashedUsername] !== 'undefined') {
        if (typeof _this2.db.secrets[secretObject.hashedTitle] === 'undefined') {
          _this2.db.secrets[secretObject.hashedTitle] = {
            secret: secretObject.secret,
            metadatas: secretObject.metadatas,
            iv: secretObject.iv,
            iv_meta: secretObject.iv_meta,
            users: [secretObject.hashedUsername]
          };
          _this2.db.users[secretObject.hashedUsername].keys[secretObject.hashedTitle] = {
            key: secretObject.wrappedKey,
            rights: 2
          };
          return;
        }
        throw 'Secret already exists';
      } else {
        throw 'User not found';
      }
    });
  };

  API.prototype.deleteSecret = function deleteSecret(user, hashedTitle) {
    var _this3 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this3);
    }).then(function () {
      if (typeof _this3.db.users[hashedUsername] !== 'undefined') {
        if (typeof _this3.db.secrets[hashedTitle] !== 'undefined') {
          delete _this3.db.users[hashedUsername].keys[hashedTitle];
          var index = _this3.db.secrets[hashedTitle].users.indexOf(hashedUsername);
          if (index > -1) {
            _this3.db.secrets[hashedTitle].users.splice(index, 1);
          }
          if (_this3.db.secrets[hashedTitle].users.length === 0) {
            delete _this3.db.secrets[hashedTitle];
          }
          return;
        }
        throw 'Secret not found';
      } else {
        throw 'User not found';
      }
    });
  };

  API.prototype.getNewChallenge = function getNewChallenge(user) {
    return getSHA256(user.username).then(function () {
      var rawChallenge = new Uint8Array(32);
      crypto.getRandomValues(rawChallenge);
      var challenge = bytesToASCIIString(rawChallenge);
      return encryptRSAOAEP(challenge, user.publicKey);
    }).then(function (encryptedChallenge) {
      return {
        time: Date.now().toString(),
        value: bytesToHexString(encryptedChallenge)
      };
    });
  };

  API.prototype.editSecret = function editSecret(user, secretObject, hashedTitle) {
    var _this4 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this4);
    }).then(function () {
      if (typeof _this4.db.users[hashedUsername] !== 'undefined') {
        if (typeof _this4.db.secrets[hashedTitle] !== 'undefined') {
          if (typeof _this4.db.users[hashedUsername].keys[hashedTitle].rights !== 'undefined' && _this4.db.users[hashedUsername].keys[hashedTitle].rights > 0) {
            _this4.db.secrets[hashedTitle].iv = secretObject.iv;
            _this4.db.secrets[hashedTitle].secret = secretObject.secret;
            _this4.db.secrets[hashedTitle].iv_meta = secretObject.iv_meta;
            _this4.db.secrets[hashedTitle].metadatas = secretObject.metadatas;
            return;
          }
          throw 'You can\'t edit this secret';
        } else {
          throw 'Secret not found';
        }
      } else {
        throw 'User not found';
      }
    });
  };

  API.prototype.newKey = function newKey(user, hashedTitle, secret, wrappedKeys) {
    var _this5 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this5);
    }).then(function () {
      if (typeof _this5.db.users[hashedUsername] !== 'undefined') {
        if (typeof _this5.db.secrets[hashedTitle] !== 'undefined') {
          if (typeof _this5.db.users[hashedUsername].keys[hashedTitle].rights !== 'undefined' && _this5.db.users[hashedUsername].keys[hashedTitle].rights > 1) {
            _this5.db.secrets[hashedTitle].iv = secret.iv;
            _this5.db.secrets[hashedTitle].secret = secret.secret;
            _this5.db.secrets[hashedTitle].iv_meta = secret.iv_meta;
            _this5.db.secrets[hashedTitle].metadatas = secret.metadatas;
            wrappedKeys.forEach(function (wrappedKey) {
              if (typeof _this5.db.users[wrappedKey.user] !== 'undefined') {
                if (typeof _this5.db.users[wrappedKey.user].keys[hashedTitle] !== 'undefined') {
                  _this5.db.users[wrappedKey.user].keys[hashedTitle].key = wrappedKey.key;
                }
              }
            });
            return;
          }
          throw 'You can\'t generate new key for this secret';
        } else {
          throw 'Secret not found';
        }
      } else {
        throw 'User not found';
      }
    });
  };

  API.prototype.unshareSecret = function unshareSecret(user, friendNames, hashedTitle) {
    var _this6 = this;

    var hashedUsername = void 0;
    var hashedFriendUsernames = [];
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      var hashedFriendUseramePromises = [];
      friendNames.forEach(function (username) {
        hashedFriendUseramePromises.push(getSHA256(username));
      });
      return Promise.all(hashedFriendUseramePromises);
    }).then(function (rHashedFriendUserames) {
      rHashedFriendUserames.forEach(function (hashedFriendUserame) {
        hashedFriendUsernames.push(bytesToHexString(hashedFriendUserame));
      });
      return user.getToken(_this6);
    }).then(function () {
      if (typeof _this6.db.users[hashedUsername] !== 'undefined') {
        if (typeof _this6.db.secrets[hashedTitle] !== 'undefined') {
          if (typeof _this6.db.users[hashedUsername].keys[hashedTitle].rights !== 'undefined' && _this6.db.users[hashedUsername].keys[hashedTitle].rights > 1) {
            var yourself = 0;
            var nb = 0;
            var response = 'OK';
            hashedFriendUsernames.forEach(function (hashedFriendUsername) {
              if (hashedUsername !== hashedFriendUsername) {
                var dbUser = _this6.db.users[hashedFriendUsername];
                if (typeof dbUser !== 'undefined') {
                  if (typeof dbUser.keys[hashedTitle] !== 'undefined') {
                    delete dbUser.keys[hashedTitle];
                    var id = _this6.db.secrets[hashedTitle].users.indexOf(hashedFriendUsername);
                    _this6.db.secrets[hashedTitle].users.splice(id, 1);
                    nb += 1;
                  } else {
                    throw 'You didn\'t share this secret with ' + hashedFriendUsername;
                  }
                } else {
                  throw hashedFriendUsername + ' not found';
                }
              } else {
                yourself = 1;
                if (hashedFriendUsernames.length === 1) {
                  response = 'You can\'t unshare with yourself';
                }
              }
            });
            if (nb === hashedFriendUsernames.length - yourself) {
              return response;
            }
            throw 'Something goes wrong.';
          } else {
            throw 'You can\'t unshare this secret';
          }
        } else {
          throw 'Secret not found';
        }
      } else {
        throw 'User not found';
      }
    });
  };

  API.prototype.shareSecret = function shareSecret(user, sharedSecretObjects) {
    var _this7 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this7);
    }).then(function () {
      var dbUser = _this7.db.users[hashedUsername];
      if (typeof dbUser !== 'undefined') {
        var nb = 0;
        sharedSecretObjects.forEach(function (sharedSecretObject) {
          if (sharedSecretObject.friendName !== hashedUsername) {
            if (typeof _this7.db.secrets[sharedSecretObject.hashedTitle] !== 'undefined') {
              if (typeof dbUser.keys[sharedSecretObject.hashedTitle].rights !== 'undefined' && dbUser.keys[sharedSecretObject.hashedTitle].rights > 1) {
                var dbFriend = _this7.db.users[sharedSecretObject.friendName];
                if (typeof dbFriend !== 'undefined') {
                  dbFriend.keys[sharedSecretObject.hashedTitle] = {
                    key: sharedSecretObject.wrappedKey,
                    rights: sharedSecretObject.rights
                  };
                  var users = _this7.db.secrets[sharedSecretObject.hashedTitle].users;
                  if (users.indexOf(sharedSecretObject.friendName) < 0) {
                    users.push(sharedSecretObject.friendName);
                  }
                  nb += 1;
                } else {
                  throw 'Friend ' + sharedSecretObject.friendName + ' not found';
                }
              } else {
                throw 'You can\'t share secret ' + sharedSecretObject.hashedTitle;
              }
            } else {
              throw 'Secret ' + sharedSecretObject.hashedTitle + ' not found';
            }
          } else {
            throw 'You can\'t share with yourself';
          }
        });
        if (nb === sharedSecretObjects.length) {
          return;
        }
        throw 'Something goes wrong.';
      } else {
        throw 'User not found';
      }
    });
  };

  API.prototype.retrieveUser = function retrieveUser(username, hash, hashed) {
    var _this8 = this;

    var hashedUsername = username;
    var user = void 0;
    var isHashed = Promise.resolve();

    if (!hashed) {
      isHashed = isHashed.then(function () {
        return getSHA256(username);
      }).then(function (rHashedUsername) {
        hashedUsername = bytesToHexString(rHashedUsername);
        return;
      });
    }

    return isHashed.then(function () {
      if (typeof _this8.db.users[hashedUsername] === 'undefined') {
        throw 'User not found';
      } else {
        user = JSON.parse(JSON.stringify(_this8.db.users[hashedUsername]));
        return getSHA256(hash);
      }
    }).then(function (hashedHash) {
      if (bytesToHexString(hashedHash) === user.pass.hash) {
        var _ret = function () {
          var metadatas = {};
          var hashedTitles = Object.keys(user.keys);
          hashedTitles.forEach(function (hashedTitle) {
            var secret = _this8.db.secrets[hashedTitle];
            metadatas[hashedTitle] = {
              iv: secret.iv_meta,
              secret: secret.metadatas
            };
          });
          user.metadatas = metadatas;
          return {
            v: user
          };
        }();

        if (typeof _ret === "object") return _ret.v;
      }
      var fakePrivateKey = new Uint8Array(3232);
      var fakeIV = new Uint8Array(16);
      var fakeHash = new Uint8Array(32);
      crypto.getRandomValues(fakePrivateKey);
      crypto.getRandomValues(fakeIV);
      crypto.getRandomValues(fakeHash);
      user.privateKey = {
        privateKey: bytesToHexString(fakePrivateKey),
        iv: bytesToHexString(fakeIV)
      };
      user.keys = {};
      user.metadatas = {};
      user.pass.hash = fakeHash;
      return user;
    });
  };

  API.prototype.getDerivationParameters = function getDerivationParameters(username, isHashed) {
    return this.retrieveUser(username, 'undefined', isHashed).then(function (user) {
      return {
        totp: user.pass.totp,
        salt: user.pass.salt,
        iterations: user.pass.iterations
      };
    });
  };

  API.prototype.getPublicKey = function getPublicKey(username, isHashed) {
    return this.retrieveUser(username, 'undefined', isHashed).then(function (user) {
      return user.publicKey;
    });
  };

  API.prototype.getUser = function getUser(username, hash) {
    return this.retrieveUser(username, hash, false);
  };

  API.prototype.getUserWithToken = function getUserWithToken(user) {
    var _this9 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this9);
    }).then(function () {
      return new Promise(function (resolve, reject) {
        if (typeof _this9.db.users[hashedUsername] === 'undefined') {
          reject('User not found');
        } else {
          (function () {
            var userObject = JSON.parse(JSON.stringify(_this9.db.users[hashedUsername]));
            var metadatas = {};
            var hashedTitles = Object.keys(user.keys);
            hashedTitles.forEach(function (hashedTitle) {
              var secret = _this9.db.secrets[hashedTitle];
              metadatas[hashedTitle] = {
                iv: secret.iv_meta,
                secret: secret.metadatas
              };
            });
            userObject.metadatas = metadatas;
            resolve(userObject);
          })();
        }
      });
    });
  };

  API.prototype.getSecret = function getSecret(hash, user) {
    var _this10 = this;

    return user.getToken(this).then(function () {
      return new Promise(function (resolve, reject) {
        if (typeof _this10.db.secrets[hash] === 'undefined') {
          reject('Invalid secret');
        } else {
          resolve(_this10.db.secrets[hash]);
        }
      });
    });
  };

  API.prototype.getAllMetadatas = function getAllMetadatas(user) {
    var _this11 = this;

    var result = {};
    return user.getToken(this).then(function () {
      return new Promise(function (resolve) {
        var hashedTitles = Object.keys(user.keys);
        hashedTitles.forEach(function (hashedTitle) {
          var secret = _this11.db.secrets[hashedTitle];
          result[hashedTitle] = {
            iv: secret.iv_meta,
            secret: secret.metadatas
          };
        });
        resolve(result);
      });
    });
  };

  API.prototype.getDb = function getDb() {
    var _this12 = this;

    return new Promise(function (resolve) {
      resolve(_this12.db);
    });
  };

  API.prototype.changePassword = function changePassword(user, privateKey, pass) {
    var _this13 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this13);
    }).then(function () {
      return new Promise(function (resolve, reject) {
        if (typeof _this13.db.users[hashedUsername] !== 'undefined') {
          resolve(getSHA256(pass.hash));
        } else {
          reject('User not found');
        }
      });
    }).then(function (hashedHash) {
      var newPass = pass;
      newPass.hash = bytesToHexString(hashedHash);
      _this13.db.users[hashedUsername].privateKey = privateKey;
      _this13.db.users[hashedUsername].pass = newPass;
      return;
    });
  };

  return API;
}();

var User = function () {
  function User(username) {
    classCallCheck(this, User);

    this.username = username;
    this.publicKey = null;
    this.privateKey = null;
    this.keys = {};
    this.hash = '';
    this.totp = false;
    this.metadatas = {};
    this.token = {
      value: '',
      time: 0
    };
  }

  User.prototype.disconnect = function disconnect() {
    delete this.username;
    delete this.publicKey;
    delete this.privateKey;
    delete this.metadatas;
    delete this.keys;
    delete this.token;
    delete this.hash;
    delete this.totp;
  };

  User.prototype.isTokenValid = function isTokenValid() {
    return this.token.time > Date.now() - 10000;
  };

  User.prototype.getToken = function getToken(api) {
    var _this = this;

    if (this.isTokenValid()) {
      return this.token.value;
    }

    return api.getNewChallenge(this).then(function (challenge) {
      _this.token.time = challenge.time;
      _this.token.value = decryptRSAOAEP(challenge.value, _this.privateKey);
      return _this.token.value;
    });
  };

  User.prototype.generateMasterKey = function generateMasterKey() {
    var _this2 = this;

    return genRSAOAEP().then(function (keyPair) {
      _this2.publicKey = keyPair.publicKey;
      _this2.privateKey = keyPair.privateKey;
      return;
    });
  };

  User.prototype.exportPublicKey = function exportPublicKey() {
    return _exportPublicKey(this.publicKey);
  };

  User.prototype.importPublicKey = function importPublicKey(jwkPublicKey) {
    var _this3 = this;

    return _importPublicKey(jwkPublicKey).then(function (publicKey) {
      _this3.publicKey = publicKey;
      return;
    });
  };

  User.prototype.exportPrivateKey = function exportPrivateKey(password) {
    var _this4 = this;

    var pass = {};
    return derivePassword(password).then(function (dKey) {
      pass.salt = bytesToHexString(dKey.salt);
      _this4.hash = bytesToHexString(dKey.hash);
      pass.hash = _this4.hash;
      pass.iterations = dKey.iterations;
      return exportKey(dKey.key, _this4.privateKey);
    }).then(function (keyObject) {
      return {
        privateKey: {
          privateKey: bytesToHexString(keyObject.key),
          iv: bytesToHexString(keyObject.iv)
        },
        pass: pass
      };
    });
  };

  User.prototype.importPrivateKey = function importPrivateKey(dKey, privateKeyObject) {
    var _this5 = this;

    return _importPrivateKey(dKey, privateKeyObject).then(function (privateKey) {
      _this5.privateKey = privateKey;
      return;
    });
  };

  User.prototype.encryptTitle = function encryptTitle(title, publicKey) {
    return encryptRSAOAEP(title, publicKey).then(function (encryptedTitle) {
      return bytesToHexString(encryptedTitle);
    });
  };

  User.prototype.shareSecret = function shareSecret(friend, wrappedKey, hashedTitle) {
    var _this6 = this;

    var result = { hashedTitle: hashedTitle };
    return this.unwrapKey(wrappedKey).then(function (key) {
      return _this6.wrapKey(key, friend.publicKey);
    }).then(function (friendWrappedKey) {
      result.wrappedKey = friendWrappedKey;
      return getSHA256(friend.username);
    }).then(function (hashedUsername) {
      result.friendName = bytesToHexString(hashedUsername);
      return result;
    });
  };

  User.prototype.editSecret = function editSecret(hashedTitle, secret) {
    var _this7 = this;

    var metadatas = this.metadatas[hashedTitle];
    if (typeof metadatas === 'undefined') {
      throw 'You don\'t have this secret';
    } else {
      var _ret = function () {
        var now = new Date();
        metadatas.lastModifiedAt = now.toISOString();
        metadatas.lastModifiedBy = _this7.username;
        var wrappedKey = _this7.keys[hashedTitle].key;
        var result = {};
        return {
          v: _this7.unwrapKey(wrappedKey).then(function (key) {
            return _this7.encryptSecret(metadatas, secret, key);
          }).then(function (secretObject) {
            result.secret = secretObject.secret;
            result.iv = secretObject.iv;
            result.metadatas = secretObject.metadatas;
            result.iv_meta = secretObject.iv_meta;
            return result;
          })
        };
      }();

      if (typeof _ret === "object") return _ret.v;
    }
  };

  User.prototype.createSecret = function createSecret(metadatas, secret) {
    var _this8 = this;

    var now = Date.now();
    var saltedTitle = now + '|' + metadatas.title;
    var result = {};
    var newMetadas = metadatas;
    return getSHA256(saltedTitle).then(function (hashedTitle) {
      result.hashedTitle = bytesToHexString(hashedTitle);
      newMetadas.id = result.hashedTitle;
      return _this8.encryptSecret(newMetadas, secret);
    }).then(function (secretObject) {
      result.secret = secretObject.secret;
      result.iv = secretObject.iv;
      result.metadatas = secretObject.metadatas;
      result.iv_meta = secretObject.iv_meta;
      result.hashedUsername = secretObject.hashedUsername;
      return _this8.wrapKey(secretObject.key, _this8.publicKey);
    }).then(function (wrappedKey) {
      result.wrappedKey = wrappedKey;
      return result;
    });
  };

  User.prototype.encryptSecret = function encryptSecret(metadatas, secret, key) {
    var _this9 = this;

    var result = {};
    return encryptAESGCM256(secret, key).then(function (secretObject) {
      result.secret = bytesToHexString(secretObject.secret);
      result.iv = bytesToHexString(secretObject.iv);
      result.key = secretObject.key;
      return encryptAESGCM256(metadatas, secretObject.key);
    }).then(function (secretObject) {
      result.metadatas = bytesToHexString(secretObject.secret);
      result.iv_meta = bytesToHexString(secretObject.iv);
      return getSHA256(_this9.username);
    }).then(function (hashedUsername) {
      result.hashedUsername = bytesToHexString(hashedUsername);
      return result;
    });
  };

  User.prototype.decryptSecret = function decryptSecret(hashedTitle, secret) {
    if (typeof this.keys[hashedTitle] === 'undefined') {
      throw 'You don\'t have this secret';
    } else {
      var wrappedKey = this.keys[hashedTitle].key;
      return this.unwrapKey(wrappedKey).then(function (key) {
        return decryptAESGCM256(secret, key);
      }).then(function (decryptedSecret) {
        return bytesToASCIIString(decryptedSecret);
      });
    }
  };

  User.prototype.unwrapKey = function unwrapKey(wrappedKey) {
    return unwrapRSAOAEP(wrappedKey, this.privateKey);
  };

  User.prototype.wrapKey = function wrapKey(key, publicKey) {
    return wrapRSAOAEP(key, publicKey).then(function (wrappedKey) {
      return bytesToHexString(wrappedKey);
    });
  };

  User.prototype.decryptAllMetadatas = function decryptAllMetadatas(allMetadatas) {
    var _this10 = this;

    var decryptMetadatasPromises = [];
    var hashedTitles = Object.keys(this.keys);

    this.metadatas = {};
    hashedTitles.forEach(function (hashedTitle) {
      decryptMetadatasPromises.push(_this10.decryptSecret(hashedTitle, allMetadatas[hashedTitle]).then(function (metadatas) {
        _this10.metadatas[hashedTitle] = JSON.parse(metadatas);
        return;
      }));
    });

    return Promise.all(decryptMetadatasPromises);
  };

  User.prototype.activateShortpass = function activateShortpass(shortpass, deviceName) {
    var _this11 = this;

    var protectKey = void 0;
    var toSend = {};
    return generateWrappingKey().then(function (key) {
      protectKey = key;
      return exportKey(protectKey, _this11.privateKey);
    }).then(function (object) {
      localStorage.setItem('privateKey', bytesToHexString(object.key));
      localStorage.setItem('privateKeyIv', bytesToHexString(object.iv));
      return derivePassword(shortpass);
    }).then(function (derived) {
      toSend.salt = bytesToHexString(derived.salt);
      toSend.iterations = derived.iterations;
      toSend.hash = bytesToHexString(derived.hash);
      return exportKey(derived.key, protectKey);
    }).then(function (keyObject) {
      toSend.protectKey = bytesToHexString(keyObject.key);
      localStorage.setItem('iv', bytesToHexString(keyObject.iv));
      localStorage.setItem('username', _this11.username);
      return getSHA256(deviceName);
    }).then(function (deviceId) {
      toSend.deviceId = bytesToHexString(deviceId);
      localStorage.setItem('deviceName', deviceName);
      return toSend;
    });
  };

  User.prototype.shortLogin = function shortLogin(shortpass, wrappedProtectKey) {
    var _this12 = this;

    var keyObject = {
      key: wrappedProtectKey,
      iv: localStorage.getItem('iv')
    };
    return importKey(shortpass, keyObject).then(function (protectKey) {
      var privateKeyObject = {
        privateKey: localStorage.getItem('privateKey'),
        iv: localStorage.getItem('privateKeyIv')
      };
      return _importPrivateKey(protectKey, privateKeyObject);
    }).then(function (privateKey) {
      _this12.privateKey = privateKey;
      return;
    });
  };

  return User;
}();

var Secretin = function () {
  function Secretin() {
    var API$$ = arguments.length <= 0 || arguments[0] === undefined ? API : arguments[0];
    var db = arguments[1];
    classCallCheck(this, Secretin);

    this.api = new API$$(db);
    this.currentUser = {};
  }

  Secretin.prototype.changeDB = function changeDB(db) {
    if (typeof this.currentUser.username !== 'undefined') {
      this.currentUser.disconnect();
    }
    this.currentUser = {};
    this.api = new this.api.constructor(db);
  };

  Secretin.prototype.newUser = function newUser(username, password) {
    var _this = this;

    var privateKey = void 0;
    var pass = void 0;
    this.currentUser = new User(username);
    return this.api.userExists(username).then(function (exists) {
      return new Promise(function (resolve, reject) {
        if (!exists) {
          resolve(_this.currentUser.generateMasterKey());
        } else {
          reject('Username already exists');
        }
      });
    }).then(function () {
      return _this.currentUser.exportPrivateKey(password);
    }).then(function (objectPrivateKey) {
      privateKey = objectPrivateKey.privateKey;
      pass = objectPrivateKey.pass;
      pass.totp = false;
      pass.shortpass = false;
      return _this.currentUser.exportPublicKey();
    }).then(function (publicKey) {
      return _this.api.addUser(_this.currentUser.username, privateKey, publicKey, pass);
    }).then(function () {
      return _this.currentUser;
    });
  };

  Secretin.prototype.loginUser = function loginUser(username, password, otp) {
    var _this2 = this;

    var key = void 0;
    var hash = void 0;
    var remoteUser = void 0;
    var parameters = void 0;
    return this.api.getDerivationParameters(username).then(function (rParameters) {
      parameters = rParameters;
      if (parameters.totp && (typeof otp === 'undefined' || otp === '')) {
        throw 'Need TOTP token';
      }
      return derivePassword(password, parameters);
    }).then(function (dKey) {
      hash = bytesToHexString(dKey.hash);
      key = dKey.key;
      return _this2.api.getUser(username, hash, otp);
    }).then(function (user) {
      _this2.currentUser = new User(username);
      _this2.currentUser.totp = parameters.totp;
      _this2.currentUser.hash = hash;
      remoteUser = user;
      _this2.currentUser.keys = remoteUser.keys;
      return _this2.currentUser.importPublicKey(remoteUser.publicKey);
    }).then(function () {
      return _this2.currentUser.importPrivateKey(key, remoteUser.privateKey);
    }).then(function () {
      return _this2.currentUser.decryptAllMetadatas(remoteUser.metadatas);
    }).then(function () {
      return _this2.currentUser;
    });
  };

  Secretin.prototype.refreshUser = function refreshUser() {
    var _this3 = this;

    return this.api.getUserWithToken(this.currentUser).then(function (user) {
      _this3.currentUser.keys = user.keys;
      return _this3.currentUser.decryptAllMetadatas(user.metadatas);
    });
  };

  Secretin.prototype.addFolder = function addFolder(title) {
    return this.addSecret(title, {}, true);
  };

  Secretin.prototype.addSecret = function addSecret(clearTitle, content, isFolder) {
    var _this4 = this;

    var hashedTitle = void 0;
    var now = new Date();
    var metadatas = {
      lastModifiedAt: now.toISOString(),
      lastModifiedBy: this.currentUser.username,
      users: {},
      folders: {},
      title: clearTitle,
      type: 'secret'
    };
    if (isFolder) {
      metadatas.type = 'folder';
    }

    return new Promise(function (resolve, reject) {
      if (typeof _this4.currentUser.currentFolder !== 'undefined') {
        metadatas.users[_this4.currentUser.username] = {
          username: _this4.currentUser.username,
          rights: _this4.currentUser.keys[_this4.currentUser.currentFolder].rights
        };
      } else {
        metadatas.users[_this4.currentUser.username] = {
          username: _this4.currentUser.username,
          rights: 2
        };
      }

      if (typeof _this4.currentUser.username === 'string') {
        _this4.currentUser.createSecret(metadatas, content).then(function (secretObject) {
          hashedTitle = secretObject.hashedTitle;
          _this4.currentUser.keys[secretObject.hashedTitle] = {
            key: secretObject.wrappedKey,
            rights: metadatas.users[_this4.currentUser.username].rights
          };
          _this4.currentUser.metadatas[secretObject.hashedTitle] = metadatas;
          return _this4.api.addSecret(_this4.currentUser, secretObject);
        }).then(function () {
          if (typeof _this4.currentUser.currentFolder !== 'undefined') {
            resolve(_this4.addSecretToFolder(hashedTitle, _this4.currentUser.currentFolder));
          } else {
            resolve(hashedTitle);
          }
        });
      } else {
        reject('You are disconnected');
      }
    });
  };

  Secretin.prototype.changePassword = function changePassword(password) {
    var _this5 = this;

    return this.currentUser.exportPrivateKey(password).then(function (objectPrivateKey) {
      return _this5.api.changePassword(_this5.currentUser, objectPrivateKey.privateKey, objectPrivateKey.pass);
    });
  };

  Secretin.prototype.editSecret = function editSecret(hashedTitle, content) {
    var _this6 = this;

    return this.currentUser.editSecret(hashedTitle, content).then(function (secretObject) {
      return _this6.api.editSecret(_this6.currentUser, secretObject, hashedTitle);
    });
  };

  Secretin.prototype.addSecretToFolder = function addSecretToFolder(hashedSecretTitle, hashedFolder) {
    var _this7 = this;

    var sharedSecretObjectsPromises = [];
    var folderMetadatas = this.currentUser.metadatas[hashedFolder];
    var secretMetadatas = this.currentUser.metadatas[hashedSecretTitle];
    Object.keys(folderMetadatas.users).forEach(function (friendName) {
      sharedSecretObjectsPromises = sharedSecretObjectsPromises.concat(function () {
        var friend = new User(friendName);
        return _this7.api.getPublicKey(friend.username).then(function (publicKey) {
          return friend.importPublicKey(publicKey);
        }).then(function () {
          return _this7.getSharedSecretObjects(hashedSecretTitle, friend, folderMetadatas.users[friend.username].rights, []);
        });
      }());
    });

    var metadatasUsers = {};
    var currentFolder = this.currentUser.currentFolder;
    return Promise.all(sharedSecretObjectsPromises).then(function (sharedSecretObjectsArray) {
      var fullSharedSecretObjects = [];
      sharedSecretObjectsArray.forEach(function (sharedSecretObjects) {
        sharedSecretObjects.forEach(function (sharedSecretObject) {
          var newSharedSecretObject = sharedSecretObject;
          if (typeof metadatasUsers[newSharedSecretObject.hashedTitle] === 'undefined') {
            metadatasUsers[newSharedSecretObject.hashedTitle] = [];
          }
          metadatasUsers[newSharedSecretObject.hashedTitle].push({
            friendName: newSharedSecretObject.username,
            folder: newSharedSecretObject.inFolder
          });
          delete newSharedSecretObject.inFolder;
          if (_this7.currentUser.username !== newSharedSecretObject.username) {
            delete newSharedSecretObject.username;
            fullSharedSecretObjects.push(newSharedSecretObject);
          }
        });
      });
      return _this7.api.shareSecret(_this7.currentUser, fullSharedSecretObjects);
    }).then(function () {
      var resetMetaPromises = [];
      if (typeof currentFolder !== 'undefined') {
        delete secretMetadatas.folders[currentFolder];
      }
      secretMetadatas.folders[hashedFolder] = {
        name: folderMetadatas.title
      };
      Object.keys(metadatasUsers).forEach(function (hashedTitle) {
        metadatasUsers[hashedTitle].forEach(function (infos) {
          var metaUser = {
            username: infos.friendName,
            rights: folderMetadatas.users[infos.friendName].rights
          };
          if (typeof infos.folder === 'undefined') {
            metaUser.folder = folderMetadatas.title;
          } else {
            metaUser.folder = infos.folder;
          }
          if (infos.friendName === _this7.currentUser.username) {
            if (typeof currentFolder === 'undefined') {
              metaUser.rights = 2;
            } else {
              metaUser.rights = _this7.currentUser.keys[currentFolder].rights;
            }
          }
          _this7.currentUser.metadatas[hashedTitle].users[infos.friendName] = metaUser;
        });

        resetMetaPromises.push(_this7.resetMetadatas(hashedTitle));
      });
      return Promise.all(resetMetaPromises);
    }).then(function () {
      return _this7.api.getSecret(hashedFolder, _this7.currentUser);
    }).then(function (encryptedSecret) {
      return _this7.currentUser.decryptSecret(hashedFolder, encryptedSecret);
    }).then(function (secret) {
      var folder = JSON.parse(secret);
      folder[hashedSecretTitle] = 1;
      return _this7.editSecret(hashedFolder, folder);
    }).then(function () {
      return hashedSecretTitle;
    });
  };

  Secretin.prototype.getSharedSecretObjects = function getSharedSecretObjects(hashedTitle, friend, rights, fullSharedSecretObjects, folderName) {
    var _this8 = this;

    var isFolder = Promise.resolve();
    var sharedSecretObjectPromises = [];
    var secretMetadatas = this.currentUser.metadatas[hashedTitle];
    if (typeof secretMetadatas === 'undefined') {
      throw 'You don\'t have this secret';
    } else {
      if (secretMetadatas.type === 'folder') {
        isFolder = isFolder.then(function () {
          return _this8.api.getSecret(hashedTitle, _this8.currentUser);
        }).then(function (encryptedSecret) {
          return _this8.currentUser.decryptSecret(hashedTitle, encryptedSecret);
        }).then(function (secrets) {
          Object.keys(JSON.parse(secrets)).forEach(function (hash) {
            sharedSecretObjectPromises.push(_this8.getSharedSecretObjects(hash, friend, rights, fullSharedSecretObjects, secretMetadatas.title));
          });
          return Promise.all(sharedSecretObjectPromises);
        });
      }

      return isFolder.then(function () {
        return _this8.currentUser.shareSecret(friend, _this8.currentUser.keys[hashedTitle].key, hashedTitle);
      }).then(function (secretObject) {
        var newSecretObject = secretObject;
        newSecretObject.rights = rights;
        newSecretObject.inFolder = folderName;
        newSecretObject.username = friend.username;
        fullSharedSecretObjects.push(newSecretObject);
        return fullSharedSecretObjects;
      });
    }
  };

  Secretin.prototype.resetMetadatas = function resetMetadatas(hashedTitle) {
    var _this9 = this;

    var secretMetadatas = this.currentUser.metadatas[hashedTitle];
    var now = new Date();
    secretMetadatas.lastModifiedAt = now;
    secretMetadatas.lastModifiedBy = this.currentUser.username;
    return this.getSecret(hashedTitle).then(function (secret) {
      return _this9.editSecret(hashedTitle, secret);
    });
  };

  Secretin.prototype.shareSecret = function shareSecret(hashedTitle, friendName, type, rights) {
    var _this10 = this;

    if (type === 'folder') {
      return new Promise(function (resolve, reject) {
        var hashedFolder = false;
        Object.keys(_this10.currentUser.metadatas).forEach(function (hash) {
          var secretMetadatas = _this10.currentUser.metadatas[hash];
          if (secretMetadatas.type === 'folder' && secretMetadatas.title === friendName) {
            hashedFolder = hash;
          }
        });
        if (hashedFolder === false) {
          reject('Folder not found');
        } else if (hashedTitle === hashedFolder) {
          reject('You can\'t put this folder in itself.');
        } else {
          resolve(_this10.addSecretToFolder(hashedTitle, hashedFolder));
        }
      });
    }

    var sharedSecretObjects = void 0;
    var friend = new User(friendName);
    return this.api.getPublicKey(friend.username).then(function (publicKey) {
      return friend.importPublicKey(publicKey);
    }).then(function () {
      return _this10.getSharedSecretObjects(hashedTitle, friend, rights, []);
    }).then(function (rSharedSecretObjects) {
      sharedSecretObjects = rSharedSecretObjects;
      return _this10.api.shareSecret(_this10.currentUser, sharedSecretObjects);
    }).then(function () {
      var resetMetaPromises = [];
      sharedSecretObjects.forEach(function (sharedSecretObject) {
        var secretMetadatas = _this10.currentUser.metadatas[sharedSecretObject.hashedTitle];
        secretMetadatas.users[friend.username] = {
          username: friend.username,
          rights: rights
        };
        if (typeof sharedSecretObject.inFolder !== 'undefined') {
          secretMetadatas.users[friend.username].folder = sharedSecretObject.inFolder;
        }
        resetMetaPromises.push(_this10.resetMetadatas(sharedSecretObject.hashedTitle));
      });
      return Promise.all(resetMetaPromises);
    });
  };

  Secretin.prototype.unshareSecret = function unshareSecret(hashedTitle, friendName) {
    var _this11 = this;

    var isFolder = Promise.resolve();
    var secretMetadatas = this.currentUser.metadatas[hashedTitle];
    if (secretMetadatas.type === 'folder') {
      isFolder = isFolder.then(function () {
        return _this11.unshareFolderSecrets(hashedTitle, friendName);
      });
    }

    return isFolder.then(function () {
      return _this11.api.unshareSecret(_this11.currentUser, [friendName], hashedTitle);
    }).then(function () {
      delete secretMetadatas.users[friendName];
      return _this11.resetMetadatas(hashedTitle);
    }).then(function () {
      return _this11.renewKey(hashedTitle);
    }, function (err) {
      if (err.status === 'Desync') {
        delete _this11.currentUser.metadatas[err.datas.title].users[err.datas.friendName];
        return _this11.resetMetadatas(hashedTitle);
      }
      throw err;
    });
  };

  Secretin.prototype.unshareFolderSecrets = function unshareFolderSecrets(hashedFolder, friendName) {
    var _this12 = this;

    return this.api.getSecret(hashedFolder, this.currentUser).then(function (encryptedSecret) {
      return _this12.currentUser.decryptSecret(hashedFolder, encryptedSecret);
    }).then(function (secrets) {
      return Object.keys(JSON.parse(secrets)).reduce(function (promise, hashedTitle) {
        return promise.then(function () {
          return _this12.unshareSecret(hashedTitle, friendName);
        });
      }, Promise.resolve());
    });
  };

  Secretin.prototype.wrapKeyForFriend = function wrapKeyForFriend(hashedUsername, key) {
    var _this13 = this;

    var friend = void 0;
    return this.api.getPublicKey(hashedUsername, true).then(function (publicKey) {
      friend = new User(hashedUsername);
      return friend.importPublicKey(publicKey);
    }).then(function () {
      return _this13.currentUser.wrapKey(key, friend.publicKey);
    }).then(function (friendWrappedKey) {
      return { user: hashedUsername, key: friendWrappedKey };
    });
  };

  Secretin.prototype.renewKey = function renewKey(hashedTitle) {
    var _this14 = this;

    var encryptedSecret = void 0;
    var secret = {};
    var hashedCurrentUsername = void 0;
    return this.api.getSecret(hashedTitle, this.currentUser).then(function (eSecret) {
      encryptedSecret = eSecret;
      return _this14.currentUser.decryptSecret(hashedTitle, encryptedSecret);
    }).then(function (rawSecret) {
      return _this14.currentUser.encryptSecret(_this14.currentUser.metadatas[hashedTitle], JSON.parse(rawSecret));
    }).then(function (secretObject) {
      secret.secret = secretObject.secret;
      secret.iv = secretObject.iv;
      secret.metadatas = secretObject.metadatas;
      secret.iv_meta = secretObject.iv_meta;
      hashedCurrentUsername = secretObject.hashedUsername;
      var wrappedKeysPromises = [];
      encryptedSecret.users.forEach(function (hashedUsername) {
        if (hashedCurrentUsername === hashedUsername) {
          wrappedKeysPromises.push(_this14.currentUser.wrapKey(secretObject.key, _this14.currentUser.publicKey).then(function (wrappedKey) {
            return { user: hashedCurrentUsername, key: wrappedKey };
          }));
        } else {
          wrappedKeysPromises.push(_this14.wrapKeyForFriend(hashedUsername, secretObject.key));
        }
      });

      return Promise.all(wrappedKeysPromises);
    }).then(function (wrappedKeys) {
      wrappedKeys.forEach(function (wrappedKey) {
        if (wrappedKey.user === hashedCurrentUsername) {
          _this14.currentUser.keys[hashedTitle].key = wrappedKey.key;
        }
      });
      return _this14.api.newKey(_this14.currentUser, hashedTitle, secret, wrappedKeys);
    });
  };

  Secretin.prototype.removeSecretFromFolder = function removeSecretFromFolder(hashedTitle, hashedFolder) {
    var _this15 = this;

    var secretMetadatas = this.currentUser.metadatas[hashedTitle];
    var folderMetadatas = this.currentUser.metadatas[hashedFolder];
    var usersToDelete = [];
    Object.keys(secretMetadatas.users).forEach(function (username) {
      if (typeof secretMetadatas.users[username].folder !== 'undefined' && secretMetadatas.users[username].folder === folderMetadatas.title) {
        usersToDelete.push(username);
      }
    });
    return this.api.unshareSecret(this.currentUser, usersToDelete, hashedTitle).then(function () {
      usersToDelete.forEach(function (username) {
        if (username !== _this15.currentUser.username) {
          delete secretMetadatas.users[username];
        } else {
          delete secretMetadatas.users[username].folder;
        }
      });
      delete secretMetadatas.folders[hashedFolder];
      return _this15.renewKey(hashedTitle);
    }).then(function () {
      return _this15.resetMetadatas(hashedTitle);
    }).then(function () {
      return _this15.api.getSecret(hashedFolder, _this15.currentUser);
    }).then(function (encryptedSecret) {
      return _this15.currentUser.decryptSecret(hashedFolder, encryptedSecret);
    }).then(function (secret) {
      var folder = JSON.parse(secret);
      delete folder[hashedTitle];
      return _this15.editSecret(hashedFolder, folder);
    });
  };

  Secretin.prototype.getSecret = function getSecret(hashedTitle) {
    var _this16 = this;

    return this.api.getSecret(hashedTitle, this.currentUser).then(function (encryptedSecret) {
      return _this16.currentUser.decryptSecret(hashedTitle, encryptedSecret);
    }).then(function (secret) {
      return JSON.parse(secret);
    });
  };

  Secretin.prototype.deleteSecret = function deleteSecret(hashedTitle) {
    var _this17 = this;

    var isFolder = Promise.resolve();
    var secretMetadatas = this.currentUser.metadatas[hashedTitle];
    if (secretMetadatas.type === 'folder') {
      isFolder = isFolder.then(function () {
        return _this17.deleteFolderSecrets(hashedTitle);
      });
    }

    return isFolder.then(function () {
      return _this17.api.deleteSecret(_this17.currentUser, hashedTitle);
    }).then(function () {
      delete _this17.currentUser.metadatas[hashedTitle];
      delete _this17.currentUser.keys[hashedTitle];
      var editFolderPromises = [];
      Object.keys(secretMetadatas.folders).forEach(function (hashedFolder) {
        editFolderPromises.push(_this17.api.getSecret(hashedFolder, _this17.currentUser).then(function (encryptedSecret) {
          return _this17.currentUser.decryptSecret(hashedFolder, encryptedSecret);
        }).then(function (secret) {
          var folder = JSON.parse(secret);
          delete folder[hashedTitle];
          return _this17.editSecret(hashedFolder, folder);
        }));
      });
      return Promise.all(editFolderPromises);
    });
  };

  Secretin.prototype.deleteFolderSecrets = function deleteFolderSecrets(hashedFolder) {
    var _this18 = this;

    return this.api.getSecret(hashedFolder, this.currentUser).then(function (encryptedSecret) {
      return _this18.currentUser.decryptSecret(hashedFolder, encryptedSecret);
    }).then(function (secrets) {
      return Object.keys(JSON.parse(secrets)).reduce(function (promise, hashedTitle) {
        return promise.then(function () {
          return _this18.deleteSecret(hashedTitle);
        });
      }, Promise.resolve());
    });
  };

  Secretin.prototype.activateTotp = function activateTotp(seed) {
    var protectedSeed = xorSeed(hexStringToUint8Array(this.currentUser.hash), seed.raw);
    return this.api.activateTotp(bytesToHexString(protectedSeed), this.currentUser);
  };

  Secretin.prototype.activateShortpass = function activateShortpass(shortpass, deviceName) {
    var _this19 = this;

    if (localStorageAvailable()) {
      return this.currentUser.activateShortpass(shortpass, deviceName).then(function (toSend) {
        return _this19.api.activateShortpass(toSend, _this19.currentUser);
      });
    }
    throw 'LocalStorage unavailable';
  };

  Secretin.prototype.shortLogin = function shortLogin(shortpass) {
    var _this20 = this;

    var username = localStorage.getItem('username');
    var deviceName = localStorage.getItem('deviceName');
    var shortpassKey = void 0;
    var parameters = void 0;
    this.currentUser = new User(username);
    return this.api.getProtectKeyParameters(username, deviceName).then(function (rParameters) {
      parameters = rParameters;
      _this20.currentUser.totp = parameters.totp;
      return _this20.currentUser.importPublicKey(parameters.publicKey);
    }).then(function () {
      return derivePassword(shortpass, parameters);
    }).then(function (dKey) {
      shortpassKey = dKey.key;
      return _this20.api.getProtectKey(username, deviceName, bytesToHexString(dKey.hash));
    }).then(function (protectKey) {
      return _this20.currentUser.shortLogin(shortpassKey, protectKey);
    }).then(function () {
      return _this20.refreshUser();
    }).then(function () {
      return _this20.currentUser;
    }, function (e) {
      localStorage.removeItem('username');
      localStorage.removeItem('deviceName');
      localStorage.removeItem('privateKey');
      localStorage.removeItem('privateKeyIv');
      localStorage.removeItem('iv');
      throw e;
    });
  };

  Secretin.prototype.canITryShortpass = function canITryShortpass() {
    return localStorageAvailable() && localStorage.getItem('username') !== null;
  };

  return Secretin;
}();

function reqData(path, datas, type) {
  return new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.open(type, encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function () {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      } else {
        try {
          var newData = JSON.parse(xhr.responseText);
          reject({ status: xhr.statusText, datas: newData });
        } catch (e) {
          reject(xhr.statusText);
        }
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

function doGET(path) {
  return new Promise(function (resolve, reject) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', encodeURI(path));
    xhr.onload = function () {
      if (xhr.status === 200) {
        var datas = JSON.parse(xhr.responseText);
        resolve(datas);
      } else {
        reject(xhr.statusText);
      }
    };
    xhr.send();
  });
}

function doPOST(path, datas) {
  return reqData(path, datas, 'POST');
}

function doPUT(path, datas) {
  return reqData(path, datas, 'PUT');
}

function doDELETE(path, datas) {
  return reqData(path, datas, 'DELETE');
}

var API$1 = function () {
  function API(link) {
    classCallCheck(this, API);

    if (link) {
      this.db = link;
    } else {
      this.db = window.location.origin;
    }
  }

  API.prototype.userExists = function userExists(username, isHashed) {
    return this.retrieveUser(username, 'undefined', isHashed).then(function () {
      return true;
    }, function () {
      return false;
    });
  };

  API.prototype.addUser = function addUser(username, privateKey, publicKey, pass) {
    var _this = this;

    return getSHA256(username).then(function (hashedUsername) {
      return doPOST(_this.db + '/user/' + bytesToHexString(hashedUsername), {
        pass: pass,
        privateKey: privateKey,
        publicKey: publicKey,
        keys: {}
      });
    });
  };

  API.prototype.addSecret = function addSecret(user, secretObject) {
    var _this2 = this;

    return user.getToken(this).then(function (token) {
      return doPOST(_this2.db + '/user/' + secretObject.hashedUsername + '/' + secretObject.hashedTitle, {
        secret: secretObject.secret,
        iv: secretObject.iv,
        metadatas: secretObject.metadatas,
        iv_meta: secretObject.iv_meta,
        key: secretObject.wrappedKey,
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.deleteSecret = function deleteSecret(user, hashedTitle) {
    var _this3 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this3);
    }).then(function (token) {
      return doDELETE(_this3.db + '/user/' + hashedUsername + '/' + hashedTitle, {
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.getNewChallenge = function getNewChallenge(user) {
    var _this4 = this;

    return getSHA256(user.username).then(function (hashedUsername) {
      return doGET(_this4.db + '/challenge/' + bytesToHexString(hashedUsername));
    });
  };

  API.prototype.editSecret = function editSecret(user, secretObject, hashedTitle) {
    var _this5 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this5);
    }).then(function (token) {
      return doPOST(_this5.db + '/edit/' + hashedUsername + '/' + hashedTitle, {
        iv: secretObject.iv,
        secret: secretObject.secret,
        iv_meta: secretObject.iv_meta,
        metadatas: secretObject.metadatas,
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.newKey = function newKey(user, hashedTitle, secret, wrappedKeys) {
    var _this6 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this6);
    }).then(function (token) {
      return doPOST(_this6.db + '/newKey/' + hashedUsername + '/' + hashedTitle, {
        wrappedKeys: wrappedKeys,
        secret: secret,
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.unshareSecret = function unshareSecret(user, friendNames, hashedTitle) {
    var _this7 = this;

    var hashedUsername = void 0;
    var hashedFriendUsernames = [];
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      var hashedFriendUseramePromises = [];
      friendNames.forEach(function (username) {
        hashedFriendUseramePromises.push(getSHA256(username));
      });
      return Promise.all(hashedFriendUseramePromises);
    }).then(function (rHashedFriendUserames) {
      rHashedFriendUserames.forEach(function (hashedFriendUserame) {
        hashedFriendUsernames.push(bytesToHexString(hashedFriendUserame));
      });
      return user.getToken(_this7);
    }).then(function (token) {
      return doPOST(_this7.db + '/unshare/' + hashedUsername + '/' + hashedTitle, {
        friendNames: hashedFriendUsernames,
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.shareSecret = function shareSecret(user, sharedSecretObjects) {
    var _this8 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this8);
    }).then(function (token) {
      return doPOST(_this8.db + '/share/' + hashedUsername, {
        secretObjects: sharedSecretObjects,
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.retrieveUser = function retrieveUser(username, hash, hashed) {
    var _this9 = this;

    var isHashed = Promise.resolve();
    var hashedUsername = username;
    if (!hashed) {
      isHashed = isHashed.then(function () {
        return getSHA256(username);
      }).then(function (rHashedUsername) {
        hashedUsername = bytesToHexString(rHashedUsername);
        return;
      });
    }
    return isHashed.then(function () {
      return doGET(_this9.db + '/user/' + hashedUsername + '/' + hash);
    });
  };

  API.prototype.getDerivationParameters = function getDerivationParameters(username, isHashed) {
    return this.retrieveUser(username, 'undefined', isHashed).then(function (user) {
      return {
        totp: user.pass.totp,
        shortpass: user.pass.shortpass,
        salt: user.pass.salt,
        iterations: user.pass.iterations
      };
    });
  };

  API.prototype.getPublicKey = function getPublicKey(username, isHashed) {
    return this.retrieveUser(username, 'undefined', isHashed).then(function (user) {
      return user.publicKey;
    });
  };

  API.prototype.getUser = function getUser(username, hash, otp) {
    var _this10 = this;

    return getSHA256(username).then(function (hashedUsername) {
      return doGET(_this10.db + '/user/' + bytesToHexString(hashedUsername) + '/' + hash + '?otp=' + otp);
    });
  };

  API.prototype.getUserWithToken = function getUserWithToken(user) {
    var _this11 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this11);
    }).then(function (token) {
      return doGET(_this11.db + '/user/' + hashedUsername + '?token=' + bytesToHexString(token));
    });
  };

  API.prototype.getSecret = function getSecret(hashedTitle, user) {
    var _this12 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this12);
    }).then(function (token) {
      var uri = _this12.db + '/secret/';
      uri += hashedTitle + '?name=' + hashedUsername + '&token=';
      uri += '' + bytesToHexString(token);
      return doGET(uri);
    });
  };

  API.prototype.getProtectKey = function getProtectKey(username, deviceName, hash) {
    var _this13 = this;

    var hashedUsername = void 0;
    return getSHA256(username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return getSHA256(deviceName);
    }).then(function (deviceId) {
      return doGET(_this13.db + '/protectKey/' + hashedUsername + '/' + bytesToHexString(deviceId) + '/' + hash);
    }).then(function (result) {
      if (hash === 'undefined') {
        return result;
      }
      return result.protectKey;
    });
  };

  API.prototype.getProtectKeyParameters = function getProtectKeyParameters(username, deviceName) {
    return this.getProtectKey(username, deviceName, 'undefined');
  };

  API.prototype.getDb = function getDb(user) {
    var _this14 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this14);
    }).then(function (token) {
      return doGET(_this14.db + '/database/' + hashedUsername + '?token=' + bytesToHexString(token));
    });
  };

  API.prototype.changePassword = function changePassword(user, privateKey, pass) {
    var _this15 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this15);
    }).then(function (token) {
      return doPUT(_this15.db + '/user/' + hashedUsername, {
        pass: pass,
        privateKey: privateKey,
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.testTotp = function testTotp(seed, token) {
    return doGET(this.db + '/totp/' + seed + '/' + token);
  };

  API.prototype.activateTotp = function activateTotp(seed, user) {
    var _this16 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this16);
    }).then(function (token) {
      return doPUT(_this16.db + '/activateTotp/' + hashedUsername, {
        seed: seed,
        token: bytesToHexString(token)
      });
    });
  };

  API.prototype.activateShortpass = function activateShortpass(shortpass, user) {
    var _this17 = this;

    var hashedUsername = void 0;
    return getSHA256(user.username).then(function (rHashedUsername) {
      hashedUsername = bytesToHexString(rHashedUsername);
      return user.getToken(_this17);
    }).then(function (token) {
      return doPUT(_this17.db + '/activateShortpass/' + hashedUsername, {
        shortpass: shortpass,
        token: bytesToHexString(token)
      });
    });
  };

  return API;
}();

Secretin.version = version;
Secretin.User = User;
Secretin.generateSeed = generateSeed;
Secretin.API = {
  Standalone: API,
  Server: API$1
};

return Secretin;

}());