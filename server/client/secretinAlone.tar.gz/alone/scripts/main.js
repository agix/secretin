document.addEventListener("DOMContentLoaded", function() {

document.getElementById('newUser').addEventListener('click', function(e) {
  var btn = e.target;
  var username = document.getElementById('newUsername').value;
  var password = document.getElementById('newPassword').value;
  api.userExists(username).then(function(exists){
    if(!exists){
      var result = {};
      var pass = {};
      currentUser = new User(username);
      btn.disabled = true;
      btn.value = 'Please wait...';
      currentUser.generateMasterKey().then(function(){
        return derivePassword(password);
      }).then(function(dKey){
        pass.salt = bytesToHexString(dKey.salt);
        pass.hash = bytesToHexString(dKey.hash);
        currentUser.hash = pass.hash;
        return currentUser.exportPrivateKey(dKey.key);
      }).then(function(privateKey){
        result.privateKey = privateKey;
        return currentUser.exportPublicKey();
      }).then(function(publicKey){
        result.publicKey = publicKey;
        return api.addUser(currentUser.username, result.privateKey, result.publicKey, pass);
      }).then(function(msg){
        document.location.href = '#keys';
        btn.disabled = false;
        btn.value = 'Generate';
        document.getElementById('newUsername').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('userTitle').textContent = currentUser.username+'\'s secrets';
        document.getElementById('secrets').style.display = '';
        document.getElementById('login').style.display = 'none';
        document.getElementById('deco').style.display = '';
        setTimeout(function(){ getSecretList(currentUser); }, 1000);
      }, function(err){
        btn.disabled = false;
        btn.value = 'Generate';
        error(document.getElementById('errorNew'), err);
        throw(err);
      });
    }
    else{
      error(document.getElementById('errorNew'), 'Username already exists');
    }
  });
});

document.getElementById('getKeys').addEventListener('click', function(e){
  var btn = e.target;
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;
  var remoteUser;
  var key;
  var hash;
  btn.disabled = true;
  btn.value = 'Please wait...';
  api.getSalt(username).then(function(salt){
    return derivePassword(password, salt);
  }).then(function(dKey){
    key = dKey.key;
    hash = bytesToHexString(dKey.hash);
    return api.getUser(username, hash);
  }).then(function(user){
    currentUser = new User(username);
    remoteUser = user;
    currentUser.keys = remoteUser.keys;
    currentUser.hash = hash;
    return currentUser.importPublicKey(remoteUser.publicKey);
  }).then(function(){
    return currentUser.importPrivateKey(key, remoteUser.privateKey);
  }).then(function(){
    btn.disabled = false;
    btn.value = 'Get keys';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('userTitle').textContent = currentUser.username+'\'s secrets';
    document.getElementById('secrets').style.display = '';
    document.getElementById('login').style.display = 'none';
    document.getElementById('deco').style.display = '';
    getSecretList(currentUser);
  }, function(err){
    btn.disabled = false;
    btn.value = 'Get keys';
    error(document.getElementById('errorLogin'), err);
    throw(err);
  });
});

document.getElementById('addSecret').addEventListener('click', function(e){
  if(typeof(currentUser.username) === 'string'){
    var title   = document.getElementById('secretTitle').value;
    var content = document.getElementById('secretContent').value;
    currentUser.createSecret(title, content).then(function(secretObject){
      return api.addSecret(currentUser, secretObject);
    }).then(function(msg){
      document.getElementById('secretTitle').value = '';
      document.getElementById('secretContent').value = '';
      document.location.href = '#keys';
      return api.getKeys(currentUser.username, currentUser.hash);
    }).then(function(keys){
      currentUser.keys = keys;
      getSecretList(currentUser);
    }, function(err){
      alert(err);
      throw(err);
    });
  }
  else{
    document.location.hash = '#keys';
    error(document.getElementById('errorLogin'), 'You are disconnected');
  }

});

document.getElementById('changePasswordBtn').addEventListener('click', function(e) {
  var btn = e.target;
  var password = document.getElementById('changePasswordInput').value;
  var pass = {};
  btn.disabled = true;
  btn.value = 'Please wait...';
  derivePassword(password).then(function(dKey){
    pass.salt = bytesToHexString(dKey.salt);
    pass.hash = bytesToHexString(dKey.hash);
    return currentUser.exportPrivateKey(dKey.key);
  }).then(function(privateKey){
    return api.changePassword(currentUser, privateKey, pass);
  }).then(function(msg){
    btn.disabled = false;
    btn.value = 'Change password';
    document.getElementById('changePasswordInput').value = '';
    document.location.href = '#keys';
  }, function(err){
    btn.disabled = false;
    btn.value = 'Change password';
    alert(err);
    throw(err);
  });
});

var timeout;

window.addEventListener('focus', function() {
  clearInterval(timeout);
});

window.addEventListener('blur', function() {
  timeout = setTimeout(function() { destroyUser(currentUser); currentUser = {}; }, 60000);
});

document.getElementById('deco').addEventListener('click', function(e){
  destroyUser(currentUser);
  currentUser = {};
});

document.getElementById('hideSecret').addEventListener('click', function(e){
  document.getElementById('showSecretTitle').textContent = '';
  document.getElementById('showSecretContent').value = '';
  document.location.href = '#keys';
});

document.getElementById('closeEditSecret').addEventListener('click', function(e){
  document.getElementById('editSecretTitle').textContent = '';
  document.getElementById('editSecretContent').value = '';
  document.getElementById('editSecretHash').value = '';
  document.location.href = '#keys';
});

document.getElementById('closeShareSecret').addEventListener('click', function(e){
  document.getElementById('shareSecretTitle').textContent = '';
  document.getElementById('shareSecretHash').value = '';
  var sharedUsersList = document.getElementById('sharedUsers');
  while (sharedUsersList.firstChild) {
    sharedUsersList.removeChild(sharedUsersList.firstChild);
  }
  document.location.href = '#keys';
});

document.getElementById('saveSecret').addEventListener('click', function(e){
  var hashedTitle = document.getElementById('editSecretHash').value;
  var content = document.getElementById('editSecretContent').value;
  currentUser.editSecret(content, currentUser.keys[hashedTitle].key).then(function(secretObject){
      return api.editSecret(currentUser, secretObject, hashedTitle);
  }).then(function(){
    alert('Secret saved');
  }, function(err){
    alert(err);
    throw(err);
  });
});

document.getElementById('share').addEventListener('click', function(e){
  var hashedTitle = document.getElementById('shareSecretHash').value;
  var encryptedSecret;
  var friend;
  var rights;
  api.getSecret(hashedTitle).then(function(eSecret){
    encryptedSecret = eSecret;
    var friendName = document.getElementById('friendName').value;
    rights = document.getElementById('rights').value;
    friend = new User(friendName);
    e.target.disabled = true;
    e.target.value = 'Please wait...';
    return api.getPublicKey(friend.username);
  }).then(function(publicKey){
    return friend.importPublicKey(publicKey);
  }).then(function(){
    return currentUser.shareSecret(friend, currentUser.keys[hashedTitle].key, hashedTitle);
  }).then(function(sharedSecretObject){
    return api.shareSecret(currentUser, sharedSecretObject, hashedTitle, rights);
  }).then(function(){
    e.target.disabled = false;
    e.target.value = 'Share';
    document.getElementById('friendName').value='';
    var sharedUsersList = document.getElementById('sharedUsers');
    while (sharedUsersList.firstChild) {
      sharedUsersList.removeChild(sharedUsersList.firstChild);
    }
    share(false, hashedTitle, document.getElementById('shareSecretTitle').textContent);
  }, function(err){
    e.target.disabled = false;
    e.target.value = 'Share';
    document.getElementById('friendName').value='';
    error(document.getElementById('errorShareSecret'), err);
    throw(err);
  });
});

document.getElementById('refresh').addEventListener('click', function(e){
  document.getElementById('search').value = '';
  api.getKeys(currentUser.username, currentUser.hash).then(function(keys){
    currentUser.keys = keys;
    getSecretList(currentUser);
  }, function(err){
    alert(err);
    throw(err);
  });
});

document.getElementById('search').addEventListener('keyup', function(e){
  var elems = document.querySelectorAll('.secretElem');
  for (var i = 0; i < elems.length; i++) {
    if(e.target.value.length > 2 && elems[i].children[1].textContent.toLowerCase().indexOf(e.target.value.toLowerCase()) === -1){
      elems[i].style.display = 'none';
    }
    else{
      elems[i].style.display = '';
    }
  }
});

document.getElementById('password').addEventListener('keypress', function(e){
  if(e.keyCode === 13){
    document.getElementById('getKeys').click();
  }
});

function error(elem, text){
  elem.textContent = 'Error: ' + text;
  elem.style.display = '';
  setTimeout(function(){ cleanError(elem); }, 3000);
}

function cleanError(elem){
  elem.textContent = '';
  elem.style.display = 'none';
}

function destroyUser(user){
  var secretsList = document.getElementById('secretsList');
  var oldElems = document.querySelectorAll('.secretElem');
  for (var i = 0; i < oldElems.length; i++) {
    secretsList.removeChild(oldElems[i]);
  }
  document.getElementById('userTitle').textContent = 'Not connected';
  document.getElementById('search').value = '';
  document.getElementById('secrets').style.display = 'none';
  document.getElementById('login').style.display = '';
  document.getElementById('deco').style.display = 'none';
  user.disconnect();
}

function unshare(e){
  var hashedTitle = document.getElementById('shareSecretHash').value;
  var unfriend;
  var friendName = e.path[1].children[0].textContent;
  var encryptedSecret;
  var secret = {};
  var wrappedKeys = [];
  var friend;
  e.target.disabled = true;
  e.target.value = 'Please wait...';
  api.unshareSecret(currentUser, friendName, hashedTitle, friendName).then(function(){
    return api.getSecret(hashedTitle);
  }).then(function(eSecret){
      encryptedSecret = eSecret;
      return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
  }).then(function(secret){
      return currentUser.encryptSecret(secret);
  }).then(function(secretObject){
    secret.secret = bytesToHexString(secretObject.secret);
    secret.iv = bytesToHexString(secretObject.iv);
    encryptedSecret.users.forEach(function(hashedUsername){
      api.getPublicKey(hashedUsername, true).then(function(publicKey){
        friend = new User(hashedUsername);
        return friend.importPublicKey(publicKey);
      }).then(function(){
        return currentUser.wrapKey(secretObject.key, friend.publicKey);
      }).then(function(friendWrappedKey){
        wrappedKeys.push({user: hashedUsername, key: friendWrappedKey });
        if(wrappedKeys.length === encryptedSecret.users.length){
          api.newKey(currentUser, hashedTitle, secret, wrappedKeys);

          var sharedUsersList = document.getElementById('sharedUsers');
          while (sharedUsersList.firstChild) {
            sharedUsersList.removeChild(sharedUsersList.firstChild);
          }
          share(false, hashedTitle, document.getElementById('shareSecretTitle').textContent);
        }
      });
    });
  }, function(err){
    e.target.disabled = false;
    e.target.value = 'Unshare';
    error(document.getElementById('errorShareSecret'), err);
    throw(err);
  });

}

function share(e, hashedTitle, title){
  if(typeof(hashedTitle) === 'undefined'){
    hashedTitle  = e.path[1].children[0].textContent;
  }
  if(typeof(title) === 'undefined'){
    title  = e.path[1].children[1].textContent;
  }
  document.getElementById('shareSecretHash').value = hashedTitle;
  document.getElementById('shareSecretTitle').textContent = title;
  document.location.hash = '#shareSecret';
  var sharedUsersList = document.getElementById('sharedUsers');
  api.getSecret(hashedTitle).then(function(encryptedSecret){
    encryptedSecret.users.forEach(function(userHash){
      sharedUsersList.appendChild(uiSharedUsers(userHash));
    });
  });
}

function show(e){
  var hashedTitle  = e.path[1].children[0].textContent;
  var title  = e.path[1].children[1].textContent;
  var btn   = e.target;
  api.getSecret(hashedTitle).then(function(encryptedSecret){
    return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
  }).then(function(secret){
    document.getElementById('showSecretTitle').textContent = title;
    document.getElementById('showSecretContent').value = secret;
    document.location.hash = '#showSecret';
  });
}

function editSecret(e){
  var hashedTitle = e.path[1].children[0].textContent;
  var title  = e.path[1].children[1].textContent;

  api.getSecret(hashedTitle).then(function(encryptedSecret){
    return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
  }).then(function(secret){
    document.getElementById('editSecretHash').value = hashedTitle;
    document.getElementById('editSecretTitle').textContent = title;
    document.getElementById('editSecretContent').value = secret;
    document.location.hash = '#editSecret';
  });
}

function deleteSecret(e){
  var title       = e.path[1].children[1].textContent;
  var hashedTitle = e.path[1].children[0].textContent;
  var sure = confirm('Are you sure to delete ' + title + '?');
  if(sure){
    api.deleteSecret(currentUser, hashedTitle).then(function(){
      return api.getKeys(currentUser.username, currentUser.hash);
    }).then(function(keys){
      currentUser.keys = keys;
      getSecretList(currentUser);
    }, function(err){
      alert(err);
      throw(err);
    });
  }
}

function uiSharedUsers(userHash){
  var elem = document.createElement('li');
  elem.classList.add('sharedUserElem');

  var userHashSpan = document.createElement('span');
  userHashSpan.textContent = userHash;

  var unshareBtn = document.createElement('input');
  unshareBtn.type = 'button';
  unshareBtn.value = 'Unshare';
  unshareBtn.addEventListener('click', unshare);

  elem.appendChild(userHashSpan);
  elem.appendChild(unshareBtn);
  return elem;
}

function uiSecret(hashedTitle, title){
  var elem = document.createElement('li');
  elem.classList.add('secretElem');

  var btn = document.createElement('input');
  btn.type = 'button';
  btn.value = 'Show';
  btn.addEventListener('click', show);

  var shareBtn = document.createElement('input');
  shareBtn.type = 'button';
  shareBtn.value = 'Share';
  shareBtn.addEventListener('click', share);

  var editBtn = document.createElement('input');
  editBtn.type = 'button';
  editBtn.value = 'Edit';
  editBtn.addEventListener('click', editSecret);

  var deleteBtn = document.createElement('input');
  deleteBtn.type = 'button';
  deleteBtn.value = 'Delete';
  deleteBtn.addEventListener('click', deleteSecret);

  var titleSpan = document.createElement('span');
  titleSpan.textContent = title.substring(14);

  var br = document.createElement('br');

  var hashSpan = document.createElement('span');
  hashSpan.textContent = hashedTitle;
  hashSpan.style.display = 'none';

  elem.appendChild(hashSpan);
  elem.appendChild(titleSpan);
  elem.appendChild(br);
  elem.appendChild(btn);

  if(currentUser.keys[hashedTitle].rights > 0){
    elem.appendChild(editBtn);
  }
  if(currentUser.keys[hashedTitle].rights > 1){
    elem.appendChild(shareBtn);
  }
  elem.appendChild(deleteBtn);

  return elem;
}

function getSecretList(){
  var secretsList = document.getElementById('secretsList');
  var oldElems = document.querySelectorAll('.secretElem');
  for (var i = 0; i < oldElems.length; i++) {
    secretsList.removeChild(oldElems[i]);
  }
  currentUser.decryptTitles().then(function(){
    Object.keys(currentUser.titles).forEach(function(hashedTitle){
      secretsList.appendChild(uiSecret(hashedTitle, currentUser.titles[hashedTitle]));
    });
  });
}



// ###################### User.js ######################

var User = function(username) {
  var _this = this;
  _this.username    = username;
  _this.hash        = null;
  _this.publicKey   = null;
  _this.privateKey  = null;
  _this.keys        = {};
  _this.titles      = {};
  _this.token       = {value: '', time: 0};
};

User.prototype.disconnect = function(){
  var _this = this;
  delete _this.username;
  delete _this.hash;
  delete _this.publicKey;
  delete _this.privateKey;
  delete _this.titles;
  delete _this.keys;
  delete _this.token;
};

User.prototype.isTokenValid = function(){
  var _this = this;
  return (_this.token.time > Date.now-10);
};

User.prototype.getToken = function(api){
  var _this = this;
  if(_this.isTokenValid()){
    return _this.token.value;
  }
  else{
    return api.getNewChallenge(_this).then(function(challenge){
      _this.token.time  = challenge.time;
      _this.token.value = decryptRSAOAEP(challenge.value, _this.privateKey);
      return _this.token.value;
    });
  }
};

User.prototype.generateMasterKey = function(){
  var _this = this;
  return genRSAOAEP().then(function(keyPair) {
    _this.publicKey  = keyPair.publicKey;
    _this.privateKey = keyPair.privateKey;
  });
};

User.prototype.exportPublicKey = function(){
  var _this = this;
  return exportPublicKey(_this.publicKey);
};

User.prototype.importPublicKey = function(jwkPublicKey){
  var _this = this;
  return importPublicKey(jwkPublicKey).then(function(publicKey){
    _this.publicKey = publicKey;
  });
};

User.prototype.exportPrivateKey = function(dKey){
  var _this = this;
  return exportPrivateKey(dKey, _this.privateKey).then(function(privateKeyObject){
    return {
      privateKey: bytesToHexString(privateKeyObject.privateKey),
      iv: bytesToHexString(privateKeyObject.iv)
    };
  });
};

User.prototype.importPrivateKey = function(dKey, privateKeyObject){
  var _this = this;
  return importPrivateKey(dKey, privateKeyObject).then(function(privateKey){
    _this.privateKey = privateKey;
  });
};

User.prototype.encryptTitle = function(title, publicKey){
  var _this = this;
  return encryptRSAOAEP(title, publicKey).then(function(encryptedTitle){
    return bytesToHexString(encryptedTitle);
  });
};

User.prototype.shareSecret = function(friend, wrappedKey, hashedTitle){
  var _this = this;
  var result = {};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return _this.wrapKey(key, friend.publicKey);
  }).then(function(friendWrappedKey){
    result.wrappedKey = friendWrappedKey;
    return _this.encryptTitle(_this.titles[hashedTitle], friend.publicKey);
  }).then(function(encryptedTitle){
    result.encryptedTitle = encryptedTitle;
    return SHA256(friend.username);
  }).then(function(hashedUsername){
    result.friendName = bytesToHexString(hashedUsername);
    return result;
  });
};

User.prototype.editSecret = function(secret, wrappedKey){
  var _this = this;
  var result = {};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return encryptAESGCM256(secret, key);
  }).then(function(secretObject){
    result.secret = bytesToHexString(secretObject.secret);
    result.iv = bytesToHexString(secretObject.iv);
    return result;
  });
};

User.prototype.createSecret = function(title, secret){
  var _this = this;
  var now = Date.now();
  var saltedTitle = now+'|'+title;
  var result = {};
  return _this.encryptSecret(secret).then(function(secretObject){
    result.secret = bytesToHexString(secretObject.secret);
    result.iv = bytesToHexString(secretObject.iv);
    return _this.wrapKey(secretObject.key, _this.publicKey);
  }).then(function(wrappedKey){
    result.wrappedKey = wrappedKey;
    return _this.encryptTitle(saltedTitle, _this.publicKey);
  }).then(function(encryptedTitle){
    result.encryptedTitle = encryptedTitle;
    return SHA256(_this.username);
  }).then(function(hashedUsername){
    result.hashedUsername = bytesToHexString(hashedUsername);
    return SHA256(saltedTitle);
  }).then(function(hashedTitle){
    result.hashedTitle = bytesToHexString(hashedTitle);
    return result;
  });
};

User.prototype.encryptSecret = function(secret){
  var _this = this;
  return encryptAESGCM256(secret);
};

User.prototype.decryptSecret = function(secret, wrappedKey){
  var _this = this;
  return _this.unwrapKey(wrappedKey).then(function(key){
    return decryptAESGCM256(secret, key);
  }).then(function(decryptedSecret){
    return bytesToASCIIString(decryptedSecret);
  });
};

User.prototype.unwrapKey = function(wrappedKey){
  var _this = this;
  return unwrapRSAOAEP(wrappedKey, _this.privateKey);
};

User.prototype.wrapKey = function(key, publicKey){
  var _this = this;
  return wrapRSAOAEP(key, publicKey).then(function(wrappedKey){
    return bytesToHexString(wrappedKey);
  });
};

User.prototype.decryptTitles = function(){
  var _this = this;
  return new Promise(function(resolve, reject){
    var hashedTitles = Object.keys(_this.keys);
    hashedTitles.forEach(function(hashedTitle){
      _this.titles = {};
      decryptRSAOAEP(_this.keys[hashedTitle].title, _this.privateKey).then(function(title){
        _this.titles[hashedTitle] = bytesToASCIIString(title);
        if(Object.keys(_this.titles).length === hashedTitles.length){
          resolve();
        }
      });
    });
  });
};

// ###################### API.js ######################

var OPTIONAL_SALT = '';

var API = function(link) {
  if(typeof link === 'object'){
    this.db = link;
  }
  else{
    this.db = {"users":{}, "secrets": {}};
  }
  this.textarea = document.getElementById('db');
};

API.prototype.userExists = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return true;
  }).catch(function(err){
    return false;
  });
};

API.prototype.addUser = function(username, privateKey, publicKey, pass){
  var _this = this;
  var hashedUsername;
  return SHA256(username).then(function(hashedUsernameR){
    hashedUsername = hashedUsernameR;
    if(typeof _this.db.users[bytesToHexString(hashedUsername)] === 'undefined'){
      return SHA256(pass.hash+OPTIONAL_SALT).then(function(hashedHash){
        pass.hash = bytesToHexString(hashedHash);
        _this.db.users[bytesToHexString(hashedUsername)] = {pass: pass, privateKey: privateKey, publicKey: publicKey, keys: {}};
        _this.textarea.value = JSON.stringify(_this.db);
      });
    }
    else{
      throw('User already exists');
    }
  });
};

API.prototype.addSecret = function(user, secretObject){
  var _this = this;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    if(typeof _this.db.users[secretObject.hashedUsername] !== 'undefined'){
      if(typeof _this.db.secrets[secretObject.hashedTitle] === 'undefined'){
        _this.db.secrets[secretObject.hashedTitle] = {
          secret: secretObject.secret,
          iv: secretObject.iv,
          users: [secretObject.hashedUsername]
        }
        _this.db.users[secretObject.hashedUsername].keys[secretObject.hashedTitle] = {
          title: secretObject.encryptedTitle,
          key: secretObject.wrappedKey,
          rights: 2
        }
        _this.textarea.value = JSON.stringify(_this.db);
      }
      else{
        throw('Secret already exists');
      }
    }
    else{
      throw('User not found');
    }
  });
}

API.prototype.deleteSecret = function(user, hashedTitle){
  var _this = this;
  var hashdeUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    if(typeof _this.db.users[hashedUsername] !== 'undefined'){
      if(typeof _this.db.secrets[hashedTitle] !== 'undefined'){
        delete _this.db.users[hashedUsername].keys[hashedTitle];
        var index = _this.db.secrets[hashedTitle].users.indexOf(hashedUsername);
        if (index > -1) {
          _this.db.secrets[hashedTitle].users.splice(index, 1);
        }
        if(_this.db.secrets[hashedTitle].users.length === 0){
          delete _this.db.secrets[hashedTitle];
        }
        _this.textarea.value = JSON.stringify(_this.db);
      }
      else{
        throw('Secret not found');
      }
    }
    else{
      throw('User not found');
    }
  });
};

API.prototype.getNewChallenge = function(user){
  var _this = this;
  return SHA256(username).then(function(hashedUsername){
    var rawChallenge = new Uint8Array(32);
    crypto.getRandomValues(rawChallenge);
    var challenge = bytesToASCIIString(rawChallenge);
    return encryptRSAOAEP(challenge, user.publicKey);
  }).then(function(encryptedChallenge){
    return {time: Date.now().toString(), value: bytesToHexString(encryptedChallenge)};
  });
};

API.prototype.editSecret = function(user, secretObject, hashedTitle){
  var _this = this;
  var hashdeUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    if(typeof _this.db.users[hashedUsername] !== 'undefined'){
      if(typeof _this.db.secrets[hashedTitle] !== 'undefined'){
        _this.db.secrets[hashedTitle].iv = secretObject.iv;
        _this.db.secrets[hashedTitle].secret = secretObject.secret;
        _this.textarea.value = JSON.stringify(_this.db);
      }
      else{
        throw('Secret not found');
      }
    }
    else{
      throw('User not found');
    }
  });
};

API.prototype.newKey = function(user, hashedTitle, secret, wrappedKeys){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    if(typeof _this.db.users[hashedUsername] !== 'undefined'){
      if(typeof _this.db.secrets[hashedTitle] !== 'undefined'){
        wrappedKeys.forEach(function(wrappedKey){
          if(typeof _this.db.users[wrappedKey.user] !== 'undefined'){
            if(typeof _this.db.users[wrappedKey.user].keys[hashedTitle] !== 'undefined'){
              _this.db.users[wrappedKey.user].keys[hashedTitle].key = wrappedKey.key;
              _this.textarea.value = JSON.stringify(_this.db);
            }
          }
        });
      }
      else{
        throw('Secret not found');
      }
    }
    else{
      throw('User not found');
    }
  });
};


API.prototype.unshareSecret = function(user, friendName, hashedTitle, hashedFriendUsername){
  var _this = this;
  var hashedUsername;
  var hashedFriendUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return SHA256(friendName);
  }).then(function(rHashedFriendUsername){
    if(typeof(hashedFriendUsername) === 'undefined'){
      hashedFriendUsername = bytesToHexString(rHashedFriendUsername);
    }
    return user.getToken(_this);
  }).then(function(token){
    if(hashedUsername !== hashedFriendUsername){
      if(typeof _this.db.users[hashedUsername] !== 'undefined'){
        if(typeof _this.db.secrets[hashedTitle] !== 'undefined'){
          if(typeof _this.db.users[hashedFriendUsername] !== 'undefined'){
            if(typeof _this.db.users[hashedFriendUsername].keys[hashedTitle] !== 'undefined'){
              delete _this.db.users[hashedFriendUsername].keys[hashedTitle];
              var id = _this.db.secrets[hashedTitle].users.indexOf(hashedFriendUsername);
              _this.db.secrets[hashedTitle].users.splice(id, 1);
              _this.textarea.value = JSON.stringify(_this.db);
            }
            else{
              throw('You didn\'t share this secret with this friend');
            }
          }
          else{
            throw('Friend not found');
          }
        }
        else{
          throw('Secret not found');
        }
      }
      else{
        throw('User not found');
      }
    }
    else{
      throw('You can\'t unshare with youself');
    }
  });
};

API.prototype.shareSecret = function(user, sharedSecretObject, hashedTitle, rights){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    if(typeof _this.db.users[hashedUsername] !== 'undefined'){
      if(typeof _this.db.secrets[hashedTitle] !== 'undefined'){
        if(typeof _this.db.users[sharedSecretObject.friendName] !== 'undefined'){
          _this.db.users[sharedSecretObject.friendName].keys[hashedTitle] = {
            title: sharedSecretObject.encryptedTitle,
            key: sharedSecretObject.wrappedKey,
            rights: rights
          }
          if(_this.db.secrets[hashedTitle].users.indexOf(sharedSecretObject.friendName) < 0){
            _this.db.secrets[hashedTitle].users.push(sharedSecretObject.friendName);
          }
          _this.textarea.value = JSON.stringify(_this.db);
        }
        else{
          throw('Friend not found');
        }
      }
      else{
        throw('Secret not found');
      }
    }
    else{
      throw('User not found');
    }
  });
};

API.prototype.retrieveUser = function(username, hash, isHashed){
  var _this = this;
  var hashedUsername;
  var user;
  return new Promise(function(resolve, reject){
    if(isHashed){
      resolve(username);
    }
    else{
      SHA256(username).then(function(hashedUsernameR){
        resolve(bytesToHexString(hashedUsernameR))
      });
    }
  }).then(function(hashedUsernameR){
    hashedUsername = hashedUsernameR;
    if(typeof _this.db.users[hashedUsername] === 'undefined'){
      throw 'User not found';
    }
    else{
      user = JSON.parse(JSON.stringify(_this.db.users[hashedUsername]));
      return SHA256(hash + OPTIONAL_SALT);
    }
  }).then(function(hashedHash){
    if(bytesToHexString(hashedHash) === user.pass.hash){
      return user;
    }
    else{
      var fakePrivateKey = new Uint8Array(3232);
      var fakeIV = new Uint8Array(16);
      crypto.getRandomValues(fakePrivateKey);
      crypto.getRandomValues(fakeIV);
      user.privateKey = {
        privateKey: bytesToHexString(fakePrivateKey),
        iv: bytesToHexString(fakeIV),
      };
      user.keys = {};
      return user;
    }
  }, function(err){
    throw(err);
  });
};

API.prototype.getSalt = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return user.pass.salt;
  });
};

API.prototype.getWrappedPrivateKey = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.privateKey;
  });
};

API.prototype.getPublicKey = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return user.publicKey;
  });
};

API.prototype.getKeys = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.keys;
  });
};

API.prototype.getUser = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user;
  });
};

API.prototype.getSecret = function(hash){
  var _this = this;
  return new Promise(function(resolve, reject){
    if(typeof _this.db.secrets[hash] === 'undefined'){
      reject('Invalid secret')
    }
    else{
      resolve(_this.db.secrets[hash])
    }
  });
};

API.prototype.changePassword = function(user, privateKey, pass){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    if(typeof _this.db.users[hashedUsername] !== 'undefined'){
      return SHA256(pass.hash+OPTIONAL_SALT).then(function(hashedHash){
        user.hash = pass.hash;
        pass.hash = bytesToHexString(hashedHash);
        _this.db.users[hashedUsername].privateKey = privateKey;
        _this.db.users[hashedUsername].pass = pass;
        _this.textarea.value = JSON.stringify(_this.db);
      });
    }
    else{
      throw('User not found');
    }
  });
};
if(typeof(crypto) === 'undefined'){
    crypto = msCrypto;
}
if(typeof(crypto.subtle) === 'undefined'){
    crypto.subtle = crypto.webkitSubtle;
}
// ###################### crypto.js ######################

function SHA256(str){
  var algorithm = 'SHA-256';
  var data = asciiToUint8Array(str);
  return crypto.subtle.digest(algorithm, data);
}

function genRSAOAEP(){
  var algorithm = {
    name: 'RSA-OAEP',
    modulusLength: 4096,
    publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
    hash: {name: 'SHA-256'}
  };
  var extractable = true;
  var keyUsages = [
    'wrapKey',
    'unwrapKey',
    'encrypt',
    'decrypt'
  ];
  return crypto.subtle.generateKey(algorithm, extractable, keyUsages);
}


function encryptAESGCM256(secret, key){
  var result = {};
  var algorithm = {};
  if(typeof key === 'undefined'){
    algorithm = {
      name: 'AES-GCM',
      length: 256
    };
    var extractable = true;
    var keyUsages = [
      'encrypt'
    ];
    return crypto.subtle.generateKey(algorithm, extractable, keyUsages).then(function(key){
      var iv = new Uint8Array(12);
      crypto.getRandomValues(iv);
      algorithm = {
        name: 'AES-GCM',
        iv: iv,
        tagLength: 128
      };
      var data = asciiToUint8Array(secret);
      result.key = key;
      result.iv = iv;
      return crypto.subtle.encrypt(algorithm, key, data);
    }).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
  else{
    result.key = key;
    var iv = new Uint8Array(12);
    crypto.getRandomValues(iv);
    algorithm = {
      name: 'AES-GCM',
      iv: iv,
      tagLength: 128
    };
    var data = asciiToUint8Array(secret);
    result.iv = iv;
    return crypto.subtle.encrypt(algorithm, key, data).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
}

function decryptAESGCM256(secretObject, key){
  var algorithm = {
    name: 'AES-GCM',
    iv: hexStringToUint8Array(secretObject.iv),
    tagLength: 128
  };
  var data = hexStringToUint8Array(secretObject.secret);
  return crypto.subtle.decrypt(algorithm, key, data);
}

function encryptRSAOAEP(secret, publicKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = asciiToUint8Array(secret);
  return crypto.subtle.encrypt(algorithm, publicKey, data);
}

function decryptRSAOAEP(secret, privateKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = hexStringToUint8Array(secret);
  return crypto.subtle.decrypt(algorithm, privateKey, data);
}

function wrapRSAOAEP(key, wrappingPublicKey){
  var format = 'raw';
  var wrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  return crypto.subtle.wrapKey(format, key, wrappingPublicKey, wrapAlgorithm);
}

function unwrapRSAOAEP(wrappedKeyHex, unwrappingPrivateKey){
  var format = 'raw';
  var wrappedKey = hexStringToUint8Array(wrappedKeyHex);
  var unwrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var unwrappedKeyAlgorithm  = {
    name: 'AES-GCM',
    length: 256
  };
  var extractable = true;
  var usages = ['decrypt', 'encrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedKey, unwrappingPrivateKey, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, usages
  );
}

function exportPublicKey(publicKey){
  var format = 'jwk';
  return crypto.subtle.exportKey(format, publicKey);
}

function importPublicKey(jwkPublicKey){
  var format = 'jwk';
  var algorithm = {
    name: "RSA-OAEP",
    hash: {name: "SHA-256"}
  };
  var extractable = false;
  var keyUsages = [
    'wrapKey', 'encrypt'
  ];
  return crypto.subtle.importKey(format, jwkPublicKey, algorithm, extractable, keyUsages);
}

function derivePassword(password, salt){
  var result = {};

  var passwordBuf = asciiToUint8Array(password);
  var extractable = false;
  var usages = ['deriveKey', 'deriveBits'];

  return crypto.subtle.importKey(
    'raw', passwordBuf, {name: 'PBKDF2'}, extractable, usages
  ).then(function(key){

    var saltBuf;
    if(typeof salt === 'undefined'){
      saltBuf = new Uint8Array(32);
      crypto.getRandomValues(saltBuf);
    }
    else{
      saltBuf = hexStringToUint8Array(salt);
    }

    result.salt = saltBuf;

    var algorithm = {
      name: "PBKDF2",
      salt: saltBuf,
      iterations: 10000,
      hash: {name: "SHA-256"}
    };

    var deriveKeyAlgorithm = {
      name: "AES-CBC",
      length: 256
    };

    extractable = true;
    usages = ['wrapKey', 'unwrapKey'];

    return crypto.subtle.deriveKey(algorithm, key, deriveKeyAlgorithm, extractable, usages);
  }).then(function(dKey){
    result.key = dKey;
    return crypto.subtle.exportKey('raw', dKey);
  }).then(function(rawKey){
    return crypto.subtle.digest('SHA-256', rawKey);
  }).then(function(hashedKey){
    result.hash = hashedKey;
    return result;
  });
}

function exportPrivateKey(key, privateKey){
  var result = {};
  var format = 'jwk';
  var iv = new Uint8Array(16);
  crypto.getRandomValues(iv);
  var wrapAlgorithm = {
    name: "AES-CBC",
    iv: iv
  };
  result.iv = iv;
  return crypto.subtle.wrapKey(
    format, privateKey, key, wrapAlgorithm
  ).then(function(wrappedPrivateKey){
    result.privateKey = wrappedPrivateKey;
    return result;
  });
}

function importPrivateKey(key, privateKeyObject){
  var format = 'jwk';
  var wrappedPrivateKey = hexStringToUint8Array(privateKeyObject.privateKey);
  var unwrapAlgorithm = {
    name: 'AES-CBC',
    iv: hexStringToUint8Array(privateKeyObject.iv)
  };
  var unwrappedKeyAlgorithm = {
    name: "RSA-OAEP",
    hash: {name: "sha-256"}
  };
  var extractable = true;
  var keyUsages = ['unwrapKey', 'decrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedPrivateKey, key, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, keyUsages
  ).then(function(privateKey){
    return privateKey;
  }).catch(function(err){
    throw('Invalid Password');
  });
}

// ###################### http.js ######################

function GET(path){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', encodeURI(path));
    xhr.onload = function() {
      if (xhr.status === 200) {
        var datas = JSON.parse(xhr.responseText);
        resolve(datas);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send();
  });
}

function POST(path, datas){
  return reqData(path, datas, 'POST');
}

function PUT(path, datas){
  return reqData(path, datas, 'PUT');
}

function reqData(path, datas, type){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open(type, encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

function DELETE(path, datas){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open('DELETE', encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

// ###################### util.js ######################

function hexStringToUint8Array(hexString){
  if (hexString.length % 2 !== 0){
    throw "Invalid hexString";
  }
  var arrayBuffer = new Uint8Array(hexString.length / 2);

  for (var i = 0; i < hexString.length; i += 2) {
    var byteValue = parseInt(hexString.substr(i, 2), 16);
    if (isNaN(byteValue)){
      throw "Invalid hexString";
    }
    arrayBuffer[i/2] = byteValue;
  }

  return arrayBuffer;
}

function bytesToHexString(bytes){
  if (!bytes){
    return null;
  }

  bytes = new Uint8Array(bytes);
  var hexBytes = [];

  for (var i = 0; i < bytes.length; ++i) {
    var byteString = bytes[i].toString(16);
    if (byteString.length < 2){
      byteString = "0" + byteString;
    }
    hexBytes.push(byteString);
  }
  return hexBytes.join("");
}

function asciiToUint8Array(str){
  var chars = [];
  for (var i = 0; i < str.length; ++i){
    chars.push(str.charCodeAt(i));
  }
  return new Uint8Array(chars);
}

function bytesToASCIIString(bytes){
  return String.fromCharCode.apply(null, new Uint8Array(bytes));
}
var menu = document.getElementById('menu');
menu.children[0].classList.remove('hover');
menu.children[1].classList.add('hover');
document.getElementById('db').disabled = false;
document.getElementById('db').addEventListener('change', function(e) {
  try{
    var db = JSON.parse(e.target.value)
    api = new API(db);
  }
  catch (e){
    console.log('Invalid JSON : ' + e.message)
  }
});

var api = new API();
var currentUser = {};

});