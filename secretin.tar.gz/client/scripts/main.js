document.addEventListener("DOMContentLoaded", function() {

document.getElementById('newUser').addEventListener('click', function(e) {
  var btn = e.target;
  var username = document.getElementById('newUsername').value;
  var password = document.getElementById('newPassword').value;
  btn.disabled = true;
  btn.value = 'Please wait...';
  newUser(username, password).then(function(msg){
    document.location.href = '#keys';
    btn.disabled = false;
    btn.value = 'Generate';
    document.getElementById('newUsername').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('userTitle').textContent = currentUser.username+'\'s secrets';
    document.getElementById('secrets').style.display = '';
    document.getElementById('login').style.display = 'none';
    document.getElementById('deco').style.display = '';
    getSecretList();
  }, function(err){
    btn.disabled = false;
    btn.value = 'Generate';
    error(document.getElementById('errorNew'), err);
    throw(err);
  });
});

document.getElementById('getKeys').addEventListener('click', function(e){
  var btn = e.target;
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;
  var remoteUser;
  var key;
  var hash;
  btn.disabled = true;
  btn.value = 'Please wait...';
  getKeys(username, password).then(function(){
    btn.disabled = false;
    btn.value = 'Get keys';
    document.getElementById('username').value = '';
    document.getElementById('password').value = '';
    document.getElementById('userTitle').textContent = currentUser.username+'\'s secrets';
    document.getElementById('secrets').style.display = '';
    document.getElementById('login').style.display = 'none';
    document.getElementById('deco').style.display = '';
    getSecretList();
  }, function(err){
    btn.disabled = false;
    btn.value = 'Get keys';
    error(document.getElementById('errorLogin'), err);
    throw(err);
  });
});

document.getElementById('addSecretPopup').addEventListener('click', function(e){
  var secret = new Secret();
  document.getElementById('popupTitle').textContent = 'Add secret';
  var secretContent = document.getElementById('secretContent');

  var title = document.createElement('input');
  title.type = 'text';
  title.placeholder = 'Secret title';

  var addSecretBtn = document.createElement('input');
  addSecretBtn.type = 'button';
  addSecretBtn.classList.add('btn3');
  addSecretBtn.value = 'Add Secret';
  addSecretBtn.addEventListener('click', function(e){
    addSecret(title.value, secret.toString()).then(function(){
      secret.destroy();
      cleanElement(secretContent);
      document.getElementById('popupTitle').value = '';
      document.location.href = '#keys';
      getSecretList();
    }, function(err){
      alert(err);
      throw(err);
    });

  });

  secretContent.appendChild(title);
  secret.draw(secretContent);

  cleanElement(document.getElementById('popupBottom'));
  document.getElementById('popupBottom').appendChild(addSecretBtn);

  var popupClose = document.createElement('a');
  popupClose.classList.add('close');
  popupClose.textContent = '×';
  popupClose.addEventListener('click', function(e){
    secret.destroy();
    cleanElement(secretContent);
    document.getElementById('popupTitle').value = '';
    document.location.href = '#keys';
  });

  var secretPopup = document.getElementById('secretPopup').querySelector('.popup');
  secretPopup.insertBefore(popupClose, secretContent);
});


function showSecretPopup(e){

  var hashedTitle  = e.path[1].children[0].textContent;
  var title  = e.path[1].children[1].textContent;

  getSecret(hashedTitle).then(function(secretDatas){
    var secret = new Secret(secretDatas);
    var secretContent = document.getElementById('secretContent');
    document.getElementById('popupTitle').textContent = title;
    secret.draw(secretContent);

    var editSecretBtn = document.createElement('input');
    editSecretBtn.type = 'button';
    editSecretBtn.classList.add('btn3');
    editSecretBtn.value = 'Edit Secret';
    editSecretBtn.addEventListener('click', function(e){
      if(e.target.value === 'Edit Secret'){
        e.target.value = 'Save Secret';
        secret.editable = true;
        secret.redraw();
      }
      else{
        editSecret(hashedTitle, secret.toString()).then(function(){
          secret.editable = false;
          secret.redraw();
          e.target.value = 'Edit Secret';
        }, function(err){
          alert(err);
          throw(err);
        });
      }
    });

    cleanElement(document.getElementById('popupBottom'));
    if(currentUser.keys[hashedTitle].rights > 0){
      document.getElementById('popupBottom').appendChild(editSecretBtn);
    }

    document.location.hash = '#secretPopup';

    var popupClose = document.createElement('a');
    popupClose.classList.add('close');
    popupClose.textContent = '×';
    popupClose.addEventListener('click', function(e){
      secret.destroy();
      cleanElement(secretContent);
      document.getElementById('popupTitle').value = '';
      document.location.href = '#keys';
    });

    var secretPopup = document.getElementById('secretPopup').querySelector('.popup');
    secretPopup.insertBefore(popupClose, secretContent);
  });
}

function cleanElement(elem){
  while (elem.firstChild) {
    elem.removeChild(elem.firstChild);
  }
}

document.getElementById('changePasswordBtn').addEventListener('click', function(e) {
  var btn = e.target;
  var password = document.getElementById('changePasswordInput').value;
  var pass = {};
  btn.disabled = true;
  btn.value = 'Please wait...';
  changePassword(password).then(function(msg){
    btn.disabled = false;
    btn.value = 'Change password';
    document.getElementById('changePasswordInput').value = '';
    document.location.href = '#keys';
  }, function(err){
    btn.disabled = false;
    btn.value = 'Change password';
    alert(err);
    throw(err);
  });
});

var timeout;

window.addEventListener('focus', function() {
  clearInterval(timeout);
});

window.addEventListener('blur', function() {
  timeout = setTimeout(function() { destroyUser(currentUser); currentUser = {}; }, 60000);
});

document.getElementById('deco').addEventListener('click', function(e){
  destroyUser(currentUser);
  currentUser = {};
});

document.getElementById('closeShareSecret').addEventListener('click', function(e){
  document.getElementById('shareSecretTitle').textContent = '';
  document.getElementById('shareSecretHash').value = '';
  var sharedUsersList = document.getElementById('sharedUsers');
  while (sharedUsersList.firstChild) {
    sharedUsersList.removeChild(sharedUsersList.firstChild);
  }
  document.location.href = '#keys';
});

document.getElementById('share').addEventListener('click', function(e){
  var hashedTitle = document.getElementById('shareSecretHash').value;
  var friendName = document.getElementById('friendName').value;
  var rights = document.getElementById('rights').value;
  e.target.disabled = true;
  e.target.value = 'Please wait...';
  shareSecret(hashedTitle, friendName, rights).then(function(users){
    e.target.disabled = false;
    e.target.value = 'Share';
    document.getElementById('friendName').value = '';
    share(false, hashedTitle, document.getElementById('shareSecretTitle').textContent);
  }, function(err){
    e.target.disabled = false;
    e.target.value = 'Share';
    document.getElementById('friendName').value='';
    error(document.getElementById('errorShareSecret'), err);
    throw(err);
  });
});


function unshare(e){
  var hashedTitle = document.getElementById('shareSecretHash').value;
  var friendName = e.path[1].children[0].textContent;
  e.target.disabled = true;
  e.target.value = 'Please wait...';
  unshareSecret(hashedTitle, friendName).then(function(){
    share(false, hashedTitle, document.getElementById('shareSecretTitle').textContent);
  }, function(err){
    e.target.disabled = false;
    e.target.value = 'Unshare';
    error(document.getElementById('errorShareSecret'), err);
    throw(err);
  });

}

document.getElementById('refresh').addEventListener('click', function(e){
  document.getElementById('search').value = '';
  refreshKeys().then(function(){
    getSecretList();
  }, function(err){
    alert(err);
    throw(err);
  });
});

document.getElementById('changePasswordA').addEventListener('click', function(e){
  setTimeout(function(){ document.getElementById('changePasswordInput').focus(); }, 100);
});

document.getElementById('search').addEventListener('keyup', function(e){
  var elems = document.querySelectorAll('.secretElem');
  for (var i = 0; i < elems.length; i++) {
    if(e.target.value.length > 2 && elems[i].children[1].textContent.toLowerCase().indexOf(e.target.value.toLowerCase()) === -1){
      elems[i].style.display = 'none';
    }
    else{
      elems[i].style.display = '';
    }
  }
});

document.getElementById('getDb').addEventListener('click', function(e) {
  if(typeof currentUser !== 'undefined' && typeof currentUser.username !== 'undefined'){
    api.getDb(currentUser.username, currentUser.hash).then(function(db){
      document.getElementById('db').value = JSON.stringify(db);
    });
  }
  else{
    document.getElementById('db').value = 'Not connected !';
    setTimeout(function(){ document.getElementById('db').value = ''; }, 1000);
  }
});

document.getElementById('password').addEventListener('keypress', function(e){
  if(e.keyCode === 13){
    document.getElementById('getKeys').click();
  }
});

document.getElementById('newPassword').addEventListener('keypress', function(e){
  if(e.keyCode === 13){
    document.getElementById('newUser').click();
  }
});

function error(elem, text){
  elem.textContent = 'Error: ' + text;
  elem.style.display = '';
  setTimeout(function(){ cleanError(elem); }, 3000);
}

function cleanError(elem){
  elem.textContent = '';
  elem.style.display = 'none';
}

function destroyUser(user){
  var secretsList = document.getElementById('secretsList');
  var oldElems = document.querySelectorAll('.secretElem');
  for (var i = 0; i < oldElems.length; i++) {
    secretsList.removeChild(oldElems[i]);
  }
  document.getElementById('userTitle').textContent = 'Not connected';
  document.getElementById('search').value = '';
  document.getElementById('secrets').style.display = 'none';
  document.getElementById('login').style.display = '';
  document.getElementById('deco').style.display = 'none';
  user.disconnect();
}

document.getElementById('editSecret').addEventListener('click', function(e){
  var popup = document.getElementById('showSecret');
  var content = popup.getElementsByClassName('content')[0];

  document.getElementById('saveSecret').style.display = '';
  document.getElementById('hideSecret').textContent = 'Cancel';
});

function uiDeleteSecret(e){
  var title       = e.path[1].children[1].textContent;
  var hashedTitle = e.path[1].children[0].textContent;
  var sure = confirm('Are you sure to delete ' + title + '?');
  if(sure){
    deleteSecret(hashedTitle).then(function(){
      getSecretList();
    }, function(err){
      alert(err);
      throw(err);
    });
  }
}

function share(e, hashedTitle, title){
  if(typeof(hashedTitle) === 'undefined'){
    hashedTitle = e.path[1].children[0].textContent;
  }
  if(typeof(title) === 'undefined'){
    title  = e.path[1].children[1].textContent;
  }
  document.getElementById('shareSecretHash').value = hashedTitle;
  document.getElementById('shareSecretTitle').textContent = title;
  document.location.hash = '#shareSecret';

  getSharedUsers(hashedTitle).then(function(users){
    var sharedUsersList = document.getElementById('sharedUsers');
    while (sharedUsersList.firstChild) {
      sharedUsersList.removeChild(sharedUsersList.firstChild);
    }
    users.forEach(function(userHash){
      sharedUsersList.appendChild(uiSharedUsers(userHash));
    });
  });
}

function getSecretList(){
  var secretsList = document.getElementById('secretsList');
  var oldElems = secretsList.querySelectorAll('.secretElem');

  for (var i = 0; i < oldElems.length; i++) {
    secretsList.removeChild(oldElems[i]);
  }
  currentUser.decryptTitles().then(function(){
    Object.keys(currentUser.titles).forEach(function(hashedTitle){
      secretsList.appendChild(uiSecretList(hashedTitle, currentUser.titles[hashedTitle]));
    });
  });
  document.getElementById('search').focus();
}



// ###################### User.js ######################

var User = function(username) {
  var _this = this;
  _this.username    = username;
  _this.hash        = null;
  _this.publicKey   = null;
  _this.privateKey  = null;
  _this.keys        = {};
  _this.titles      = {};
  _this.token       = {value: '', time: 0};
};

User.prototype.disconnect = function(){
  var _this = this;
  delete _this.username;
  delete _this.hash;
  delete _this.publicKey;
  delete _this.privateKey;
  delete _this.titles;
  delete _this.keys;
  delete _this.token;
};

User.prototype.isTokenValid = function(){
  var _this = this;
  return (_this.token.time > Date.now-10);
};

User.prototype.getToken = function(api){
  var _this = this;
  if(_this.isTokenValid()){
    return _this.token.value;
  }
  else{
    return api.getNewChallenge(_this).then(function(challenge){
      _this.token.time  = challenge.time;
      _this.token.value = decryptRSAOAEP(challenge.value, _this.privateKey);
      return _this.token.value;
    });
  }
};

User.prototype.generateMasterKey = function(){
  var _this = this;
  return genRSAOAEP().then(function(keyPair) {
    _this.publicKey  = keyPair.publicKey;
    _this.privateKey = keyPair.privateKey;
  });
};

User.prototype.exportPublicKey = function(){
  var _this = this;
  return exportPublicKey(_this.publicKey);
};

User.prototype.importPublicKey = function(jwkPublicKey){
  var _this = this;
  return importPublicKey(jwkPublicKey).then(function(publicKey){
    _this.publicKey = publicKey;
  });
};

User.prototype.exportPrivateKey = function(dKey){
  var _this = this;
  return exportPrivateKey(dKey, _this.privateKey).then(function(privateKeyObject){
    return {
      privateKey: bytesToHexString(privateKeyObject.privateKey),
      iv: bytesToHexString(privateKeyObject.iv)
    };
  });
};

User.prototype.importPrivateKey = function(dKey, privateKeyObject){
  var _this = this;
  return importPrivateKey(dKey, privateKeyObject).then(function(privateKey){
    _this.privateKey = privateKey;
  });
};

User.prototype.encryptTitle = function(title, publicKey){
  var _this = this;
  return encryptRSAOAEP(title, publicKey).then(function(encryptedTitle){
    return bytesToHexString(encryptedTitle);
  });
};

User.prototype.shareSecret = function(friend, wrappedKey, hashedTitle){
  var _this = this;
  var result = {};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return _this.wrapKey(key, friend.publicKey);
  }).then(function(friendWrappedKey){
    result.wrappedKey = friendWrappedKey;
    return _this.encryptTitle(_this.titles[hashedTitle], friend.publicKey);
  }).then(function(encryptedTitle){
    result.encryptedTitle = encryptedTitle;
    return SHA256(friend.username);
  }).then(function(hashedUsername){
    result.friendName = bytesToHexString(hashedUsername);
    return result;
  });
};

User.prototype.editSecret = function(secret, wrappedKey){
  var _this = this;
  var result = {};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return encryptAESGCM256(secret, key);
  }).then(function(secretObject){
    result.secret = bytesToHexString(secretObject.secret);
    result.iv = bytesToHexString(secretObject.iv);
    return result;
  });
};

User.prototype.createSecret = function(title, secret){
  var _this = this;
  var now = Date.now();
  var saltedTitle = now+'|'+title;
  var result = {};
  return _this.encryptSecret(secret).then(function(secretObject){
    result.secret = bytesToHexString(secretObject.secret);
    result.iv = bytesToHexString(secretObject.iv);
    return _this.wrapKey(secretObject.key, _this.publicKey);
  }).then(function(wrappedKey){
    result.wrappedKey = wrappedKey;
    return _this.encryptTitle(saltedTitle, _this.publicKey);
  }).then(function(encryptedTitle){
    result.encryptedTitle = encryptedTitle;
    return SHA256(_this.username);
  }).then(function(hashedUsername){
    result.hashedUsername = bytesToHexString(hashedUsername);
    return SHA256(saltedTitle);
  }).then(function(hashedTitle){
    result.hashedTitle = bytesToHexString(hashedTitle);
    return result;
  });
};

User.prototype.encryptSecret = function(secret){
  var _this = this;
  return encryptAESGCM256(secret);
};

User.prototype.decryptSecret = function(secret, wrappedKey){
  var _this = this;
  return _this.unwrapKey(wrappedKey).then(function(key){
    return decryptAESGCM256(secret, key);
  }).then(function(decryptedSecret){
    return bytesToASCIIString(decryptedSecret);
  });
};

User.prototype.unwrapKey = function(wrappedKey){
  var _this = this;
  return unwrapRSAOAEP(wrappedKey, _this.privateKey);
};

User.prototype.wrapKey = function(key, publicKey){
  var _this = this;
  return wrapRSAOAEP(key, publicKey).then(function(wrappedKey){
    return bytesToHexString(wrappedKey);
  });
};

User.prototype.decryptTitles = function(){
  var _this = this;
  return new Promise(function(resolve, reject){
    var hashedTitles = Object.keys(_this.keys);
    hashedTitles.forEach(function(hashedTitle){
      _this.titles = {};
      decryptRSAOAEP(_this.keys[hashedTitle].title, _this.privateKey).then(function(title){
        _this.titles[hashedTitle] = bytesToASCIIString(title);
        if(Object.keys(_this.titles).length === hashedTitles.length){
          resolve();
        }
      });
    });
  });
};
var Secret = function(rawContent) {
  this.parent = false;
  this.editable = true;
  this.fields = [];

  if(typeof(rawContent) !== 'undefined'){
    this.editable = false;

    try {
      var object = JSON.parse(rawContent);
      for(var key in object){
        this[key] = object[key];
      }
    }
    catch(e) {
      this.fields.push({label:'secret', content: rawContent});
    }
  }
  else{
    this.fields.push({label:'', content: ''});
  }
};

Secret.prototype.destroy = function(){
  delete this.fields;
  this.wipe();
};

Secret.prototype.wipe = function(){
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  if(typeof(fieldsList) !== 'undefined'){
    cleanElement(fieldsList);
  }
};

Secret.prototype.newField = function(data, index){
  var _this = this;
  var field = document.createElement('li');
  var label;
  if(this.editable === true){
    label = document.createElement('input');
    label.type = 'text';
    label.classList.add('secretFieldLabel');
    label.placeholder = 'Label';
    label.value = data.label;
  }
  else{
    label = document.createElement('label');
    label.textContent = data.label+' : ';
  }

  var content = document.createElement('input');
  content.type = 'text';
  content.classList.add('secretFieldContent');
  content.placeholder = 'Secret';
  content.value = data.content;
  if(this.editable !== true){
    content.readOnly = true;
  }

  var iconDelete = document.createElement('a');
  iconDelete.classList.add('icon');
  iconDelete.classList.add('iconDelete');
  iconDelete.title = 'Delete Field';
  iconDelete.textContent = '-';
  iconDelete.addEventListener('click', function(e){
    _this.deleteField(index);
  });
  if(this.editable !== true || this.fields.length < 2){
    iconDelete.style.display = 'none';
  }

  var iconCopy = document.createElement('a');
  iconCopy.classList.add('icon');
  iconCopy.title = 'Copy';
  iconCopy.textContent = '❐';

  iconCopy.addEventListener('click', function(e){
    var field = e.target.parentNode.querySelector('.secretFieldContent');
    field.select();
    document.execCommand('copy');
    document.getElementById('search').select();
  });

  var iconGenerate = document.createElement('a');
  iconGenerate.classList.add('icon');
  iconGenerate.title = 'Copy';
  iconGenerate.textContent = '⎁';

  iconGenerate.addEventListener('click', function(e){
    var field = e.target.parentNode.querySelector('.secretFieldContent');
    field.value = generateRandomString(30);
  });

  field.appendChild(label);
  field.appendChild(content);
  field.appendChild(iconDelete);
  field.appendChild(iconCopy);
  if(this.editable === true){
    field.appendChild(iconGenerate);
  }

  return field;
};

Secret.prototype.redraw = function(){
  this.wipe();
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  for (var i = 0; i < this.fields.length; ++i) {
    fieldsList.appendChild(this.newField(this.fields[i]), i);
  }
};

Secret.prototype.draw = function(parent){
  var _this = this;
  this.parent = parent;
  this.wipe();

  var fieldsList = document.createElement('ul');
  for (var i = 0; i < this.fields.length; ++i) {
    fieldsList.appendChild(this.newField(this.fields[i]), i);
  }

  var iconAdd = document.createElement('a');
  iconAdd.classList.add('icon');
  iconAdd.classList.add('bottomIcon');
  iconAdd.title = 'Add field';
  iconAdd.textContent = '+';
  if(this.editable !== true){
    iconAdd.style.display = 'none';
  }
  iconAdd.addEventListener('click', function(e){
    _this.addField();
  });

  this.parent.appendChild(fieldsList);
  this.parent.appendChild(iconAdd);
};

Secret.prototype.addField = function(){
  this.getDatas();
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  var newFieldData = {label: '', content: ''};
  this.fields.push(newFieldData);
  fieldsList.appendChild(this.newField(newFieldData, this.fields.length));

  fieldsList.childNodes[0].querySelector('.iconDelete').style.display = '';
};

Secret.prototype.getDatas = function(){
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  for(var i = 0; i < fieldsList.childNodes.length; i++){
    var field = fieldsList.childNodes[i];
    this.fields[i].content = field.querySelector('.secretFieldContent').value;
    if(this.editable === true){
      this.fields[i].label = field.querySelector('.secretFieldLabel').value;
    }
    else{
      this.fields[i].label = field.querySelector('.secretFieldLabel').textContent;
    }
  }
};

Secret.prototype.deleteField = function(index){
  this.getDatas();
  this.fields.splice(index-1, 1);
  this.redraw();
};

Secret.prototype.toString = function(){
  this.getDatas();
  return JSON.stringify({'fields': this.fields});
};



// ###################### API.js ######################

var API = function(link) {
  var _this = this;
  if(link){
    _this.db = link;
  }
  else{
    _this.db = window.location.origin;
  }
};

API.prototype.userExists = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return true;
  }).catch(function(err){
    return false;
  });
};

API.prototype.addUser = function(username, privateKey, publicKey, pass){
  var _this = this;
  return SHA256(username).then(function(hashedUsername){
    return POST(_this.db+'/user/'+bytesToHexString(hashedUsername),{
      pass: pass,
      privateKey: privateKey,
      publicKey: publicKey,
      keys: {}
    });
  });
};

API.prototype.addSecret = function(user, secretObject){
  var _this = this;
  return user.getToken(_this).then(function(token){
    return POST(_this.db+'/user/'+secretObject.hashedUsername+'/'+secretObject.hashedTitle,{
      secret: secretObject.secret,
      iv: secretObject.iv,
      title: secretObject.encryptedTitle,
      key: secretObject.wrappedKey,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.deleteSecret = function(user, hashedTitle){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return DELETE(_this.db+'/user/'+hashedUsername+'/'+hashedTitle, {
      token: bytesToHexString(token)
    });
  });
};


API.prototype.getNewChallenge = function(user){
  var _this = this;
  return SHA256(user.username).then(function(hashedUsername){
    return GET(_this.db+'/challenge/'+bytesToHexString(hashedUsername));
  });
};

API.prototype.editSecret = function(user, secretObject, hashedTitle){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/edit/'+hashedUsername+'/'+hashedTitle,{
      iv: secretObject.iv,
      secret: secretObject.secret,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.newKey = function(user, hashedTitle, secret, wrappedKeys){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/newKey/'+hashedUsername+'/'+hashedTitle,{
      wrappedKeys: wrappedKeys,
      secret: secret,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.unshareSecret = function(user, friendName, hashedTitle, hashedFriendUsername){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return SHA256(friendName);
  }).then(function(rHashedFriendUsername){
    if(typeof(hashedFriendUsername) === 'undefined'){
      hashedFriendUsername = bytesToHexString(rHashedFriendUsername);
    }
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/unshare/'+hashedUsername+'/'+hashedTitle,{
      friendName: hashedFriendUsername,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.shareSecret = function(user, sharedSecretObject, hashedTitle, rights){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/share/'+hashedUsername+'/'+hashedTitle,{
      friendName: sharedSecretObject.friendName,
      title: sharedSecretObject.encryptedTitle,
      key: sharedSecretObject.wrappedKey,
      rights: rights,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.retrieveUser = function(username, hash, isHashed){
  var _this = this;
  if(isHashed){
    return GET(_this.db+'/user/'+username+'/'+hash);
  }
  else{
    return SHA256(username).then(function(hashedUsername){
      return GET(_this.db+'/user/'+bytesToHexString(hashedUsername)+'/'+hash);
    });
  }
};

API.prototype.getDerivationParameters = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return {salt: user.pass.salt, iterations: user.pass.iterations};
  });
};

API.prototype.getWrappedPrivateKey = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.privateKey;
  });
};

API.prototype.getPublicKey = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return user.publicKey;
  });
};

API.prototype.getKeys = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.keys;
  });
};

API.prototype.getUser = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user;
  });
};

API.prototype.getSecret = function(hashedTitle){
  var _this = this;
  return GET(_this.db+'/secret/'+hashedTitle);
};

API.prototype.getDb = function(username, hash, isHashed){
  var _this = this;
  return SHA256(username).then(function(hashedUsername){
    return GET(_this.db+'/database/'+bytesToHexString(hashedUsername)+'/'+hash);
  });
};

API.prototype.changePassword = function(user, privateKey, pass){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return PUT(_this.db+'/user/'+hashedUsername,{
      pass: pass,
      privateKey: privateKey,
      token: bytesToHexString(token)
    });
  });
};
if(typeof(crypto) === 'undefined'){
    crypto = msCrypto;
}
if(typeof(crypto.subtle) === 'undefined'){
    crypto.subtle = crypto.webkitSubtle;
}
// ###################### crypto.js ######################

function SHA256(str){
  var algorithm = 'SHA-256';
  var data = asciiToUint8Array(str);
  return crypto.subtle.digest(algorithm, data);
}

function genRSAOAEP(){
  var algorithm = {
    name: 'RSA-OAEP',
    modulusLength: 4096,
    publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
    hash: {name: 'SHA-256'}
  };
  var extractable = true;
  var keyUsages = [
    'wrapKey',
    'unwrapKey',
    'encrypt',
    'decrypt'
  ];
  return crypto.subtle.generateKey(algorithm, extractable, keyUsages);
}


function encryptAESGCM256(secret, key){
  var result = {};
  var algorithm = {};
  if(typeof key === 'undefined'){
    algorithm = {
      name: 'AES-GCM',
      length: 256
    };
    var extractable = true;
    var keyUsages = [
      'encrypt'
    ];
    return crypto.subtle.generateKey(algorithm, extractable, keyUsages).then(function(key){
      var iv = new Uint8Array(12);
      crypto.getRandomValues(iv);
      algorithm = {
        name: 'AES-GCM',
        iv: iv,
        tagLength: 128
      };
      var data = asciiToUint8Array(secret);
      result.key = key;
      result.iv = iv;
      return crypto.subtle.encrypt(algorithm, key, data);
    }).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
  else{
    result.key = key;
    var iv = new Uint8Array(12);
    crypto.getRandomValues(iv);
    algorithm = {
      name: 'AES-GCM',
      iv: iv,
      tagLength: 128
    };
    var data = asciiToUint8Array(secret);
    result.iv = iv;
    return crypto.subtle.encrypt(algorithm, key, data).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
}

function decryptAESGCM256(secretObject, key){
  var algorithm = {
    name: 'AES-GCM',
    iv: hexStringToUint8Array(secretObject.iv),
    tagLength: 128
  };
  var data = hexStringToUint8Array(secretObject.secret);
  return crypto.subtle.decrypt(algorithm, key, data);
}

function encryptRSAOAEP(secret, publicKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = asciiToUint8Array(secret);
  return crypto.subtle.encrypt(algorithm, publicKey, data);
}

function decryptRSAOAEP(secret, privateKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = hexStringToUint8Array(secret);
  return crypto.subtle.decrypt(algorithm, privateKey, data);
}

function wrapRSAOAEP(key, wrappingPublicKey){
  var format = 'raw';
  var wrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  return crypto.subtle.wrapKey(format, key, wrappingPublicKey, wrapAlgorithm);
}

function unwrapRSAOAEP(wrappedKeyHex, unwrappingPrivateKey){
  var format = 'raw';
  var wrappedKey = hexStringToUint8Array(wrappedKeyHex);
  var unwrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var unwrappedKeyAlgorithm  = {
    name: 'AES-GCM',
    length: 256
  };
  var extractable = true;
  var usages = ['decrypt', 'encrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedKey, unwrappingPrivateKey, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, usages
  );
}

function exportPublicKey(publicKey){
  var format = 'jwk';
  return crypto.subtle.exportKey(format, publicKey);
}

function importPublicKey(jwkPublicKey){
  var format = 'jwk';
  var algorithm = {
    name: "RSA-OAEP",
    hash: {name: "SHA-256"}
  };
  var extractable = false;
  var keyUsages = [
    'wrapKey', 'encrypt'
  ];
  return crypto.subtle.importKey(format, jwkPublicKey, algorithm, extractable, keyUsages);
}

function derivePassword(password, parameters){
  var result = {};

  var passwordBuf = asciiToUint8Array(password);
  var extractable = false;
  var usages = ['deriveKey', 'deriveBits'];

  return crypto.subtle.importKey(
    'raw', passwordBuf, {name: 'PBKDF2'}, extractable, usages
  ).then(function(key){

    var saltBuf;
    var iterations;
    if(typeof parameters === 'undefined'){
      saltBuf = new Uint8Array(32);
      crypto.getRandomValues(saltBuf);
      var iterationsBuf = new Uint8Array(1);
      crypto.getRandomValues(iterationsBuf);
      iterations = 100000 + iterationsBuf[0];
    }
    else{
      saltBuf = hexStringToUint8Array(parameters.salt);
      if(typeof parameters.iterations === 'undefined'){
        iterations = 10000; //retrocompatibility
      }
      else{
        iterations = parameters.iterations;
      }
    }

    result.salt = saltBuf;
    result.iterations = iterations;

    var algorithm = {
      name: "PBKDF2",
      salt: saltBuf,
      iterations: iterations,
      hash: {name: "SHA-256"}
    };

    var deriveKeyAlgorithm = {
      name: "AES-CBC",
      length: 256
    };

    extractable = true;
    usages = ['wrapKey', 'unwrapKey'];

    return crypto.subtle.deriveKey(algorithm, key, deriveKeyAlgorithm, extractable, usages);
  }).then(function(dKey){
    result.key = dKey;
    return crypto.subtle.exportKey('raw', dKey);
  }).then(function(rawKey){
    return crypto.subtle.digest('SHA-256', rawKey);
  }).then(function(hashedKey){
    result.hash = hashedKey;
    return result;
  });
}

function exportPrivateKey(key, privateKey){
  var result = {};
  var format = 'jwk';
  var iv = new Uint8Array(16);
  crypto.getRandomValues(iv);
  var wrapAlgorithm = {
    name: "AES-CBC",
    iv: iv
  };
  result.iv = iv;
  return crypto.subtle.wrapKey(
    format, privateKey, key, wrapAlgorithm
  ).then(function(wrappedPrivateKey){
    result.privateKey = wrappedPrivateKey;
    return result;
  });
}

function importPrivateKey(key, privateKeyObject){
  var format = 'jwk';
  var wrappedPrivateKey = hexStringToUint8Array(privateKeyObject.privateKey);
  var unwrapAlgorithm = {
    name: 'AES-CBC',
    iv: hexStringToUint8Array(privateKeyObject.iv)
  };
  var unwrappedKeyAlgorithm = {
    name: "RSA-OAEP",
    hash: {name: "sha-256"}
  };
  var extractable = true;
  var keyUsages = ['unwrapKey', 'decrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedPrivateKey, key, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, keyUsages
  ).then(function(privateKey){
    return privateKey;
  }).catch(function(err){
    throw('Invalid Password');
  });
}

// ###################### http.js ######################

function GET(path){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', encodeURI(path));
    xhr.onload = function() {
      if (xhr.status === 200) {
        var datas = JSON.parse(xhr.responseText);
        resolve(datas);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send();
  });
}

function POST(path, datas){
  return reqData(path, datas, 'POST');
}

function PUT(path, datas){
  return reqData(path, datas, 'PUT');
}

function reqData(path, datas, type){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open(type, encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

function DELETE(path, datas){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open('DELETE', encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

// ###################### secretin.js ######################

function newUser(username, password){
  return api.userExists(username).then(function(exists){
    if(!exists){
      var result = {};
      var pass = {};
      currentUser = new User(username);
      return currentUser.generateMasterKey().then(function(){
        return derivePassword(password);
      }).then(function(dKey){
        pass.salt = bytesToHexString(dKey.salt);
        pass.hash = bytesToHexString(dKey.hash);
        pass.iterations = dKey.iterations;
        currentUser.hash = pass.hash;
        return currentUser.exportPrivateKey(dKey.key);
      }).then(function(privateKey){
        result.privateKey = privateKey;
        return currentUser.exportPublicKey();
      }).then(function(publicKey){
        result.publicKey = publicKey;
        return api.addUser(currentUser.username, result.privateKey, result.publicKey, pass);
      }, function(err){
        throw(err);
      });
    }
    else{
      throw('Username already exists');
    }
  });
}

function getKeys(username, password){
  return api.getDerivationParameters(username).then(function(parameters){
    return derivePassword(password, parameters);
  }).then(function(dKey){
    key = dKey.key;
    hash = bytesToHexString(dKey.hash);
    return api.getUser(username, hash);
  }).then(function(user){
    currentUser = new User(username);
    remoteUser = user;
    currentUser.keys = remoteUser.keys;
    currentUser.hash = hash;
    return currentUser.importPublicKey(remoteUser.publicKey);
  }).then(function(){
    return currentUser.importPrivateKey(key, remoteUser.privateKey);
  }, function(err){
    throw(err);
  });
}

function refreshKeys(){
  return api.getKeys(currentUser.username, currentUser.hash).then(function(keys){
    currentUser.keys = keys;
    return keys;
  }, function(err){
    throw(err);
  });
}

function addSecret(title, content){
  return new Promise(function(resolve, reject){
    if(typeof(currentUser.username) === 'string'){
      return currentUser.createSecret(title, content).then(function(secretObject){
        return api.addSecret(currentUser, secretObject);
      }).then(function(msg){
        resolve(refreshKeys());
      }, function(err){
        throw(err);
      });
    }
    else{
      throw('You are disconnected');
    }
  });
}

function changePassword(password){
  var pass = {};
  return derivePassword(password).then(function(dKey){
    pass.salt = bytesToHexString(dKey.salt);
    pass.hash = bytesToHexString(dKey.hash);
    pass.iterations = dKey.iterations;
    return currentUser.exportPrivateKey(dKey.key);
  }).then(function(privateKey){
    return api.changePassword(currentUser, privateKey, pass);
  }, function(err){
    throw(err);
  });
}

function editSecret(hashedTitle, content){
  return currentUser.editSecret(content, currentUser.keys[hashedTitle].key).then(function(secretObject){
    return api.editSecret(currentUser, secretObject, hashedTitle);
  }, function(err){
    throw(err);
  });
}

function getSharedUsers(hashedTitle){
  return api.getSecret(hashedTitle).then(function(encryptedSecret){
    return encryptedSecret.users;
  }, function(err){
    throw(err);
  });
}

function shareSecret(hashedTitle, friendName, rights){
  var friend;
  return api.getSecret(hashedTitle).then(function(encryptedSecret){
    friend = new User(friendName);
    return api.getPublicKey(friend.username);
  }).then(function(publicKey){
    return friend.importPublicKey(publicKey);
  }).then(function(){
    return currentUser.shareSecret(friend, currentUser.keys[hashedTitle].key, hashedTitle);
  }).then(function(sharedSecretObject){
    return api.shareSecret(currentUser, sharedSecretObject, hashedTitle, rights);
  }, function(err){
    throw(err);
  });
}

function unshareSecret(hashedTitle, friendName){
  var friend;
  var encryptedSecret;
  var secret = {};
  var wrappedKeys = [];
  return api.unshareSecret(currentUser, friendName, hashedTitle, friendName).then(function(){
    return api.getSecret(hashedTitle);
  }).then(function(eSecret){
      encryptedSecret = eSecret;
      return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
  }).then(function(secret){
      return currentUser.encryptSecret(secret);
  }).then(function(secretObject){
    secret.secret = bytesToHexString(secretObject.secret);
    secret.iv     = bytesToHexString(secretObject.iv);
    return new Promise(function(resolve, reject){
      encryptedSecret.users.forEach(function(hashedUsername){
        api.getPublicKey(hashedUsername, true).then(function(publicKey){
          friend = new User(hashedUsername);
          return friend.importPublicKey(publicKey);
        }).then(function(){
          return currentUser.wrapKey(secretObject.key, friend.publicKey);
        }).then(function(friendWrappedKey){
          wrappedKeys.push({user: hashedUsername, key: friendWrappedKey });
          if(wrappedKeys.length === encryptedSecret.users.length){
            resolve(api.newKey(currentUser, hashedTitle, secret, wrappedKeys));
          }
        });
      });
    });
  }, function(err){
    throw(err);
  });
}

function getSecret(hashedTitle){
    return api.getSecret(hashedTitle).then(function(encryptedSecret){
        return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
    });
}

function deleteSecret(hashedTitle){
  return api.deleteSecret(currentUser, hashedTitle).then(function(){
    return refreshKeys();
  }, function(err){
    throw(err);
  });
}


// ###################### util.js ######################

function hexStringToUint8Array(hexString){
  if (hexString.length % 2 !== 0){
    throw "Invalid hexString";
  }
  var arrayBuffer = new Uint8Array(hexString.length / 2);

  for (var i = 0; i < hexString.length; i += 2) {
    var byteValue = parseInt(hexString.substr(i, 2), 16);
    if (isNaN(byteValue)){
      throw "Invalid hexString";
    }
    arrayBuffer[i/2] = byteValue;
  }

  return arrayBuffer;
}

function bytesToHexString(bytes){
  if (!bytes){
    return null;
  }

  bytes = new Uint8Array(bytes);
  var hexBytes = [];

  for (var i = 0; i < bytes.length; ++i) {
    var byteString = bytes[i].toString(16);
    if (byteString.length < 2){
      byteString = "0" + byteString;
    }
    hexBytes.push(byteString);
  }
  return hexBytes.join("");
}

function asciiToUint8Array(str){
  var chars = [];
  for (var i = 0; i < str.length; ++i){
    chars.push(str.charCodeAt(i));
  }
  return new Uint8Array(chars);
}

function bytesToASCIIString(bytes){
  return String.fromCharCode.apply(null, new Uint8Array(bytes));
}

function generateRandomString(length){
  var charset = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ123456789 !"#$%&\'()*+,-./:;<=>?@[\\]_{}';
  var randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  var string = '';
  for(var i = 0; i < length; i++){
    string += charset[randomValues[i]%charset.length];
  }
  return string;
}

function uiSharedUsers(userHash){
  var elem = document.createElement('li');
  elem.classList.add('sharedUserElem');

  var userHashSpan = document.createElement('span');
  userHashSpan.textContent = userHash;

  var unshareBtn = document.createElement('input');
  unshareBtn.type = 'button';
  unshareBtn.value = 'Unshare';
  unshareBtn.addEventListener('click', unshare);

  elem.appendChild(userHashSpan);
  elem.appendChild(unshareBtn);
  return elem;
}

function uiSecretList(hashedTitle, title){
  var elem = document.createElement('li');
  elem.classList.add('secretElem');

  var btn = document.createElement('input');
  btn.type = 'button';
  btn.value = 'Show';
  btn.addEventListener('click', showSecretPopup);

  var shareBtn = document.createElement('input');
  shareBtn.type = 'button';
  shareBtn.value = 'Share';
  shareBtn.addEventListener('click', share);

  var deleteBtn = document.createElement('input');
  deleteBtn.type = 'button';
  deleteBtn.value = 'Delete';
  deleteBtn.addEventListener('click', uiDeleteSecret);

  var titleSpan = document.createElement('span');
  titleSpan.textContent = title.substring(14);

  var br = document.createElement('br');

  var hashSpan = document.createElement('span');
  hashSpan.textContent = hashedTitle;
  hashSpan.style.display = 'none';

  elem.appendChild(hashSpan);
  elem.appendChild(titleSpan);
  elem.appendChild(br);
  elem.appendChild(btn);

  if(currentUser.keys[hashedTitle].rights > 1){
    elem.appendChild(shareBtn);
  }
  elem.appendChild(deleteBtn);

  return elem;
}
document.getElementById('dbUri').addEventListener('change', function(e) {
  var db = e.target.value;
  api = new API(db);
});

document.getElementById('db').disabled = true;

var api = new API();
var currentUser = {};

});