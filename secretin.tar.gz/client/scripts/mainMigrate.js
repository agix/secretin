document.addEventListener("DOMContentLoaded", function() {
    function getSharedUsers(hashedTitle){
  return api.getSecret(hashedTitle, currentUser).then(function(encryptedSecret){
    return encryptedSecret.users;
  }, function(err){
    throw(err);
  });
}


    function migrate(username, password){
        getKeys(username, password).then(function(){
            return currentUser.decryptTitles();
        }).then(function(){
            Object.keys(currentUser.titles).forEach(function(hashedTitle){
                var title = currentUser.titles[hashedTitle];
                var metadatas = {title: currentUser.titles[hashedTitle].substring(14), users: {}};
                metadatas.users[currentUser.username] = currentUser.keys[hashedTitle].rights;
                currentUser.metadatas = metadatas;
                if(currentUser.keys[hashedTitle].rights > 0){
                    getSecret(hashedTitle).then(function(secretDatas){
                        var rawSecretDatas;
                        try {
                          rawSecretDatas = JSON.parse(secretDatas);
                        }
                        catch(e) {
                          rawSecretDatas = {label: 'secret', content: secretDatas};
                        }
                        editSecret(hashedTitle, metadatas, rawSecretDatas).then(function(){
                            getSharedUsers(hashedTitle).then(function(users){
                                users.forEach(function(user){
                                    unshareSecret(hashedTitle, user, user);
                                });
                            });
                        });
                    });
                }
                else{
                    getSecret(hashedTitle).then(function(secretDatas){
                        var rawSecretDatas;
                        try {
                          rawSecretDatas = JSON.parse(secretDatas);
                        }
                        catch(e) {
                          rawSecretDatas = {label: 'secret', content: secretDatas};
                        }
                        addSecret(metadatas, rawSecretDatas).then(function(){
                            deleteSecret(hashedTitle);
                        });
                    });
                }
            });
        }, function(err){
            alert(err);
        });
    }

    document.getElementById('migrate').addEventListener('click', function(e){
        migrate(document.getElementById('username').value, document.getElementById('password').value);
    });

// ###################### User.js ######################

var User = function(username) {
  var _this = this;
  _this.username    = username;
  _this.hash        = null;
  _this.publicKey   = null;
  _this.privateKey  = null;
  _this.keys        = {};
  _this.metadatas   = {};
  _this.token       = {value: '', time: 0};
};

User.prototype.disconnect = function(){
  var _this = this;
  delete _this.username;
  delete _this.hash;
  delete _this.publicKey;
  delete _this.privateKey;
  delete _this.metadatas;
  delete _this.keys;
  delete _this.token;
};

User.prototype.isTokenValid = function(){
  var _this = this;
  return (_this.token.time > Date.now()-10000);
};

User.prototype.getToken = function(api){
  var _this = this;
  if(_this.isTokenValid()){
    return _this.token.value;
  }
  else{
    return api.getNewChallenge(_this).then(function(challenge){
      _this.token.time  = challenge.time;
      _this.token.value = decryptRSAOAEP(challenge.value, _this.privateKey);
      return _this.token.value;
    });
  }
};

User.prototype.generateMasterKey = function(){
  var _this = this;
  return genRSAOAEP().then(function(keyPair) {
    _this.publicKey  = keyPair.publicKey;
    _this.privateKey = keyPair.privateKey;
  });
};

User.prototype.exportPublicKey = function(){
  var _this = this;
  return exportPublicKey(_this.publicKey);
};

User.prototype.importPublicKey = function(jwkPublicKey){
  var _this = this;
  return importPublicKey(jwkPublicKey).then(function(publicKey){
    _this.publicKey = publicKey;
  });
};

User.prototype.exportPrivateKey = function(dKey){
  var _this = this;
  return exportPrivateKey(dKey, _this.privateKey).then(function(privateKeyObject){
    return {
      privateKey: bytesToHexString(privateKeyObject.privateKey),
      iv: bytesToHexString(privateKeyObject.iv)
    };
  });
};

User.prototype.importPrivateKey = function(dKey, privateKeyObject){
  var _this = this;
  return importPrivateKey(dKey, privateKeyObject).then(function(privateKey){
    _this.privateKey = privateKey;
  });
};

User.prototype.encryptTitle = function(title, publicKey){
  var _this = this;
  return encryptRSAOAEP(title, publicKey).then(function(encryptedTitle){
    return bytesToHexString(encryptedTitle);
  });
};

User.prototype.shareSecret = function(friend, wrappedKey, hashedTitle){
  var _this = this;
  var result = {hashedTitle: hashedTitle};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return _this.wrapKey(key, friend.publicKey);
  }).then(function(friendWrappedKey){
    result.wrappedKey = friendWrappedKey;
    return SHA256(friend.username);
  }).then(function(hashedUsername){
    result.friendName = bytesToHexString(hashedUsername);
    return result;
  });
};

User.prototype.editSecret = function(metadatas, secret, wrappedKey){
  var _this = this;
  var result = {};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return _this.encryptSecret(metadatas, secret, key);
  }).then(function(secretObject){
    result.secret    = secretObject.secret;
    result.iv        = secretObject.iv;
    result.metadatas = secretObject.metadatas;
    result.iv_meta   = secretObject.iv_meta;
    return result;
  });
};

User.prototype.createSecret = function(metadatas, secret){
  var _this = this;
  var now = Date.now();
  var saltedTitle = now+'|'+metadatas.title;
  var result = {};
  return _this.encryptSecret(metadatas, secret).then(function(secretObject){
    result.secret    = secretObject.secret;
    result.iv        = secretObject.iv;
    result.metadatas = secretObject.metadatas;
    result.iv_meta   = secretObject.iv_meta;
    return _this.wrapKey(secretObject.key, _this.publicKey);
  }).then(function(wrappedKey){
    result.wrappedKey = wrappedKey;
    return SHA256(_this.username);
  }).then(function(hashedUsername){
    result.hashedUsername = bytesToHexString(hashedUsername);
    return SHA256(saltedTitle);
  }).then(function(hashedTitle){
    result.hashedTitle = bytesToHexString(hashedTitle);
    return result;
  });
};

User.prototype.encryptSecret = function(metadatas, secret, key){
  var _this = this;
  var result = {};
  return encryptAESGCM256(secret, key).then(function(secretObject){
    result.secret = bytesToHexString(secretObject.secret);
    result.iv     = bytesToHexString(secretObject.iv);
    result.key    = secretObject.key;
    return encryptAESGCM256(metadatas, secretObject.key);
  }).then(function(secretObject){
    result.metadatas = bytesToHexString(secretObject.secret);
    result.iv_meta   = bytesToHexString(secretObject.iv);
    return result;
  });
};

User.prototype.decryptSecret = function(secret, wrappedKey){
  var _this = this;
  return _this.unwrapKey(wrappedKey).then(function(key){
    return decryptAESGCM256(secret, key);
  }).then(function(decryptedSecret){
    return bytesToASCIIString(decryptedSecret);
  });
};

User.prototype.unwrapKey = function(wrappedKey){
  var _this = this;
  return unwrapRSAOAEP(wrappedKey, _this.privateKey);
};

User.prototype.wrapKey = function(key, publicKey){
  var _this = this;
  return wrapRSAOAEP(key, publicKey).then(function(wrappedKey){
    return bytesToHexString(wrappedKey);
  });
};

User.prototype.decryptAllMetadatas = function(allMetadatas){
  var _this = this;
  var decryptMetadatasPromises = []
  var hashedTitles = Object.keys(_this.keys);
  _this.metadatas = {};
  hashedTitles.forEach(function(hashedTitle){
    decryptMetadatasPromises.push(
      _this.decryptSecret(allMetadatas[hashedTitle], _this.keys[hashedTitle].key).then(function(metadatas){
        _this.metadatas[hashedTitle] = JSON.parse(metadatas);
        return;
      })
    )
  });
  return Promise.all(decryptMetadatasPromises);
}

User.prototype.decryptTitles = function(){ //Should be removed after migration
  var _this = this;
  return new Promise(function(resolve, reject){
    var hashedTitles = Object.keys(_this.keys);
    var total = hashedTitles.length;
    hashedTitles.forEach(function(hashedTitle){
      _this.titles = {};
      if(typeof(_this.keys[hashedTitle].title) !== 'undefined'){
        decryptRSAOAEP(_this.keys[hashedTitle].title, _this.privateKey).then(function(title){
          _this.titles[hashedTitle] = bytesToASCIIString(title);
          if(Object.keys(_this.titles).length === total){
            resolve();
          }
        });
      }
      else{
        total -= 1;
        if(total === 0){
          console.log('Every secrets migrated');
        }
      }
    });
  });
};
var Secret = function(type, rawContent) {
  this.parent = false;
  this.editable = true;
  this.fields = [];

  if(typeof(rawContent) !== 'undefined'){
    this.editable = false;

    try {
      var object = JSON.parse(rawContent);
      for(var key in object){
        this[key] = object[key];
      }
    }
    catch(e) {
      this.fields.push({label:'secret', content: rawContent});
    }
  }
  else{
    this.fields.push({label:'', content: ''});
  }
};

Secret.prototype.destroy = function(){
  delete this.fields;
  this.wipe();
};

Secret.prototype.wipe = function(){
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  if(typeof(fieldsList) !== 'undefined'){
    cleanElement(fieldsList);
  }
};

Secret.prototype.newField = function(data, index){
  var _this = this;
  var field = document.createElement('li');
  var label;
  if(this.editable === true){
    label = document.createElement('input');
    label.type = 'text';
    label.classList.add('secretFieldLabel');
    label.placeholder = 'Label';
    label.value = data.label;
  }
  else{
    label = document.createElement('label');
    label.textContent = data.label+' : ';
  }

  var content = document.createElement('input');
  content.type = 'text';
  content.classList.add('secretFieldContent');
  content.placeholder = 'Secret';
  content.value = data.content;
  if(this.editable !== true){
    content.readOnly = true;
  }

  var iconDelete = document.createElement('a');
  iconDelete.classList.add('icon');
  iconDelete.classList.add('iconDelete');
  iconDelete.title = 'Delete Field';
  iconDelete.textContent = '-';
  iconDelete.addEventListener('click', function(e){
    _this.deleteField(index);
  });
  if(this.editable !== true || this.fields.length < 2){
    iconDelete.style.display = 'none';
  }

  var iconCopy = document.createElement('a');
  iconCopy.classList.add('icon');
  iconCopy.title = 'Copy';
  iconCopy.textContent = '❐';

  iconCopy.addEventListener('click', function(e){
    var field = e.target.parentNode.querySelector('.secretFieldContent');
    field.select();
    document.execCommand('copy');
    document.getElementById('search').select();
  });

  var iconGenerate = document.createElement('a');
  iconGenerate.classList.add('icon');
  iconGenerate.title = 'Copy';
  iconGenerate.textContent = '⎁';

  iconGenerate.addEventListener('click', function(e){
    var field = e.target.parentNode.querySelector('.secretFieldContent');
    field.value = generateRandomString(30);
  });

  field.appendChild(label);
  field.appendChild(content);
  field.appendChild(iconDelete);
  field.appendChild(iconCopy);
  if(this.editable === true){
    field.appendChild(iconGenerate);
  }

  return field;
};

Secret.prototype.redraw = function(){
  this.wipe();
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  for (var i = 0; i < this.fields.length; i++) {
    fieldsList.appendChild(this.newField(this.fields[i], i));
  }
  var iconAdd = this.parent.querySelector('.bottomIcon');
  if(this.editable !== true){
    iconAdd.style.display = 'none';
  }
  else{
    iconAdd.style.display = '';
  }
};

Secret.prototype.draw = function(parent){
  var _this = this;
  this.parent = parent;
  this.wipe();

  var fieldsList = document.createElement('ul');
  for (var i = 0; i < this.fields.length; i++) {
    fieldsList.appendChild(this.newField(this.fields[i], i));
  }

  var iconAdd = document.createElement('a');
  iconAdd.classList.add('icon');
  iconAdd.classList.add('bottomIcon');
  iconAdd.title = 'Add field';
  iconAdd.textContent = '+';
  if(this.editable !== true){
    iconAdd.style.display = 'none';
  }
  iconAdd.addEventListener('click', function(e){
    _this.addField();
  });

  this.parent.appendChild(fieldsList);
  this.parent.appendChild(iconAdd);
};

Secret.prototype.addField = function(){
  this.getDatas();
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  var newFieldData = {label: '', content: ''};
  this.fields.push(newFieldData);
  fieldsList.appendChild(this.newField(newFieldData, this.fields.length-1));

  fieldsList.childNodes[0].querySelector('.iconDelete').style.display = '';
};

Secret.prototype.getDatas = function(){
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  for(var i = 0; i < fieldsList.childNodes.length; i++){
    var field = fieldsList.childNodes[i];
    this.fields[i].content = field.querySelector('.secretFieldContent').value;
    if(this.editable === true){
      this.fields[i].label = field.querySelector('.secretFieldLabel').value;
    }
    else{
      this.fields[i].label = field.querySelector('.secretFieldLabel').textContent;
    }
  }
};

Secret.prototype.deleteField = function(index){
  this.getDatas();
  this.fields.splice(index, 1);
  this.redraw();
};

Secret.prototype.toJSON = function(){
  if(this.parent){
    this.getDatas();
    return {'fields': this.fields};
  }
  else{
    return {};
  }

};



// ###################### API.js ######################

var API = function(link) {
  var _this = this;
  if(link){
    _this.db = link;
  }
  else{
    _this.db = window.location.origin;
  }
};

API.prototype.userExists = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return true;
  }).catch(function(err){
    return false;
  });
};

API.prototype.addUser = function(username, privateKey, publicKey, pass){
  var _this = this;
  return SHA256(username).then(function(hashedUsername){
    return POST(_this.db+'/user/'+bytesToHexString(hashedUsername),{
      pass: pass,
      privateKey: privateKey,
      publicKey: publicKey,
      keys: {}
    });
  });
};

API.prototype.addSecret = function(user, secretObject){
  var _this = this;
  return user.getToken(_this).then(function(token){
    return POST(_this.db+'/user/'+secretObject.hashedUsername+'/'+secretObject.hashedTitle,{
      secret: secretObject.secret,
      iv: secretObject.iv,
      metadatas: secretObject.metadatas,
      iv_meta: secretObject.iv_meta,
      key: secretObject.wrappedKey,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.deleteSecret = function(user, hashedTitle){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return DELETE(_this.db+'/user/'+hashedUsername+'/'+hashedTitle, {
      token: bytesToHexString(token)
    });
  }).then(function(datas){
    return datas;
  });
};


API.prototype.getNewChallenge = function(user){
  var _this = this;
  return SHA256(user.username).then(function(hashedUsername){
    return GET(_this.db+'/challenge/'+bytesToHexString(hashedUsername));
  });
};

API.prototype.editSecret = function(user, secretObject, hashedTitle){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/edit/'+hashedUsername+'/'+hashedTitle,{
      iv: secretObject.iv,
      secret: secretObject.secret,
      iv_meta: secretObject.iv_meta,
      metadatas: secretObject.metadatas,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.newKey = function(user, hashedTitle, secret, wrappedKeys){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/newKey/'+hashedUsername+'/'+hashedTitle,{
      wrappedKeys: wrappedKeys,
      secret: secret,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.unshareSecret = function(user, friendNames, hashedTitle){
  var _this = this;
  var hashedUsername;
  var hashedFriendUserames = [];
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    var hashedFriendUseramePromises = [];
    friendNames.forEach(function(username){
      hashedFriendUseramePromises.push(SHA256(username));
    });
    return Promise.all(hashedFriendUseramePromises);
  }).then(function(rHashedFriendUserames){
    rHashedFriendUserames.forEach(function(hashedFriendUserame){
      hashedFriendUserames.push(bytesToHexString(hashedFriendUserame));
    });
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/unshare/'+hashedUsername+'/'+hashedTitle,{
      friendNames: hashedFriendUserames,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.shareSecret = function(user, sharedSecretObjects){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/share/'+hashedUsername,{
      secretObjects: sharedSecretObjects,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.retrieveUser = function(username, hash, isHashed){
  var _this = this;
  if(isHashed){
    return GET(_this.db+'/user/'+username+'/'+hash);
  }
  else{
    return SHA256(username).then(function(hashedUsername){
      return GET(_this.db+'/user/'+bytesToHexString(hashedUsername)+'/'+hash);
    });
  }
};

API.prototype.getDerivationParameters = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return {salt: user.pass.salt, iterations: user.pass.iterations};
  });
};

API.prototype.getWrappedPrivateKey = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.privateKey;
  });
};

API.prototype.getPublicKey = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return user.publicKey;
  });
};

API.prototype.getKeysWithToken = function(user){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return GET(_this.db+'/user/'+hashedUsername+'?token='+bytesToHexString(token));
  }).then(function(userContent){
    return userContent.keys;
  });
};

API.prototype.getKeys = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.keys;
  });
};

API.prototype.getUser = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user;
  });
};

API.prototype.getSecret = function(hashedTitle, user){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return GET(_this.db+'/secret/'+hashedTitle+'?name='+hashedUsername+'&token='+bytesToHexString(token));
  });
};

API.prototype.getAllMetadatas = function(user){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return GET(_this.db+'/allMetadatas/'+hashedUsername+'?token='+bytesToHexString(token));
  }).then(function(datas){
    return datas
  });
};

API.prototype.getDb = function(username, hash, isHashed){
  var _this = this;
  return SHA256(username).then(function(hashedUsername){
    return GET(_this.db+'/database/'+bytesToHexString(hashedUsername)+'/'+hash);
  });
};

API.prototype.changePassword = function(user, privateKey, pass){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return PUT(_this.db+'/user/'+hashedUsername,{
      pass: pass,
      privateKey: privateKey,
      token: bytesToHexString(token)
    });
  });
};

// ###################### secretin.js ######################

var Secretin = function() {
  this.api = new API();
  this.currentUser = {};
}

Secretin.prototype.changeDB = function(db){
  this.api = new API(db);
}

Secretin.prototype.newUser = function(username, password){
  var _this = this;
  return _this.api.userExists(username).then(function(exists){
    if(!exists){
      var result = {};
      var pass = {};
      _this.currentUser = new User(username);
      return _this.currentUser.generateMasterKey().then(function(){
        return derivePassword(password);
      }).then(function(dKey){
        pass.salt = bytesToHexString(dKey.salt);
        pass.hash = bytesToHexString(dKey.hash);
        pass.iterations = dKey.iterations;
        _this.currentUser.hash = pass.hash;
        return _this.currentUser.exportPrivateKey(dKey.key);
      }).then(function(privateKey){
        result.privateKey = privateKey;
        return _this.currentUser.exportPublicKey();
      }).then(function(publicKey){
        result.publicKey = publicKey;
        return _this.api.addUser(_this.currentUser.username, result.privateKey, result.publicKey, pass);
      }, function(err){
        throw(err);
      });
    }
    else{
      throw('Username already exists');
    }
  });
}

Secretin.prototype.getKeys = function(username, password){
  var _this = this;
  return _this.api.getDerivationParameters(username).then(function(parameters){
    return derivePassword(password, parameters);
  }).then(function(dKey){
    key = dKey.key;
    hash = bytesToHexString(dKey.hash);
    return _this.api.getUser(username, hash);
  }).then(function(user){
    _this.currentUser = new User(username);
    remoteUser = user;
    _this.currentUser.keys = remoteUser.keys;
    _this.currentUser.hash = hash;
    return _this.currentUser.importPublicKey(remoteUser.publicKey);
  }).then(function(){
    return _this.currentUser.importPrivateKey(key, remoteUser.privateKey);
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.refreshKeys = function(){
  var _this = this;
  return _this.api.getKeysWithToken(_this.currentUser).then(function(keys){
    _this.currentUser.keys = keys;
    return keys;
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.addSecret = function(metadatas, content){
  var _this = this;
  var hashedTitle;
  return new Promise(function(resolve, reject){
    metadatas.users = {};
    metadatas.folders = {};
    metadatas.users[_this.currentUser.username] = {rights: 2};
    if(typeof(_this.currentUser.username) === 'string'){
      return _this.currentUser.createSecret(metadatas, content).then(function(secretObject){
        hashedTitle = secretObject.hashedTitle
        return _this.api.addSecret(_this.currentUser, secretObject);
      }).then(function(msg){
        return _this.refreshKeys();
      }).then(function(){
        return _this.getAllMetadatas();
      }).then(function(){
        if(typeof(_this.currentUser.currentFolder) !== 'undefined'){
          resolve(_this.addSecretToFolder(hashedTitle, _this.currentUser.currentFolder))
        }
        else{
          resolve();
        }
      }, function(err){
        throw(err);
      });
    }
    else{
      throw('You are disconnected');
    }
  });
}

Secretin.prototype.changePassword = function(password){
  var _this = this;
  var pass = {};
  return derivePassword(password).then(function(dKey){
    pass.salt = bytesToHexString(dKey.salt);
    pass.hash = bytesToHexString(dKey.hash);
    pass.iterations = dKey.iterations;
    return _this.currentUser.exportPrivateKey(dKey.key);
  }).then(function(privateKey){
    return _this.api.changePassword(_this.currentUser, privateKey, pass);
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.editSecret = function(hashedTitle, metadatas, content){
  var _this = this;
  return _this.currentUser.editSecret(metadatas, content, _this.currentUser.keys[hashedTitle].key).then(function(secretObject){
    return _this.api.editSecret(_this.currentUser, secretObject, hashedTitle);
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.addSecretToFolder = function(hashedSecretTitle, hashedFolder){
  var _this = this;
  var sharedSecretObjectsPromises = [];
  Object.keys(_this.currentUser.metadatas[hashedFolder].users).forEach(function(friendName){
    sharedSecretObjectsPromises = sharedSecretObjectsPromises.concat(
      (function(){
        var friend = new User(friendName);
        return _this.api.getPublicKey(friend.username).then(function(publicKey){
          return friend.importPublicKey(publicKey);
        }).then(function(){
          return _this.getSharedSecretObjects(hashedSecretTitle, friend, _this.currentUser.metadatas[hashedFolder].users[friend.username].rights, []);
        });
      })()
    );
  });

  var metadatasUsers = {}
  return Promise.all(sharedSecretObjectsPromises).then(function(sharedSecretObjectsArray){
    var fullSharedSecretObjects = [];
    sharedSecretObjectsArray.forEach(function(sharedSecretObjects){
      sharedSecretObjects.forEach(function(sharedSecretObject){
        if(typeof(metadatasUsers[sharedSecretObject.hashedTitle]) === 'undefined'){
          metadatasUsers[sharedSecretObject.hashedTitle] = []
        }
        metadatasUsers[sharedSecretObject.hashedTitle].push({friendName: sharedSecretObject.username, folder: sharedSecretObject.inFolder});
        delete sharedSecretObject.inFolder;
        if(_this.currentUser.username !== sharedSecretObject.username){
          delete sharedSecretObject.username;
          fullSharedSecretObjects.push(sharedSecretObject);
        }
      });
    });
    return _this.api.shareSecret(_this.currentUser, fullSharedSecretObjects);
  }).then(function(){
    var resetMetaPromises = [];
    if(typeof(_this.currentUser.currentFolder) !== 'undefined'){
      delete _this.currentUser.metadatas[hashedSecretTitle].folders[_this.currentUser.currentFolder];
    }
    _this.currentUser.metadatas[hashedSecretTitle].folders[hashedFolder] = {name: _this.currentUser.metadatas[hashedFolder].title};
    Object.keys(metadatasUsers).forEach(function(hashedTitle){
      metadatasUsers[hashedTitle].forEach(function(infos){
        var metaUser = {rights: _this.currentUser.metadatas[hashedFolder].users[infos.friendName].rights};
        if(typeof(infos.folder) === 'undefined'){
          metaUser.folder = _this.currentUser.metadatas[hashedFolder].title;
        }
        else{
          metaUser.folder = infos.folder;
        }
        if(infos.friendName === _this.currentUser.username){
          metaUser.rights = 2;
        }
        _this.currentUser.metadatas[hashedTitle].users[infos.friendName] = metaUser;
      });

      resetMetaPromises.push(_this.resetMetadatas(hashedTitle));
    });
    return Promise.all(resetMetaPromises);
  }).then(function(){
    return _this.api.getSecret(hashedFolder, _this.currentUser);
  }).then(function(encryptedSecret){
    return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedFolder].key);
  }).then(function(secret){
    var folder = JSON.parse(secret);
    folder[hashedSecretTitle] = 1;
    return _this.editSecret(hashedFolder, _this.currentUser.metadatas[hashedFolder], folder);
  });
}

Secretin.prototype.getSharedSecretObjects = function(hashedTitle, friend, rights, fullSharedSecretObjects, folderName){
  var _this = this;
  var isFolder = Promise.resolve();
  var sharedSecretObjectPromises = [];
  if(typeof(_this.currentUser.metadatas[hashedTitle].type) !== 'undefined' && _this.currentUser.metadatas[hashedTitle].type === 'folder'){
    isFolder = isFolder.then(function(){
      return _this.api.getSecret(hashedTitle, _this.currentUser).then(function(encryptedSecret){
        return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedTitle].key);
      }).then(function(secrets){
        Object.keys(JSON.parse(secrets)).forEach(function(hash){
          sharedSecretObjectPromises.push(_this.getSharedSecretObjects(hash, friend, rights, fullSharedSecretObjects, _this.currentUser.metadatas[hashedTitle].title));
        });
        return Promise.all(sharedSecretObjectPromises);
      });
    });
  }

  return isFolder.then(function(){
    return _this.currentUser.shareSecret(friend, _this.currentUser.keys[hashedTitle].key, hashedTitle);
  }).then(function(secretObject){
    secretObject.rights = rights;
    secretObject.inFolder = folderName;
    secretObject.username = friend.username;
    fullSharedSecretObjects.push(secretObject);
    return fullSharedSecretObjects;
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.resetMetadatas = function(hashedTitle){
  var _this = this;
  var secretObject;
  return _this.api.getSecret(hashedTitle, _this.currentUser).then(function(encryptedSecret){
    return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedTitle].key);
  }).then(function(secret){
    secretObject = JSON.parse(secret);
    return _this.editSecret(hashedTitle, _this.currentUser.metadatas[hashedTitle], secretObject);
  });
}


Secretin.prototype.shareSecret = function(hashedTitle, friendName, rights, type){
  var _this = this;
  if(type === 'folder'){
    return new Promise(function(resolve, reject){
      var hashedFolder = false;
      Object.keys(_this.currentUser.metadatas).forEach(function(hash){
        if(typeof(_this.currentUser.metadatas[hash].type) !== 'undefined' && _this.currentUser.metadatas[hash].type === 'folder' && _this.currentUser.metadatas[hash].title === friendName){
          hashedFolder = hash;
        }
      });
      if(hashedFolder === false){
        reject('Folder not found');
      }
      else{
        if(hashedTitle === hashedFolder){
          reject('You can\'t put this folder in itself.');
        }
        else{
          resolve(_this.addSecretToFolder(hashedTitle, hashedFolder));
        }
      }
    });
  }
  else{
    var sharedSecretObjects;
    var friend = new User(friendName);
    return _this.api.getPublicKey(friend.username).then(function(publicKey){
      return friend.importPublicKey(publicKey);
    }).then(function(){
      return _this.getSharedSecretObjects(hashedTitle, friend, rights, []);
    }).then(function(rSharedSecretObjects){
      sharedSecretObjects = rSharedSecretObjects;
      return _this.api.shareSecret(_this.currentUser, sharedSecretObjects);
    }).then(function(){
      var resetMetaPromises = [];
      sharedSecretObjects.forEach(function(sharedSecretObject){
        _this.currentUser.metadatas[sharedSecretObject.hashedTitle].users[friend.username] = {rights: rights};
        if(typeof(sharedSecretObject.inFolder) !== 'undefined'){
          _this.currentUser.metadatas[sharedSecretObject.hashedTitle].users[friend.username].folder = sharedSecretObject.inFolder;
        }
        resetMetaPromises.push(_this.resetMetadatas(sharedSecretObject.hashedTitle));
      });
      return Promise.all(resetMetaPromises);
    }, function(err){
      throw(err);
    });
  }
}

Secretin.prototype.shareFolderSecrets = function(hashedFolder, friend, rights){
  var _this = this;
  var shareSecretPromises = [];
  secretList.forEach(function(hashedTitle){
    if(typeof(_this.currentUser.metadatas[hashedTitle]) !== 'undefined'){
      shareSecretPromises.push(
        _this.currentUser.shareSecret(friend, _this.currentUser.keys[hashedTitle].key, hashedTitle).then(function(sharedSecretObject){
          sharedSecretObject.rights = rights;
          return sharedSecretObject;
        })
      );
    }
  });
  return Promise.all(shareSecretPromises).then(function(sharedSecretObjects){
    return _this.api.shareSecret(_this.currentUser, sharedSecretObjects);
  }).then(function(){
    var resetMetaPromises = [];
    secretList.forEach(function(hashedTitle){
      _this.currentUser.metadatas[hashedTitle].users[friend.username] = {rights: rights, folder: _this.currentUser.metadatas[hashedFolder].title};
      resetMetaPromises.push(_this.resetMetadatas(hashedTitle));
    });
    return Promise.all(resetMetaPromises);
  });
}

Secretin.prototype.unshareSecret = function(hashedTitle, friendName){
  var _this = this;
  var secret = {};
  var isFolder = Promise.resolve();
  if(typeof(_this.currentUser.metadatas[hashedTitle].type) !== 'undefined' && _this.currentUser.metadatas[hashedTitle].type === 'folder'){
    isFolder = isFolder.then(function(){
      return _this.unshareFolderSecrets(hashedTitle, friendName);
    });
  }

  return isFolder.then(function(){
    return _this.api.unshareSecret(_this.currentUser, [friendName], hashedTitle);
  }).then(function(){
    delete _this.currentUser.metadatas[hashedTitle].users[friendName];
    return _this.resetMetadatas(hashedTitle);
  }).then(function(){
    return _this.renewKey(hashedTitle);
  }, function(err){
    if(err.status === 'Desync'){
      delete _this.currentUser.metadatas[err.datas.title].users[err.datas.friendName];
      return _this.resetMetadatas(hashedTitle);
    }
    else{
      throw(err);
    }
  });
}

Secretin.prototype.unshareFolderSecrets = function(hashedFolder, friendName, friendName2){
  var _this = this;
  return _this.api.getSecret(hashedFolder, _this.currentUser).then(function(encryptedSecret){
    return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedFolder].key);
  }).then(function(secrets){
    return Object.keys(JSON.parse(secrets)).reduce(function(promise, hashedTitle){
      return promise.then(function(){
        return _this.unshareSecret(hashedTitle, friendName);
      });
    }, Promise.resolve());
  });
}

Secretin.prototype.wrapKeyForFriend = function(hashedUsername, key){
  var _this = this;
  var friend;
  return _this.api.getPublicKey(hashedUsername, true).then(function(publicKey){
    friend = new User(hashedUsername);
    return friend.importPublicKey(publicKey);
  }).then(function(){
    return _this.currentUser.wrapKey(key, friend.publicKey);
  }).then(function(friendWrappedKey){
    return {user: hashedUsername, key: friendWrappedKey };
  });
}

Secretin.prototype.renewKey = function(hashedTitle){
  var _this = this;
  var encryptedSecret;
  var secret = {};
  return _this.api.getSecret(hashedTitle, _this.currentUser).then(function(eSecret){
    encryptedSecret = eSecret;
    return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedTitle].key);
  }).then(function(secret){
    return _this.currentUser.encryptSecret(_this.currentUser.metadatas[hashedTitle], JSON.parse(secret));
  }).then(function(secretObject){
    secret.secret    = secretObject.secret;
    secret.iv        = secretObject.iv;
    secret.metadatas = secretObject.metadatas;
    secret.iv_meta   = secretObject.iv_meta;
    var wrappedKeysPromises = [];
    encryptedSecret.users.forEach(function(hashedUsername){
      wrappedKeysPromises.push(_this.wrapKeyForFriend(hashedUsername, secretObject.key));
    });

    return Promise.all(wrappedKeysPromises);
  }).then(function(wrappedKeys){
    return _this.api.newKey(_this.currentUser, hashedTitle, secret, wrappedKeys);
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.removeSecretFromFolder = function(hashedTitle, hashedFolder){
  var _this = this;
  var folderName = _this.currentUser.metadatas[hashedTitle].folders[hashedFolder].name;
  var usersToDelete = [];
  Object.keys(_this.currentUser.metadatas[hashedTitle].users).forEach(function(username){
    var user = _this.currentUser.metadatas[hashedTitle].users[username];
    if(typeof(user.folder) !== 'undefined' && user.folder === folderName){
      usersToDelete.push(username);
    }
  });
  return _this.api.unshareSecret(_this.currentUser, usersToDelete, hashedTitle).then(function(){
    usersToDelete.forEach(function(username){
      if(username !== _this.currentUser.username){
        delete _this.currentUser.metadatas[hashedTitle].users[username];
      }
      else{
        delete _this.currentUser.metadatas[hashedTitle].users[username].folder;
      }
    });
    delete _this.currentUser.metadatas[hashedTitle].folders[hashedFolder];
    return _this.renewKey(hashedTitle);
  }).then(function(){
    return _this.api.getSecret(hashedFolder, _this.currentUser);
  }).then(function(encryptedSecret){
    return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedFolder].key);
  }).then(function(secret){
    var folder = JSON.parse(secret);
    delete folder[hashedTitle];
    return _this.editSecret(hashedFolder, _this.currentUser.metadatas[hashedFolder], folder);
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.getSecret = function(hashedTitle){
  var _this = this;
  return _this.api.getSecret(hashedTitle, _this.currentUser).then(function(rEncryptedSecret){
    var encryptedSecret = {secret: rEncryptedSecret.secret, iv: rEncryptedSecret.iv};
    return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedTitle].key);
  });
}

Secretin.prototype.deleteSecret = function(hashedTitle){
  var _this = this;
  var wasLast = false;
  var isFolder = Promise.resolve();
  if(typeof(_this.currentUser.metadatas[hashedTitle].type) !== 'undefined' && _this.currentUser.metadatas[hashedTitle].type === 'folder'){
    isFolder = isFolder.then(function(){
      return _this.deleteFolderSecrets(hashedTitle);
    });
  }

  return isFolder.then(function(){
    delete _this.currentUser.metadatas[hashedTitle].users[_this.currentUser.username];
    return _this.resetMetadatas(hashedTitle);
  }).then(function(){
    return _this.api.deleteSecret(_this.currentUser, hashedTitle);
  }).then(function(wasLast){
    var isLast = Promise.resolve();
    if(wasLast){
      isLast = isLast.then(function(){
        var editFolderPromises = [];
        Object.keys(_this.currentUser.metadatas[hashedTitle].folders).forEach(function(hashedFolder){
          editFolderPromises.push(
            _this.api.getSecret(hashedFolder, _this.currentUser).then(function(encryptedSecret){
              return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedFolder].key);
            }).then(function(secret){
              var folder = JSON.parse(secret);
              delete folder[hashedTitle];
              return _this.editSecret(hashedFolder, _this.currentUser.metadatas[hashedFolder], folder);
            })
          )
        });
        return Promise.all(editFolderPromises);
      });
    }
    return isLast;
  }, function(err){
    throw(err);
  });
}

Secretin.prototype.deleteFolderSecrets = function(hashedFolder){
  var _this = this;
  return _this.api.getSecret(hashedFolder, _this.currentUser).then(function(encryptedSecret){
    return _this.currentUser.decryptSecret(encryptedSecret, _this.currentUser.keys[hashedFolder].key);
  }).then(function(secrets){
    return Object.keys(JSON.parse(secrets)).reduce(function(promise, hashedTitle){
      return promise.then(function(){
        return _this.deleteSecret(hashedTitle);
      });
    }, Promise.resolve());
  });
}

Secretin.prototype.getAllMetadatas = function(){
  var _this = this;
  return _this.api.getAllMetadatas(_this.currentUser).then(function(allMetadatas){
    return _this.currentUser.decryptAllMetadatas(allMetadatas);
  }, function(err){
    throw(err);
  })
}


if(typeof(crypto) === 'undefined'){
    crypto = msCrypto;
}
if(typeof(crypto.subtle) === 'undefined'){
    crypto.subtle = crypto.webkitSubtle;
}
// ###################### crypto.js ######################

function SHA256(str){
  var algorithm = 'SHA-256';
  var data = asciiToUint8Array(str);
  return crypto.subtle.digest(algorithm, data);
}

function genRSAOAEP(){
  var algorithm = {
    name: 'RSA-OAEP',
    modulusLength: 4096,
    publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
    hash: {name: 'SHA-256'}
  };
  var extractable = true;
  var keyUsages = [
    'wrapKey',
    'unwrapKey',
    'encrypt',
    'decrypt'
  ];
  return crypto.subtle.generateKey(algorithm, extractable, keyUsages);
}


function encryptAESGCM256(secret, key){
  var result = {};
  var algorithm = {};
  if(typeof key === 'undefined'){
    algorithm = {
      name: 'AES-GCM',
      length: 256
    };
    var extractable = true;
    var keyUsages = [
      'encrypt'
    ];
    return crypto.subtle.generateKey(algorithm, extractable, keyUsages).then(function(key){
      var iv = new Uint8Array(12);
      crypto.getRandomValues(iv);
      algorithm = {
        name: 'AES-GCM',
        iv: iv,
        tagLength: 128
      };
      var data = asciiToUint8Array(JSON.stringify(secret));
      result.key = key;
      result.iv = iv;
      return crypto.subtle.encrypt(algorithm, key, data);
    }).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
  else{
    result.key = key;
    var iv = new Uint8Array(12);
    crypto.getRandomValues(iv);
    algorithm = {
      name: 'AES-GCM',
      iv: iv,
      tagLength: 128
    };
    var data = asciiToUint8Array(JSON.stringify(secret));
    result.iv = iv;
    return crypto.subtle.encrypt(algorithm, key, data).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
}

function decryptAESGCM256(secretObject, key){
  var algorithm = {
    name: 'AES-GCM',
    iv: hexStringToUint8Array(secretObject.iv),
    tagLength: 128
  };
  var data = hexStringToUint8Array(secretObject.secret);
  return crypto.subtle.decrypt(algorithm, key, data);
}

function encryptRSAOAEP(secret, publicKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = asciiToUint8Array(secret);
  return crypto.subtle.encrypt(algorithm, publicKey, data);
}

function decryptRSAOAEP(secret, privateKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = hexStringToUint8Array(secret);
  return crypto.subtle.decrypt(algorithm, privateKey, data);
}

function wrapRSAOAEP(key, wrappingPublicKey){
  var format = 'raw';
  var wrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  return crypto.subtle.wrapKey(format, key, wrappingPublicKey, wrapAlgorithm);
}

function unwrapRSAOAEP(wrappedKeyHex, unwrappingPrivateKey){
  var format = 'raw';
  var wrappedKey = hexStringToUint8Array(wrappedKeyHex);
  var unwrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var unwrappedKeyAlgorithm  = {
    name: 'AES-GCM',
    length: 256
  };
  var extractable = true;
  var usages = ['decrypt', 'encrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedKey, unwrappingPrivateKey, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, usages
  );
}

function exportPublicKey(publicKey){
  var format = 'jwk';
  return crypto.subtle.exportKey(format, publicKey);
}

function importPublicKey(jwkPublicKey){
  var format = 'jwk';
  var algorithm = {
    name: "RSA-OAEP",
    hash: {name: "SHA-256"}
  };
  var extractable = false;
  var keyUsages = [
    'wrapKey', 'encrypt'
  ];
  return crypto.subtle.importKey(format, jwkPublicKey, algorithm, extractable, keyUsages);
}

function derivePassword(password, parameters){
  var result = {};

  var passwordBuf = asciiToUint8Array(password);
  var extractable = false;
  var usages = ['deriveKey', 'deriveBits'];

  return crypto.subtle.importKey(
    'raw', passwordBuf, {name: 'PBKDF2'}, extractable, usages
  ).then(function(key){

    var saltBuf;
    var iterations;
    if(typeof parameters === 'undefined'){
      saltBuf = new Uint8Array(32);
      crypto.getRandomValues(saltBuf);
      var iterationsBuf = new Uint8Array(1);
      crypto.getRandomValues(iterationsBuf);
      iterations = 100000 + iterationsBuf[0];
    }
    else{
      saltBuf = hexStringToUint8Array(parameters.salt);
      if(typeof parameters.iterations === 'undefined'){
        iterations = 10000; //retrocompatibility
      }
      else{
        iterations = parameters.iterations;
      }
    }

    result.salt = saltBuf;
    result.iterations = iterations;

    var algorithm = {
      name: "PBKDF2",
      salt: saltBuf,
      iterations: iterations,
      hash: {name: "SHA-256"}
    };

    var deriveKeyAlgorithm = {
      name: "AES-CBC",
      length: 256
    };

    extractable = true;
    usages = ['wrapKey', 'unwrapKey'];

    return crypto.subtle.deriveKey(algorithm, key, deriveKeyAlgorithm, extractable, usages);
  }).then(function(dKey){
    result.key = dKey;
    return crypto.subtle.exportKey('raw', dKey);
  }).then(function(rawKey){
    return crypto.subtle.digest('SHA-256', rawKey);
  }).then(function(hashedKey){
    result.hash = hashedKey;
    return result;
  });
}

function exportPrivateKey(key, privateKey){
  var result = {};
  var format = 'jwk';
  var iv = new Uint8Array(16);
  crypto.getRandomValues(iv);
  var wrapAlgorithm = {
    name: "AES-CBC",
    iv: iv
  };
  result.iv = iv;
  return crypto.subtle.wrapKey(
    format, privateKey, key, wrapAlgorithm
  ).then(function(wrappedPrivateKey){
    result.privateKey = wrappedPrivateKey;
    return result;
  });
}

function importPrivateKey(key, privateKeyObject){
  var format = 'jwk';
  var wrappedPrivateKey = hexStringToUint8Array(privateKeyObject.privateKey);
  var unwrapAlgorithm = {
    name: 'AES-CBC',
    iv: hexStringToUint8Array(privateKeyObject.iv)
  };
  var unwrappedKeyAlgorithm = {
    name: "RSA-OAEP",
    hash: {name: "sha-256"}
  };
  var extractable = true;
  var keyUsages = ['unwrapKey', 'decrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedPrivateKey, key, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, keyUsages
  ).then(function(privateKey){
    return privateKey;
  }).catch(function(err){
    throw('Invalid Password');
  });
}

// ###################### http.js ######################

function GET(path){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', encodeURI(path));
    xhr.onload = function() {
      if (xhr.status === 200) {
        var datas = JSON.parse(xhr.responseText);
        resolve(datas);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send();
  });
}

function POST(path, datas){
  return reqData(path, datas, 'POST');
}

function PUT(path, datas){
  return reqData(path, datas, 'PUT');
}

function reqData(path, datas, type){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open(type, encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      }
      else{
        try{
          var datas = JSON.parse(xhr.responseText);
          reject({status: xhr.statusText, datas: datas});
        }
        catch(err){
          reject(xhr.statusText);
        }
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

function DELETE(path, datas){
  return reqData(path, datas, 'DELETE');
}

// ###################### util.js ######################

function hexStringToUint8Array(hexString){
  if (hexString.length % 2 !== 0){
    throw "Invalid hexString";
  }
  var arrayBuffer = new Uint8Array(hexString.length / 2);

  for (var i = 0; i < hexString.length; i += 2) {
    var byteValue = parseInt(hexString.substr(i, 2), 16);
    if (isNaN(byteValue)){
      throw "Invalid hexString";
    }
    arrayBuffer[i/2] = byteValue;
  }

  return arrayBuffer;
}

function bytesToHexString(bytes){
  if (!bytes){
    return null;
  }

  bytes = new Uint8Array(bytes);
  var hexBytes = [];

  for (var i = 0; i < bytes.length; ++i) {
    var byteString = bytes[i].toString(16);
    if (byteString.length < 2){
      byteString = "0" + byteString;
    }
    hexBytes.push(byteString);
  }
  return hexBytes.join("");
}

function asciiToUint8Array(str){
  var chars = [];
  for (var i = 0; i < str.length; ++i){
    chars.push(str.charCodeAt(i));
  }
  return new Uint8Array(chars);
}

function bytesToASCIIString(bytes){
  return String.fromCharCode.apply(null, new Uint8Array(bytes));
}

function generateRandomString(length){
  var charset = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ123456789 !"#$%&\'()*+,-./:;<=>?@[\\]_{}';
  var randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  var string = '';
  for(var i = 0; i < length; i++){
    string += charset[randomValues[i]%charset.length];
  }
  return string;
}

document.getElementById('db').disabled = true;
var secretin = new Secretin();
});