document.addEventListener("DOMContentLoaded", function() {
    function getSharedUsers(hashedTitle){
  return api.getSecret(hashedTitle, currentUser).then(function(encryptedSecret){
    return encryptedSecret.users;
  }, function(err){
    throw(err);
  });
}


    function migrate(username, password){
        getKeys(username, password).then(function(){
            return currentUser.decryptTitles();
        }).then(function(){
            Object.keys(currentUser.titles).forEach(function(hashedTitle){
                var title = currentUser.titles[hashedTitle];
                var metadatas = {title: currentUser.titles[hashedTitle].substring(14), users: {}};
                metadatas.users[currentUser.username] = currentUser.keys[hashedTitle].rights;
                currentUser.metadatas = metadatas;
                if(currentUser.keys[hashedTitle].rights > 0){
                    getSecret(hashedTitle).then(function(secretDatas){
                        var rawSecretDatas;
                        try {
                          rawSecretDatas = JSON.parse(secretDatas);
                        }
                        catch(e) {
                          rawSecretDatas = {label: 'secret', content: secretDatas};
                        }
                        editSecret(hashedTitle, metadatas, rawSecretDatas).then(function(){
                            getSharedUsers(hashedTitle).then(function(users){
                                users.forEach(function(user){
                                    unshareSecret(hashedTitle, user, user);
                                });
                            });
                        });
                    });
                }
                else{
                    getSecret(hashedTitle).then(function(secretDatas){
                        var rawSecretDatas;
                        try {
                          rawSecretDatas = JSON.parse(secretDatas);
                        }
                        catch(e) {
                          rawSecretDatas = {label: 'secret', content: secretDatas};
                        }
                        addSecret(metadatas, rawSecretDatas).then(function(){
                            deleteSecret(hashedTitle);
                        });
                    });
                }
            });
        }, function(err){
            alert(err);
        });
    }

    document.getElementById('migrate').addEventListener('click', function(e){
        migrate(document.getElementById('username').value, document.getElementById('password').value);
    });

// ###################### User.js ######################

var User = function(username) {
  var _this = this;
  _this.username    = username;
  _this.hash        = null;
  _this.publicKey   = null;
  _this.privateKey  = null;
  _this.keys        = {};
  _this.metadatas   = {};
  _this.token       = {value: '', time: 0};
};

User.prototype.disconnect = function(){
  var _this = this;
  delete _this.username;
  delete _this.hash;
  delete _this.publicKey;
  delete _this.privateKey;
  delete _this.metadatas;
  delete _this.keys;
  delete _this.token;
};

User.prototype.isTokenValid = function(){
  var _this = this;
  return (_this.token.time > Date.now()-10000);
};

User.prototype.getToken = function(api){
  var _this = this;
  if(_this.isTokenValid()){
    return _this.token.value;
  }
  else{
    return api.getNewChallenge(_this).then(function(challenge){
      _this.token.time  = challenge.time;
      _this.token.value = decryptRSAOAEP(challenge.value, _this.privateKey);
      return _this.token.value;
    });
  }
};

User.prototype.generateMasterKey = function(){
  var _this = this;
  return genRSAOAEP().then(function(keyPair) {
    _this.publicKey  = keyPair.publicKey;
    _this.privateKey = keyPair.privateKey;
  });
};

User.prototype.exportPublicKey = function(){
  var _this = this;
  return exportPublicKey(_this.publicKey);
};

User.prototype.importPublicKey = function(jwkPublicKey){
  var _this = this;
  return importPublicKey(jwkPublicKey).then(function(publicKey){
    _this.publicKey = publicKey;
  });
};

User.prototype.exportPrivateKey = function(dKey){
  var _this = this;
  return exportPrivateKey(dKey, _this.privateKey).then(function(privateKeyObject){
    return {
      privateKey: bytesToHexString(privateKeyObject.privateKey),
      iv: bytesToHexString(privateKeyObject.iv)
    };
  });
};

User.prototype.importPrivateKey = function(dKey, privateKeyObject){
  var _this = this;
  return importPrivateKey(dKey, privateKeyObject).then(function(privateKey){
    _this.privateKey = privateKey;
  });
};

User.prototype.encryptTitle = function(title, publicKey){
  var _this = this;
  return encryptRSAOAEP(title, publicKey).then(function(encryptedTitle){
    return bytesToHexString(encryptedTitle);
  });
};

User.prototype.shareSecret = function(friend, wrappedKey, hashedTitle){
  var _this = this;
  var result = {};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return _this.wrapKey(key, friend.publicKey);
  }).then(function(friendWrappedKey){
    result.wrappedKey = friendWrappedKey;
    return SHA256(friend.username);
  }).then(function(hashedUsername){
    result.friendName = bytesToHexString(hashedUsername);
    return result;
  });
};

User.prototype.editSecret = function(metadatas, secret, wrappedKey){
  var _this = this;
  var result = {};
  return _this.unwrapKey(wrappedKey).then(function(key){
    return _this.encryptSecret(metadatas, secret, key);
  }).then(function(secretObject){
    result.secret    = secretObject.secret;
    result.iv        = secretObject.iv;
    result.metadatas = secretObject.metadatas;
    result.iv_meta   = secretObject.iv_meta;
    return result;
  });
};

User.prototype.createSecret = function(metadatas, secret){
  var _this = this;
  var now = Date.now();
  var saltedTitle = now+'|'+metadatas.title;
  var result = {};
  return _this.encryptSecret(metadatas, secret).then(function(secretObject){
    result.secret    = secretObject.secret;
    result.iv        = secretObject.iv;
    result.metadatas = secretObject.metadatas;
    result.iv_meta   = secretObject.iv_meta;
    return _this.wrapKey(secretObject.key, _this.publicKey);
  }).then(function(wrappedKey){
    result.wrappedKey = wrappedKey;
    return SHA256(_this.username);
  }).then(function(hashedUsername){
    result.hashedUsername = bytesToHexString(hashedUsername);
    return SHA256(saltedTitle);
  }).then(function(hashedTitle){
    result.hashedTitle = bytesToHexString(hashedTitle);
    return result;
  });
};

User.prototype.encryptSecret = function(metadatas, secret, key){
  var _this = this;
  var result = {};
  return encryptAESGCM256(secret, key).then(function(secretObject){
    result.secret = bytesToHexString(secretObject.secret);
    result.iv     = bytesToHexString(secretObject.iv);
    result.key    = secretObject.key;
    return encryptAESGCM256(metadatas, secretObject.key);
  }).then(function(secretObject){
    result.metadatas = bytesToHexString(secretObject.secret);
    result.iv_meta   = bytesToHexString(secretObject.iv);
    return result;
  });
};

User.prototype.decryptSecret = function(secret, wrappedKey){
  var _this = this;
  return _this.unwrapKey(wrappedKey).then(function(key){
    return decryptAESGCM256(secret, key);
  }).then(function(decryptedSecret){
    return bytesToASCIIString(decryptedSecret);
  });
};

User.prototype.unwrapKey = function(wrappedKey){
  var _this = this;
  return unwrapRSAOAEP(wrappedKey, _this.privateKey);
};

User.prototype.wrapKey = function(key, publicKey){
  var _this = this;
  return wrapRSAOAEP(key, publicKey).then(function(wrappedKey){
    return bytesToHexString(wrappedKey);
  });
};

User.prototype.decryptAllMetadatas = function(allMetadatas){
  var _this = this;
  return new Promise(function(resolve, reject){
    var hashedTitles = Object.keys(_this.keys);
    hashedTitles.forEach(function(hashedTitle){
      _this.metadatas = {};
      _this.decryptSecret(allMetadatas[hashedTitle], _this.keys[hashedTitle].key).then(function(metadatas){
        _this.metadatas[hashedTitle] = JSON.parse(metadatas);
        if(Object.keys(_this.metadatas).length === hashedTitles.length){
          resolve();
        }
      });
    });
  });
}

User.prototype.decryptTitles = function(){ //Should be removed after migration
  var _this = this;
  return new Promise(function(resolve, reject){
    var hashedTitles = Object.keys(_this.keys);
    var total = hashedTitles.length;
    hashedTitles.forEach(function(hashedTitle){
      _this.titles = {};
      if(typeof(_this.keys[hashedTitle].title) !== 'undefined'){
        decryptRSAOAEP(_this.keys[hashedTitle].title, _this.privateKey).then(function(title){
          _this.titles[hashedTitle] = bytesToASCIIString(title);
          if(Object.keys(_this.titles).length === total){
            resolve();
          }
        });
      }
      else{
        total -= 1;
        if(total === 0){
          console.log('Every secrets migrated');
        }
      }
    });
  });
};
var Secret = function(rawContent) {
  this.parent = false;
  this.editable = true;
  this.fields = [];

  if(typeof(rawContent) !== 'undefined'){
    this.editable = false;

    try {
      var object = JSON.parse(rawContent);
      for(var key in object){
        this[key] = object[key];
      }
    }
    catch(e) {
      this.fields.push({label:'secret', content: rawContent});
    }
  }
  else{
    this.fields.push({label:'', content: ''});
  }
};

Secret.prototype.destroy = function(){
  delete this.fields;
  this.wipe();
};

Secret.prototype.wipe = function(){
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  if(typeof(fieldsList) !== 'undefined'){
    cleanElement(fieldsList);
  }
};

Secret.prototype.newField = function(data, index){
  var _this = this;
  var field = document.createElement('li');
  var label;
  if(this.editable === true){
    label = document.createElement('input');
    label.type = 'text';
    label.classList.add('secretFieldLabel');
    label.placeholder = 'Label';
    label.value = data.label;
  }
  else{
    label = document.createElement('label');
    label.textContent = data.label+' : ';
  }

  var content = document.createElement('input');
  content.type = 'text';
  content.classList.add('secretFieldContent');
  content.placeholder = 'Secret';
  content.value = data.content;
  if(this.editable !== true){
    content.readOnly = true;
  }

  var iconDelete = document.createElement('a');
  iconDelete.classList.add('icon');
  iconDelete.classList.add('iconDelete');
  iconDelete.title = 'Delete Field';
  iconDelete.textContent = '-';
  iconDelete.addEventListener('click', function(e){
    _this.deleteField(index);
  });
  if(this.editable !== true || this.fields.length < 2){
    iconDelete.style.display = 'none';
  }

  var iconCopy = document.createElement('a');
  iconCopy.classList.add('icon');
  iconCopy.title = 'Copy';
  iconCopy.textContent = '❐';

  iconCopy.addEventListener('click', function(e){
    var field = e.target.parentNode.querySelector('.secretFieldContent');
    field.select();
    document.execCommand('copy');
    document.getElementById('search').select();
  });

  var iconGenerate = document.createElement('a');
  iconGenerate.classList.add('icon');
  iconGenerate.title = 'Copy';
  iconGenerate.textContent = '⎁';

  iconGenerate.addEventListener('click', function(e){
    var field = e.target.parentNode.querySelector('.secretFieldContent');
    field.value = generateRandomString(30);
  });

  field.appendChild(label);
  field.appendChild(content);
  field.appendChild(iconDelete);
  field.appendChild(iconCopy);
  if(this.editable === true){
    field.appendChild(iconGenerate);
  }

  return field;
};

Secret.prototype.redraw = function(){
  this.wipe();
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  for (var i = 0; i < this.fields.length; i++) {
    fieldsList.appendChild(this.newField(this.fields[i], i));
  }
  var iconAdd = this.parent.querySelector('.bottomIcon');
  if(this.editable !== true){
    iconAdd.style.display = 'none';
  }
  else{
    iconAdd.style.display = '';
  }
};

Secret.prototype.draw = function(parent){
  var _this = this;
  this.parent = parent;
  this.wipe();

  var fieldsList = document.createElement('ul');
  for (var i = 0; i < this.fields.length; i++) {
    fieldsList.appendChild(this.newField(this.fields[i], i));
  }

  var iconAdd = document.createElement('a');
  iconAdd.classList.add('icon');
  iconAdd.classList.add('bottomIcon');
  iconAdd.title = 'Add field';
  iconAdd.textContent = '+';
  if(this.editable !== true){
    iconAdd.style.display = 'none';
  }
  iconAdd.addEventListener('click', function(e){
    _this.addField();
  });

  this.parent.appendChild(fieldsList);
  this.parent.appendChild(iconAdd);
};

Secret.prototype.addField = function(){
  this.getDatas();
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  var newFieldData = {label: '', content: ''};
  this.fields.push(newFieldData);
  fieldsList.appendChild(this.newField(newFieldData, this.fields.length-1));

  fieldsList.childNodes[0].querySelector('.iconDelete').style.display = '';
};

Secret.prototype.getDatas = function(){
  var fieldsList = this.parent.getElementsByTagName('ul')[0];
  for(var i = 0; i < fieldsList.childNodes.length; i++){
    var field = fieldsList.childNodes[i];
    this.fields[i].content = field.querySelector('.secretFieldContent').value;
    if(this.editable === true){
      this.fields[i].label = field.querySelector('.secretFieldLabel').value;
    }
    else{
      this.fields[i].label = field.querySelector('.secretFieldLabel').textContent;
    }
  }
};

Secret.prototype.deleteField = function(index){
  this.getDatas();
  this.fields.splice(index, 1);
  this.redraw();
};

Secret.prototype.toJSON = function(){
  if(this.parent){
    this.getDatas();
    return {'fields': this.fields};
  }
  else{
    return {};
  }

};



// ###################### API.js ######################

var API = function(link) {
  var _this = this;
  if(link){
    _this.db = link;
  }
  else{
    _this.db = window.location.origin;
  }
};

API.prototype.userExists = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return true;
  }).catch(function(err){
    return false;
  });
};

API.prototype.addUser = function(username, privateKey, publicKey, pass){
  var _this = this;
  return SHA256(username).then(function(hashedUsername){
    return POST(_this.db+'/user/'+bytesToHexString(hashedUsername),{
      pass: pass,
      privateKey: privateKey,
      publicKey: publicKey,
      keys: {}
    });
  });
};

API.prototype.addSecret = function(user, secretObject){
  var _this = this;
  return user.getToken(_this).then(function(token){
    return POST(_this.db+'/user/'+secretObject.hashedUsername+'/'+secretObject.hashedTitle,{
      secret: secretObject.secret,
      iv: secretObject.iv,
      metadatas: secretObject.metadatas,
      iv_meta: secretObject.iv_meta,
      key: secretObject.wrappedKey,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.deleteSecret = function(user, hashedTitle){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return DELETE(_this.db+'/user/'+hashedUsername+'/'+hashedTitle, {
      token: bytesToHexString(token)
    });
  });
};


API.prototype.getNewChallenge = function(user){
  var _this = this;
  return SHA256(user.username).then(function(hashedUsername){
    return GET(_this.db+'/challenge/'+bytesToHexString(hashedUsername));
  });
};

API.prototype.editSecret = function(user, secretObject, hashedTitle){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/edit/'+hashedUsername+'/'+hashedTitle,{
      iv: secretObject.iv,
      secret: secretObject.secret,
      iv_meta: secretObject.iv_meta,
      metadatas: secretObject.metadatas,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.newKey = function(user, hashedTitle, secret, wrappedKeys){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/newKey/'+hashedUsername+'/'+hashedTitle,{
      wrappedKeys: wrappedKeys,
      secret: secret,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.unshareSecret = function(user, friendName, hashedTitle, hashedFriendUsername){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return SHA256(friendName);
  }).then(function(rHashedFriendUsername){
    if(typeof(hashedFriendUsername) === 'undefined'){
      hashedFriendUsername = bytesToHexString(rHashedFriendUsername);
    }
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/unshare/'+hashedUsername+'/'+hashedTitle,{
      friendName: hashedFriendUsername,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.shareSecret = function(user, sharedSecretObject, hashedTitle, rights){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return POST(_this.db+'/share/'+hashedUsername+'/'+hashedTitle,{
      friendName: sharedSecretObject.friendName,
      key: sharedSecretObject.wrappedKey,
      rights: rights,
      token: bytesToHexString(token)
    });
  });
};

API.prototype.retrieveUser = function(username, hash, isHashed){
  var _this = this;
  if(isHashed){
    return GET(_this.db+'/user/'+username+'/'+hash);
  }
  else{
    return SHA256(username).then(function(hashedUsername){
      return GET(_this.db+'/user/'+bytesToHexString(hashedUsername)+'/'+hash);
    });
  }
};

API.prototype.getDerivationParameters = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return {salt: user.pass.salt, iterations: user.pass.iterations};
  });
};

API.prototype.getWrappedPrivateKey = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.privateKey;
  });
};

API.prototype.getPublicKey = function(username, isHashed){
  var _this = this;
  return _this.retrieveUser(username, 'undefined', isHashed).then(function(user){
    return user.publicKey;
  });
};

API.prototype.getKeysWithToken = function(user){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return GET(_this.db+'/user/'+hashedUsername+'?token='+bytesToHexString(token));
  }).then(function(userContent){
    return userContent.keys;
  });
};

API.prototype.getKeys = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user.keys;
  });
};

API.prototype.getUser = function(username, hash, isHashed){
  var _this = this;
  return _this.retrieveUser(username, hash, isHashed).then(function(user){
    return user;
  });
};

API.prototype.getSecret = function(hashedTitle, user){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return GET(_this.db+'/secret/'+hashedTitle+'?name='+hashedUsername+'&token='+bytesToHexString(token));
  });
};

API.prototype.getAllMetadatas = function(user){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return GET(_this.db+'/allMetadatas/'+hashedUsername+'?token='+bytesToHexString(token));
  });
};

API.prototype.getDb = function(username, hash, isHashed){
  var _this = this;
  return SHA256(username).then(function(hashedUsername){
    return GET(_this.db+'/database/'+bytesToHexString(hashedUsername)+'/'+hash);
  });
};

API.prototype.changePassword = function(user, privateKey, pass){
  var _this = this;
  var hashedUsername;
  return SHA256(user.username).then(function(rHashedUsername){
    hashedUsername = bytesToHexString(rHashedUsername);
    return user.getToken(_this);
  }).then(function(token){
    return PUT(_this.db+'/user/'+hashedUsername,{
      pass: pass,
      privateKey: privateKey,
      token: bytesToHexString(token)
    });
  });
};
if(typeof(crypto) === 'undefined'){
    crypto = msCrypto;
}
if(typeof(crypto.subtle) === 'undefined'){
    crypto.subtle = crypto.webkitSubtle;
}
// ###################### crypto.js ######################

function SHA256(str){
  var algorithm = 'SHA-256';
  var data = asciiToUint8Array(str);
  return crypto.subtle.digest(algorithm, data);
}

function genRSAOAEP(){
  var algorithm = {
    name: 'RSA-OAEP',
    modulusLength: 4096,
    publicExponent: new Uint8Array([0x01, 0x00, 0x01]),
    hash: {name: 'SHA-256'}
  };
  var extractable = true;
  var keyUsages = [
    'wrapKey',
    'unwrapKey',
    'encrypt',
    'decrypt'
  ];
  return crypto.subtle.generateKey(algorithm, extractable, keyUsages);
}


function encryptAESGCM256(secret, key){
  var result = {};
  var algorithm = {};
  if(typeof key === 'undefined'){
    algorithm = {
      name: 'AES-GCM',
      length: 256
    };
    var extractable = true;
    var keyUsages = [
      'encrypt'
    ];
    return crypto.subtle.generateKey(algorithm, extractable, keyUsages).then(function(key){
      var iv = new Uint8Array(12);
      crypto.getRandomValues(iv);
      algorithm = {
        name: 'AES-GCM',
        iv: iv,
        tagLength: 128
      };
      var data = asciiToUint8Array(JSON.stringify(secret));
      result.key = key;
      result.iv = iv;
      return crypto.subtle.encrypt(algorithm, key, data);
    }).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
  else{
    result.key = key;
    var iv = new Uint8Array(12);
    crypto.getRandomValues(iv);
    algorithm = {
      name: 'AES-GCM',
      iv: iv,
      tagLength: 128
    };
    var data = asciiToUint8Array(JSON.stringify(secret));
    result.iv = iv;
    return crypto.subtle.encrypt(algorithm, key, data).then(function(encryptedSecret){
      result.secret = encryptedSecret;
      return result;
    });
  }
}

function decryptAESGCM256(secretObject, key){
  var algorithm = {
    name: 'AES-GCM',
    iv: hexStringToUint8Array(secretObject.iv),
    tagLength: 128
  };
  var data = hexStringToUint8Array(secretObject.secret);
  return crypto.subtle.decrypt(algorithm, key, data);
}

function encryptRSAOAEP(secret, publicKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = asciiToUint8Array(secret);
  return crypto.subtle.encrypt(algorithm, publicKey, data);
}

function decryptRSAOAEP(secret, privateKey){
  var algorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var data = hexStringToUint8Array(secret);
  return crypto.subtle.decrypt(algorithm, privateKey, data);
}

function wrapRSAOAEP(key, wrappingPublicKey){
  var format = 'raw';
  var wrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  return crypto.subtle.wrapKey(format, key, wrappingPublicKey, wrapAlgorithm);
}

function unwrapRSAOAEP(wrappedKeyHex, unwrappingPrivateKey){
  var format = 'raw';
  var wrappedKey = hexStringToUint8Array(wrappedKeyHex);
  var unwrapAlgorithm = {
    name: 'RSA-OAEP',
    hash: {name: 'SHA-256'}
  };
  var unwrappedKeyAlgorithm  = {
    name: 'AES-GCM',
    length: 256
  };
  var extractable = true;
  var usages = ['decrypt', 'encrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedKey, unwrappingPrivateKey, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, usages
  );
}

function exportPublicKey(publicKey){
  var format = 'jwk';
  return crypto.subtle.exportKey(format, publicKey);
}

function importPublicKey(jwkPublicKey){
  var format = 'jwk';
  var algorithm = {
    name: "RSA-OAEP",
    hash: {name: "SHA-256"}
  };
  var extractable = false;
  var keyUsages = [
    'wrapKey', 'encrypt'
  ];
  return crypto.subtle.importKey(format, jwkPublicKey, algorithm, extractable, keyUsages);
}

function derivePassword(password, parameters){
  var result = {};

  var passwordBuf = asciiToUint8Array(password);
  var extractable = false;
  var usages = ['deriveKey', 'deriveBits'];

  return crypto.subtle.importKey(
    'raw', passwordBuf, {name: 'PBKDF2'}, extractable, usages
  ).then(function(key){

    var saltBuf;
    var iterations;
    if(typeof parameters === 'undefined'){
      saltBuf = new Uint8Array(32);
      crypto.getRandomValues(saltBuf);
      var iterationsBuf = new Uint8Array(1);
      crypto.getRandomValues(iterationsBuf);
      iterations = 100000 + iterationsBuf[0];
    }
    else{
      saltBuf = hexStringToUint8Array(parameters.salt);
      if(typeof parameters.iterations === 'undefined'){
        iterations = 10000; //retrocompatibility
      }
      else{
        iterations = parameters.iterations;
      }
    }

    result.salt = saltBuf;
    result.iterations = iterations;

    var algorithm = {
      name: "PBKDF2",
      salt: saltBuf,
      iterations: iterations,
      hash: {name: "SHA-256"}
    };

    var deriveKeyAlgorithm = {
      name: "AES-CBC",
      length: 256
    };

    extractable = true;
    usages = ['wrapKey', 'unwrapKey'];

    return crypto.subtle.deriveKey(algorithm, key, deriveKeyAlgorithm, extractable, usages);
  }).then(function(dKey){
    result.key = dKey;
    return crypto.subtle.exportKey('raw', dKey);
  }).then(function(rawKey){
    return crypto.subtle.digest('SHA-256', rawKey);
  }).then(function(hashedKey){
    result.hash = hashedKey;
    return result;
  });
}

function exportPrivateKey(key, privateKey){
  var result = {};
  var format = 'jwk';
  var iv = new Uint8Array(16);
  crypto.getRandomValues(iv);
  var wrapAlgorithm = {
    name: "AES-CBC",
    iv: iv
  };
  result.iv = iv;
  return crypto.subtle.wrapKey(
    format, privateKey, key, wrapAlgorithm
  ).then(function(wrappedPrivateKey){
    result.privateKey = wrappedPrivateKey;
    return result;
  });
}

function importPrivateKey(key, privateKeyObject){
  var format = 'jwk';
  var wrappedPrivateKey = hexStringToUint8Array(privateKeyObject.privateKey);
  var unwrapAlgorithm = {
    name: 'AES-CBC',
    iv: hexStringToUint8Array(privateKeyObject.iv)
  };
  var unwrappedKeyAlgorithm = {
    name: "RSA-OAEP",
    hash: {name: "sha-256"}
  };
  var extractable = true;
  var keyUsages = ['unwrapKey', 'decrypt'];

  return crypto.subtle.unwrapKey(
    format, wrappedPrivateKey, key, unwrapAlgorithm, unwrappedKeyAlgorithm, extractable, keyUsages
  ).then(function(privateKey){
    return privateKey;
  }).catch(function(err){
    throw('Invalid Password');
  });
}

// ###################### http.js ######################

function GET(path){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', encodeURI(path));
    xhr.onload = function() {
      if (xhr.status === 200) {
        var datas = JSON.parse(xhr.responseText);
        resolve(datas);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send();
  });
}

function POST(path, datas){
  return reqData(path, datas, 'POST');
}

function PUT(path, datas){
  return reqData(path, datas, 'PUT');
}

function reqData(path, datas, type){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open(type, encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

function DELETE(path, datas){
  return new Promise(function(resolve, reject){
    var xhr = new XMLHttpRequest();
    xhr.open('DELETE', encodeURI(path));
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.onload = function() {
      if (xhr.status === 200) {
        resolve(xhr.statusText);
      }
      else{
        reject(xhr.statusText);
      }
    };
    xhr.send(JSON.stringify(datas));
  });
}

// ###################### secretin.js ######################

function newUser(username, password){
  return api.userExists(username).then(function(exists){
    if(!exists){
      var result = {};
      var pass = {};
      currentUser = new User(username);
      return currentUser.generateMasterKey().then(function(){
        return derivePassword(password);
      }).then(function(dKey){
        pass.salt = bytesToHexString(dKey.salt);
        pass.hash = bytesToHexString(dKey.hash);
        pass.iterations = dKey.iterations;
        currentUser.hash = pass.hash;
        return currentUser.exportPrivateKey(dKey.key);
      }).then(function(privateKey){
        result.privateKey = privateKey;
        return currentUser.exportPublicKey();
      }).then(function(publicKey){
        result.publicKey = publicKey;
        return api.addUser(currentUser.username, result.privateKey, result.publicKey, pass);
      }, function(err){
        throw(err);
      });
    }
    else{
      throw('Username already exists');
    }
  });
}

function getKeys(username, password){
  return api.getDerivationParameters(username).then(function(parameters){
    return derivePassword(password, parameters);
  }).then(function(dKey){
    key = dKey.key;
    hash = bytesToHexString(dKey.hash);
    return api.getUser(username, hash);
  }).then(function(user){
    currentUser = new User(username);
    remoteUser = user;
    currentUser.keys = remoteUser.keys;
    currentUser.hash = hash;
    return currentUser.importPublicKey(remoteUser.publicKey);
  }).then(function(){
    return currentUser.importPrivateKey(key, remoteUser.privateKey);
  }, function(err){
    throw(err);
  });
}

function refreshKeys(){
  return api.getKeysWithToken(currentUser).then(function(keys){
    currentUser.keys = keys;
    return keys;
  }, function(err){
    throw(err);
  });
}

function addSecret(metadatas, content){
  return new Promise(function(resolve, reject){
    metadatas.users = {};
    metadatas.users[currentUser.username] = {rights: 3};
    if(typeof(currentUser.username) === 'string'){
      return currentUser.createSecret(metadatas, content).then(function(secretObject){
        return api.addSecret(currentUser, secretObject);
      }).then(function(msg){
        resolve(refreshKeys());
      }, function(err){
        throw(err);
      });
    }
    else{
      throw('You are disconnected');
    }
  });
}

function changePassword(password){
  var pass = {};
  return derivePassword(password).then(function(dKey){
    pass.salt = bytesToHexString(dKey.salt);
    pass.hash = bytesToHexString(dKey.hash);
    pass.iterations = dKey.iterations;
    return currentUser.exportPrivateKey(dKey.key);
  }).then(function(privateKey){
    return api.changePassword(currentUser, privateKey, pass);
  }, function(err){
    throw(err);
  });
}

function editSecret(hashedTitle, metadatas, content){
  return currentUser.editSecret(metadatas, content, currentUser.keys[hashedTitle].key).then(function(secretObject){
    return api.editSecret(currentUser, secretObject, hashedTitle);
  }, function(err){
    throw(err);
  });
}

function shareSecret(hashedTitle, friendName, rights){
  var friend = new User(friendName);
  return api.getPublicKey(friend.username).then(function(publicKey){
    return friend.importPublicKey(publicKey);
  }).then(function(){
    return currentUser.shareSecret(friend, currentUser.keys[hashedTitle].key, hashedTitle);
  }).then(function(sharedSecretObject){
    return api.shareSecret(currentUser, sharedSecretObject, hashedTitle, rights);
  }).then(function(){
    return api.getSecret(hashedTitle, currentUser);
  }).then(function(encryptedSecret){
    return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
  }).then(function(secret){
    currentUser.metadatas[hashedTitle].users[friend.username] = {rights: rights};
    return editSecret(hashedTitle, currentUser.metadatas[hashedTitle], JSON.parse(secret));
  }, function(err){
    throw(err);
  });
}

function unshareSecret(hashedTitle, friendName, friendName2){ //friendName2 exists to help migration
  var friend;
  var encryptedSecret;
  var secret = {};
  var wrappedKeys = [];
  return api.unshareSecret(currentUser, friendName, hashedTitle, friendName2).then(function(){
    return api.getSecret(hashedTitle, currentUser);
  }).then(function(eSecret){
    encryptedSecret = eSecret;
    return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
  }).then(function(secret){
    delete currentUser.metadatas[hashedTitle].users[friendName];
    return currentUser.encryptSecret(currentUser.metadatas[hashedTitle], JSON.parse(secret));
  }).then(function(secretObject){
    secret.secret    = secretObject.secret;
    secret.iv        = secretObject.iv;
    secret.metadatas = secretObject.metadatas;
    secret.iv_meta   = secretObject.iv_meta;
    return new Promise(function(resolve, reject){
      encryptedSecret.users.forEach(function(hashedUsername){
        api.getPublicKey(hashedUsername, true).then(function(publicKey){
          friend = new User(hashedUsername);
          return friend.importPublicKey(publicKey);
        }).then(function(){
          return currentUser.wrapKey(secretObject.key, friend.publicKey);
        }).then(function(friendWrappedKey){
          wrappedKeys.push({user: hashedUsername, key: friendWrappedKey });
          if(wrappedKeys.length === encryptedSecret.users.length){
            resolve(api.newKey(currentUser, hashedTitle, secret, wrappedKeys));
          }
        });
      });
    });
  }, function(err){
    throw(err);
  });
}

function getSecret(hashedTitle){
  return api.getSecret(hashedTitle, currentUser).then(function(rEncryptedSecret){
    var encryptedSecret = {secret: rEncryptedSecret.secret, iv: rEncryptedSecret.iv};
    return currentUser.decryptSecret(encryptedSecret, currentUser.keys[hashedTitle].key);
  });
}

function deleteSecret(hashedTitle){
  return api.deleteSecret(currentUser, hashedTitle).then(function(){
    return refreshKeys();
  }, function(err){
    throw(err);
  });
}

function getAllMetadatas(){
  return api.getAllMetadatas(currentUser).then(function(allMetadatas){
    return currentUser.decryptAllMetadatas(allMetadatas);
  }, function(err){
    throw(err);
  })
}

// ###################### util.js ######################

function hexStringToUint8Array(hexString){
  if (hexString.length % 2 !== 0){
    throw "Invalid hexString";
  }
  var arrayBuffer = new Uint8Array(hexString.length / 2);

  for (var i = 0; i < hexString.length; i += 2) {
    var byteValue = parseInt(hexString.substr(i, 2), 16);
    if (isNaN(byteValue)){
      throw "Invalid hexString";
    }
    arrayBuffer[i/2] = byteValue;
  }

  return arrayBuffer;
}

function bytesToHexString(bytes){
  if (!bytes){
    return null;
  }

  bytes = new Uint8Array(bytes);
  var hexBytes = [];

  for (var i = 0; i < bytes.length; ++i) {
    var byteString = bytes[i].toString(16);
    if (byteString.length < 2){
      byteString = "0" + byteString;
    }
    hexBytes.push(byteString);
  }
  return hexBytes.join("");
}

function asciiToUint8Array(str){
  var chars = [];
  for (var i = 0; i < str.length; ++i){
    chars.push(str.charCodeAt(i));
  }
  return new Uint8Array(chars);
}

function bytesToASCIIString(bytes){
  return String.fromCharCode.apply(null, new Uint8Array(bytes));
}

function generateRandomString(length){
  var charset = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ123456789 !"#$%&\'()*+,-./:;<=>?@[\\]_{}';
  var randomValues = new Uint8Array(length);
  crypto.getRandomValues(randomValues);
  var string = '';
  for(var i = 0; i < length; i++){
    string += charset[randomValues[i]%charset.length];
  }
  return string;
}

function uiSharedUsers(userHash){
  var elem = document.createElement('li');
  elem.classList.add('sharedUserElem');

  var userHashSpan = document.createElement('span');
  userHashSpan.textContent = userHash;

  var unshareBtn = document.createElement('input');
  unshareBtn.type = 'button';
  unshareBtn.value = 'Unshare';
  unshareBtn.addEventListener('click', unshare);

  elem.appendChild(userHashSpan);
  elem.appendChild(unshareBtn);
  return elem;
}

function uiSecretList(hashedTitle, title){
  var elem = document.createElement('li');
  elem.classList.add('secretElem');

  var btn = document.createElement('input');
  btn.type = 'button';
  btn.value = 'Show';
  btn.addEventListener('click', showSecretPopup);

  var shareBtn = document.createElement('input');
  shareBtn.type = 'button';
  shareBtn.value = 'Share';
  shareBtn.addEventListener('click', share);

  var deleteBtn = document.createElement('input');
  deleteBtn.type = 'button';
  deleteBtn.value = 'Delete';
  deleteBtn.addEventListener('click', uiDeleteSecret);

  var titleSpan = document.createElement('span');
  titleSpan.textContent = title;

  var br = document.createElement('br');

  var hashSpan = document.createElement('span');
  hashSpan.textContent = hashedTitle;
  hashSpan.style.display = 'none';

  elem.appendChild(hashSpan);
  elem.appendChild(titleSpan);
  elem.appendChild(br);
  elem.appendChild(btn);

  if(currentUser.keys[hashedTitle].rights > 1){
    elem.appendChild(shareBtn);
  }
  elem.appendChild(deleteBtn);

  return elem;
}
document.getElementById('dbUri').addEventListener('change', function(e) {
  var db = e.target.value;
  api = new API(db);
});

document.getElementById('db').disabled = true;

var api = new API();
var currentUser = {};

});